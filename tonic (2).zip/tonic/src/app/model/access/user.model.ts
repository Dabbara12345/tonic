import { Role } from './role.model';
import { Store } from '../store.model';
import { Alert } from '../communication/alert.model';
import { Security } from './security.model';
import { NameValue } from '../utils/nameValue.model';
import { Permission } from './permission.model';

export class User {

  public id!: number;

  public firstName!: string;
  public initial?: string;
  public lastName!: string;
  public description?: string;

  public email?: string;
  public employeeNumber?: string;
  public password?: string;
  public changePassword?: boolean;
  public track1?: string;

  public store?: Store;
  public storeId?: number;

  public cellNumber?: string;
  public phoneNumber?: string;
  public sms?: string;

//  public paylocityId?: string;
  public address?: string;
  public city?: string;
  public state?: string;
  public postalCode?: string;
  public locale?: string;

  public maxComp?: number;
  public tipWeight?: number;
  public hourlyWages?: number;

  public alerts?: Array<Alert>;
  public permissions?: Array<Permission>;
  public securities?: Array<Security>;
  public settings?: Array<NameValue>;

  public reasonFired?: string;

  public fired?: Date;
  public hired?: Date;
  public created?: Date; // Used in the Staff Print
  public disabled?: Date;
  public lastLogin?: Date;

  public load(data: any): this {
    Object.assign(this, data);

    this.alerts = new Array<Alert>();

    data?.alerts
        ?.forEach((a: Alert): void => {

      this.alerts
          .push(new Alert().load(a));

    });

    this.securities = new Array<Security>();

    data?.securities
        ?.forEach((s: Security): void => {

      this.securities
          .push(new Security().load(s));
    });

    this.permissions = new Array<Permission>();

    data?.permissions
        ?.forEach((p: Permission): void => {
      this.permissions
          .push(new Permission().load(p));
    });

    this.settings = new Array<NameValue>();

    data?.settings
        ?.forEach((nV: NameValue): void => {

      this.settings
          .push(new NameValue().load(nV));
    });

    if(this.settings.length === 0){

      if(data?.paylocityId){
        this.setValue('PAYLOCITY_ID', data.paylocityId);
      }

      if(data?.engageId){
        this.setValue('ENGAGE_PEO_ID', data.engageId);
      }
    }

    if(data?.hired){
      this.hired = new Date(data.hired);
    }

    if(data?.fired){
      this.fired = new Date(data.fired);
    }

    if(data?.lastLogin){
      this.lastLogin = new Date(data.lastLogin);
    }

    if(data?.disabled){
      this.disabled = new Date(data.disabled);
    }

    if(data?.created){
      this.created = new Date(data.created);
    }

    return this;
  }

  public getName?(): string {

    let name: string = '';

    if (this.firstName){
      name = this.firstName;
    }

    if (this.lastName){
      name += ' ' + this.lastName;
    }

    return name.trim();
  }

  public hasPermissionIn(permissionName: string,
                         store: Store): boolean {

    let has = false;

    if(store &&
       this.securities
          ?.length > 0){

      const main = this.securities
                      ?.find(s => s.storeId === store.id);

      if(main){
        has = this.containsPermission(main,
                                      permissionName);
      }

      if(!has && 
         this.isRoamer()){

        for(const sec of this.securities){

          if(sec.id !== main?.id &&
             this.containsPermission(sec,
                                     permissionName)){
            has = true;
            break;
          }
        }
      }
    }

    return has;
  }

  private hasPermission(permissionName: string): boolean {

    let has: boolean = false;

    for(const sec of this.securities){

      if(this.containsPermission(sec,
                                 permissionName)){
        has = true;
        break;
      }
    }

    return has;
  }

  private containsPermission(sec: Security,
                             permissionName: string): boolean {

    let has = sec.permissions
                 .some(p => 
                    p.name === permissionName ||
                    p.name === 'ROOT');

    if (!has) {

      has = sec.roles
               .some(r => 
                  r.permissions
                   .some(p => 
                      p.name === permissionName ||
                      p.name ===  'ROOT')
               );
    }

    return has;
  }

  public hasRole(role: Role,
                 storeId: number): boolean {

    let has: boolean = false;

    if (this.securities) {

      for (const s of this.securities) {

        if (s.storeId === storeId) {

          s.roles
           .forEach(r => {

            if (r.id === role.id) {
              has = true;
            }
          });
        }
      }
    }

    return has;
  }

  public isGroup(group: string,
                 storeId: number): boolean {

    let has: boolean = false;

    if (this.securities) {

      for (const s of this.securities) {

        if (s.storeId === storeId) {

          s.roles
           .forEach(r => {

            if (r.groupName === group) {
              has = true;
            }
          });
        }
      }
    }

    return has;
  }

  public getRoles(store?: Store): Array<Role> {
    const roles: Role[] = new Array<Role>();

    if (this.securities) {

      for (const s of this.securities) {

        if (!store ||
            s.storeId === store?.id) {

          s.roles
           .forEach(r => {
              roles.push(r);
            });
          }
      }
    }

    return roles;
  }

  public hasRoles(store?: Store):boolean {
    return this.getRoles(store)
               .length > 0;
  }

  public isSupport(): boolean {

    return this.isRoot() ||
           this.isSupportManager() ||
           this.isSupportStaff() ||
           this.isSales();
  }

  public isRoot(): boolean {
    return this.hasPermission('ROOT');
  }

  public isSupportManager(): boolean {
    return this.hasPermission('SUPPORT_MANAGER');
  }

  public isSupportStaff(): boolean {
    return this.hasPermission('SUPPORT_STAFF');
  }

  public isPartner(): boolean {

    return this.isPartnerManager() ||
           this.isPartnerStaff() ||
           this.isPartnerReadOnly();
  }

  public isPartnerManager(): boolean {
    return this.hasPermission('PARTNER_MANAGER');
  }

  public isPartnerStaff(): boolean {
    return this.hasPermission('PARTNER_STAFF');
  }

  public isPartnerReadOnly(): boolean {
    return this.hasPermission('PARTNER_READ_ONLY');
  }

  public isSales(): boolean {
    return this.hasPermission('SUPPORT_READ_ONLY');
  }

  public isRoamer(): boolean {
    return this.hasPermission('SUPER_USER');
  }

  public hasSetting(name: string): boolean {

    let has: boolean;

    if (this.settings.length > 0) {

      const sett: NameValue = this.settings.filter(s => s.name === name)[0];

      if (sett){
        has = true;
      }
    }

    return has;
  }

  public setValue(name: string,
                  value: string): void {

    if (!this.settings){
      this.settings = new Array<NameValue>();
    }

    const sett: NameValue = this.settings.filter(s => s.name === name)[0];

    if (sett){

      if (value){
        sett.value = value;
      } else {
        this.settings
            .splice(this.settings.indexOf(sett), 1);
      }

    } else if (value){

      this.settings
          .push(new NameValue().load({name, value}));
    }
  }

  public getValue(name: string): string {

    let value: string;

    if (name &&
        this.settings){

      const sett: NameValue = this.settings.filter(s => s.name === name)[0];

      if (sett){
        value = sett.value;
      }
    }

    return value;
  }

  public removeValue(name: string): void {

    const index: number = this.settings
                              ?.findIndex(e => e.name === name);

    if (index >= 0) {

      this.settings
          .splice(index, 1);
    }
  }

  public get verifyEmail(): boolean {
    return this.getValue('VERIFY_EMAIL') !== undefined;
  }

  public set verifyEmail(value: boolean) {
    this.setValue('VERIFY_EMAIL',
                  value?.toString());
  }

  public setSalary(value: number): void {

    this.setValue('ANNUAL_WAGES',
                  value?.toString());
  }

  public getSalary(): number {

    const value: string = this.getValue('ANNUAL_WAGES');

    return value?.length > 0 ?
            parseInt(value, 10) :
            this.hourlyWages * 40 * 52;
  }

  public isSalaried(): boolean {
    return this.getValue('ANNUAL_WAGES')?.length > 0;
  }

  public get paylocityId(): string {
    return this.getValue('PAYLOCITY_ID');
  }

  public set paylocityId(id: string){
    this.setValue('PAYLOCITY_ID', id);
  }

  public hasPayrollId(company: string): boolean {

    const id: string = this.getPayrollId(company);

    return id ? true : false;
  }

  public setPayrollId(company: string,
                      id: string): void {
    this.setValue(this.getPayrollIdSettingName(company), id);
  }

  public getPayrollId(company: string): string {
    return this.getValue(this.getPayrollIdSettingName(company));
  }

  private getPayrollIdSettingName(company: string): string {

    let name: string = '';

    switch (company ? company.toLowerCase() : '') {

      case 'adp'://
        name = 'ADP_ID';
        break;

      case 'paycor'://
        name = 'PAYCOR_ID';
        break;

      case 'paychex'://
        name = 'PAYCHEX_ID';
        break;

      case 'paymaster':
        name = 'PAYMASTER_ID';
        break;

      case 'paylocity':
        name = 'PAYLOCITY_ID';
        break;

      case 'peo':
        name = 'ENGAGE_PEO_ID';
        break;

      case 'dominion':
        name = 'DOMINION_PAYROLL_ID';
        break;

      case 'heartland'://
        name = 'HEARTLAND_ID';
        break;

    }

    return name;
  }

  public isConnectedToQb(): boolean {
    let connected = false;

    let accessToken = this.settings.find(s => s.name.includes('QB_accessToken')) ? true : false;
    let refreshToken = this.settings.find(s => s.name.includes('QB_refresh_token')) ? true : false;
    let dateCreated = this.settings.find(s => s.name.includes('QB_accessTokenDateCreated')) ? true : false;

    if (accessToken &&
        refreshToken &&
        dateCreated) {
      connected = true;
    }

    return connected;
  }

  public setMainContact(store: Store,
                         on: boolean): void {
    this.setValue('MAIN_CONTACT_' + store.id, on ? 'true': 'false');
  }

  public isMainContact(store: Store): boolean {
    return this.getValue('MAIN_CONTACT_' + store.id) === 'true';
  }

  public hasAccess(store: Store): boolean {

    return this.securities
              ?.find(s => s.id === store.id) !== undefined;
  }
}
