import { User } from "./user.model";
import { Category } from "../map/category.model";
import { Permission } from "./permission.model";
import { SubCategory } from "../map/subCategory.model";

export class BOH {

  public boh: Array<Category>;

  constructor(user: User) {
    this.boh = this.bohSection(user);
  }

  /**
   * Getter $boh
   * @return {Array<Category> }
   */
	public get $boh(): Array<Category>  {
		return this.boh;
  }

  private bohSection(user: User): Array<Category> {

    const bohArr: Array<Category> = new Array<Category>();

    bohArr.push(this.access());
    bohArr.push(this.store());
    bohArr.push(this.order(user));
    bohArr.push(this.payment());
    bohArr.push(this.menu());
    bohArr.push(this.item());
    bohArr.push(this.cashManagement());
    bohArr.push(this.communications());
    bohArr.push(this.equipment());
    bohArr.push(this.attendance());
    bohArr.push(this.customerAccounts());
    bohArr.push(this.inventory());
    bohArr.push(this.enterprise(user));

    return bohArr;
  }

  private access(): Category {
    const login:  SubCategory = new SubCategory('Login', new Array<Permission>(
      new Permission('WEBSITE_LOGIN',       'Login')
    ));

    const reports:  SubCategory = new SubCategory('Reports', new Array<Permission>(
      new Permission('VIEW_REPORTS', 'View'),
      new Permission('VIEW_REPORTS_SALES', 'Sales'),
      new Permission('VIEW_REPORTS_DEPOSITS', 'Deposits'),
      new Permission('VIEW_REPORTS_SECURITY', 'Security'),
      new Permission('VIEW_REPORTS_STATISTICS', 'Statistics'),
      new Permission('VIEW_REPORTS_GENERAL', 'General'),
      new Permission('VIEW_REPORTS_ATTENDANCE', 'Attendance'),
      new Permission('VIEW_REPORTS_CUSTOMERS', 'Customers'),
      new Permission('VIEW_REPORTS_INVENTORY', 'Inventory'),
      new Permission('VIEW_REPORTS_CASH_MANAGEMENT', 'Cash Management'),
      new Permission('VIEW_REPORTS_ENTERPRISE', 'Enterprise')
    ));

    return new Category('Access', new Array<SubCategory>(login,
                                                         reports));
  }

  private store(): Category {

    const settings:  SubCategory = new SubCategory('Settings', new Array<Permission>(
      new Permission('MODIFY_SETTINGS', 'Settings')
    ));

    const info:  SubCategory = new SubCategory('Info', new Array<Permission>(
      new Permission('VIEW_SETUP', 'View'),
      new Permission('MODIFY_STORE', 'Modify')
    ));

    const ui:  SubCategory = new SubCategory('User Interface', new Array<Permission>(
      new Permission('MODIFY_COLORS', 'Colors'),
      new Permission('ADD_AREA', 'Add area'),
      new Permission('REMOVE_AREA', 'Remove area')
    ));

    const staff:  SubCategory = new SubCategory('Staff', new Array<Permission>(
      new Permission('ADD_STAFF', 'Add'),
      new Permission('REMOVE_STAFF', 'Remove')
    ));

    const roles:  SubCategory = new SubCategory('Roles', new Array<Permission>(
      new Permission('ADD_ROLE', 'Add'),
      new Permission('MODIFY_ROLE', 'Modify'),
      new Permission('REMOVE_ROLE', 'Remove')
    ));

    const permissions:  SubCategory = new SubCategory('Permissions', new Array<Permission>(
      new Permission('ADD_PERMISSION', 'Add'),
      new Permission('REMOVE_PERMISSION', 'Remove')
    ));

    return new Category('Store', new Array<SubCategory>(info,
                                                        ui,
                                                        staff,
                                                        roles,
                                                        permissions,
                                                        settings));
  }

  private menu(): Category {

    const menu:  SubCategory = new SubCategory('Menu', new Array<Permission>(
      new Permission('VIEW_MENU', 'View'),
      new Permission('ADD_MENU', 'Add'),
      new Permission('REMOVE_MENU', 'Remove'),
    ));

    const section:  SubCategory = new SubCategory('Section', new Array<Permission>(
      new Permission('ADD_SECTION', 'Add'),
      new Permission('REMOVE_SECTION', 'Remove')
    ));

    const item:  SubCategory = new SubCategory('Item', new Array<Permission>(
      new Permission('ADD_MAIN_ITEM', 'Add'),
      new Permission('REMOVE_MAIN_ITEM', 'Remove')
    ));

    const side:  SubCategory = new SubCategory('Side', new Array<Permission>(
      new Permission('ADD_SIDE_ITEM', 'Add'),
      new Permission('REMOVE_SIDE_ITEM', 'Remove')
    ));

    const combo:  SubCategory = new SubCategory('Combo', new Array<Permission>(
      new Permission('ADD_COMBO_GROUP', 'Add Group'),
      new Permission('REMOVE_COMBO_GROUP', 'Remove Group'),
      new Permission('ADD_COMBO', 'Add'),
      new Permission('REMOVE_COMBO', 'Remove')
    ));

    const menuCat: Category = new Category('Menu', new Array<SubCategory>(menu,
                                                                          section,
                                                                          item,
                                                                          side,
                                                                          combo));

    return menuCat;
  }

  private item(): Category {

    const item:  SubCategory = new SubCategory('Item', new Array<Permission>(
      new Permission('ADD_RECIPE', 'Add'),
      new Permission('REMOVE_RECIPE', 'Remove')
    ));

    const modifier:  SubCategory = new SubCategory('Modifier', new Array<Permission>(
      new Permission('ADD_PREPARATION_GROUP', 'Add'),
      new Permission('REMOVE_PREPARATION_GROUP', 'Remove'),
      new Permission('ADD_PREPARATION', 'Add Choice'),
      new Permission('REMOVE_PREPARATION', 'Remove Choice'),
      new Permission('ADD_PREPARATION_CHARGE', 'Add charge'),
      new Permission('REMOVE_PREPARATION_CHARGE', 'Remove charge')
    ));

    const salesGroup:  SubCategory = new SubCategory('Sales Groups', new Array<Permission>(
      new Permission('ADD_RECIPE_GROUP', 'Add'),
      new Permission('REMOVE_RECIPE_GROUP', 'Remove'),
      new Permission('MODIFY_RECIPE_GROUP', 'Modify')
    ));

    const recipeCat: Category = new Category('Item', new Array<SubCategory>(item,
                                                                            modifier,
                                                                            salesGroup));

    return recipeCat;
  }

  private order(user: User): Category {
    const subs = new Array<SubCategory>();

    subs.push(new SubCategory('View',
                              new Array<Permission>(new Permission('VIEW_OPEN_ORDERS',
                                                                   'VIEW_OPEN_ORDERS'))));

    subs.push(new SubCategory('Rule',
                              new Array<Permission>(new Permission('ADD_RULE', 'Add'),
                                                    new Permission('REMOVE_RULE', 'Remove'))));

    if(user.isRoot()){
      subs.push(new SubCategory('Logs',
                                new Array<Permission>(new Permission('REMOVE_ORDER_LOGS',
                                                                     'REMOVE_ORDER_LOGS'))));
    }

    return new Category('Order',
                        subs);
  }

  private payment(): Category {

    const type:  SubCategory = new SubCategory('Type', new Array<Permission>(
      new Permission('ADD_CUSTOM_PAYMENT_TYPE', 'Add'),
      new Permission('REMOVE_CUSTOM_PAYMENT_TYPE', 'Remove')
    ));

    const tax:  SubCategory = new SubCategory('Tax', new Array<Permission>(
      new Permission('ADD_TAX', 'Add'),
      new Permission('REMOVE_TAX', 'Remove'),
    ));

    const comp:  SubCategory = new SubCategory('Comp', new Array<Permission>(
      new Permission('ADD_COMP', 'Add'),
      new Permission('REMOVE_COMP', 'Remove')
    ));

    const discount:  SubCategory = new SubCategory('Discount', new Array<Permission>(
      new Permission('ADD_DISCOUNT', 'Add'),
      new Permission('REMOVE_DISCOUNT', 'Remove')
    ));

    return new Category('Payment', new Array<SubCategory>(type,
                                                          tax,
                                                          comp,
                                                          discount));
  }

  private cashManagement(): Category {

    const pettyCash = new SubCategory('Petty Cash', new Array<Permission>(
      new Permission('ADD_PETTY_CASH_TYPE', 'Add'),
      new Permission('REMOVE_PETTY_CASH_TYPE', 'Remove')
    ));

    const safe = new SubCategory('Safe', new Array<Permission>(
      new Permission('ADD_SAFE', 'Add'),
      new Permission('REMOVE_SAFE', 'Remove')
    ));

    const cashDiscount = new SubCategory('Cash Discount',
                              new Array<Permission>(new Permission('MODIFY_SETTINGS_CASH_DISCOUNT',
                                                                   'MODIFY_SETTINGS_CASH_DISCOUNT')));

    return new Category('Cash Management', new Array<SubCategory>(pettyCash,
                                                                  safe,
                                                                  cashDiscount));
  }

  private communications(): Category {

    const broadCast:  SubCategory = new SubCategory('Broadcast', new Array<Permission>(
      new Permission('ADD_BROADCAST_MESSAGE', 'Add'),
      new Permission('REMOVE_BROADCAST_MESSAGE', 'Remove')
    ));

    const message:  SubCategory = new SubCategory('Message', new Array<Permission>(
      new Permission('ADD_MESSAGE', 'Add'),
      new Permission('REMOVE_MESSAGE', 'Remove')
    ));

    const alert:  SubCategory = new SubCategory('Alert', new Array<Permission>(
      new Permission('ADD_ALERT', 'Add'),
      new Permission('REMOVE_ALERT', 'Remove')
    ));

    const communicationsCat: Category = new Category('Communications', new Array<SubCategory>(broadCast,
                                                                                              message,
                                                                                              alert));

    return communicationsCat;
  }

  private equipment(): Category {

    const terminal:  SubCategory = new SubCategory('Terminal', new Array<Permission>(
      new Permission('ENABLE_DISABLE_TERMINAL', 'Enable/Disable'),
      new Permission('REMOVE_TERMINAL', 'Remove')
    ));

    const KVD:  SubCategory = new SubCategory('KVD', new Array<Permission>(
      new Permission('ADD_KITCHEN_DISPLAY', 'Add'),
      new Permission('REMOVE_KITCHEN_DISPLAY', 'Remove')
    ));

    const cashDrawer:  SubCategory = new SubCategory('Cash Drawer', new Array<Permission>(
      new Permission('ADD_CASH_DRAWER', 'Add'),
      new Permission('REMOVE_CASH_DRAWER', 'Remove')
    ));

    const printer:  SubCategory = new SubCategory('Printer', new Array<Permission>(
      new Permission('ADD_PRINTER', 'Add'),
      new Permission('REMOVE_PRINTER', 'Remove')
    ));

    return new Category('Equipment', new Array<SubCategory>(terminal,
                                                            KVD,
                                                            cashDrawer,
                                                            printer));
  }

  private attendance(): Category {

    const view:  SubCategory = new SubCategory('View', new Array<Permission>(new Permission('VIEW_ATTENDANCE')));

    const modify:  SubCategory = new SubCategory('Modify', new Array<Permission>(
      new Permission('MODIFY_SCHEDULE', 'MODIFY_SCHEDULE'),
    ));

    const reconcile:  SubCategory = new SubCategory('Reconcile', new Array<Permission>(
      new Permission('RECONCILE_SCHEDULE', 'RECONCILE_SCHEDULE'),
    ));

    return new Category('Attendance', new Array<SubCategory>(view,
                                                             modify,
                                                             reconcile));
  }

  private customerAccounts(): Category {

    const reconcile:  SubCategory = new SubCategory('Reconcile', new Array<Permission>(
      new Permission('RECONCILE_CUSTOMER', 'RECONCILE_CUSTOMER')
    ));
    const customer:  SubCategory = new SubCategory('Customer', new Array<Permission>(
      new Permission('VIEW_CUSTOMERS', 'View'),
      new Permission('ADD_CUSTOMER', 'Add'),
      new Permission('REMOVE_CUSTOMER', 'Remove')
    ));
    const loyalty:  SubCategory = new SubCategory('Loyalty', new Array<Permission>(
      new Permission('MODIFY_LOYALTY', 'Modify'),
      new Permission('MODIFY_CUSTOMER_LOYALTY', 'Customer Loyalty')
    ));
    const promotion:  SubCategory = new SubCategory('Promotions', new Array<Permission>(
      new Permission('ADD_LOYALTY_PROMOTION', 'Add'),
      new Permission('REMOVE_LOYALTY_PROMOTION', 'Remove')
    ));

    return new Category('Customers', new Array<SubCategory>(customer,
                                                            reconcile,
                                                            loyalty,
                                                            promotion));
  }

  private enterprise(user: User): Category {
    const permissions = new Array<SubCategory>();

    const synch:  SubCategory = new SubCategory('Synch', new Array<Permission>(
      new Permission('ENTERPRISE_SYNCH', 'ENTERPRISE_SYNCH')
    ));

    const reports:  SubCategory = new SubCategory('Reports', new Array<Permission>(
      new Permission('VIEW_REPORTS_ENTERPRISE', 'VIEW_REPORTS_ENTERPRISE')
    ));

    permissions.push(synch);
    permissions.push(reports);

    if(user.isSupport() ||
       user.isRoamer()){
        const roaming:  SubCategory = new SubCategory('Roaming', new Array<Permission>(
          new Permission('SUPER_USER', 'SUPER_USER')
        ));

        permissions.push(roaming);
    }

    return new Category('Enterprise',
                        permissions);
  }

  private inventory(): Category {

    const po:  SubCategory = new SubCategory('Purchase order', new Array<Permission>(
      new Permission('ADD_PURCHASE_ORDER', 'Add'),
      new Permission('REMOVE_PURCHASE_ORDER', 'Remove')
    ));

    const ingredient:  SubCategory = new SubCategory('Ingredient', new Array<Permission>(
      new Permission('VIEW_INVENTORY', 'View'),
      new Permission('REMOVE_INGREDIENT', 'Remove'),
      new Permission('RECONCILE_INVENTORY', 'Reconcile'),
    ));
    const unit:  SubCategory = new SubCategory('Custom Unit', new Array<Permission>(
      new Permission('ADD_CUSTOM_MEASUREMENT_UNIT', 'Add'),
      new Permission('REMOVE_CUSTOM_MEASUREMENT_UNIT', 'Remove')
    ));
    const category:  SubCategory = new SubCategory('Category', new Array<Permission>(
      new Permission('ADD_INVENTORY_CATEGORY', 'Add'),
      new Permission('REMOVE_INVENTORY_CATEGORY', 'Remove')
    ));
    const vendor:  SubCategory = new SubCategory('Vendor', new Array<Permission>(
      new Permission('ADD_VENDOR', 'Add'),
      new Permission('REMOVE_VENDOR', 'Remove')
    ));

    return new Category('Inventory', new Array<SubCategory>(ingredient,
                                                            category,
                                                            vendor,
                                                            po,
                                                            unit));
  }
}
