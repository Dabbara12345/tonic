export class ApiToken {

  public id?: number;
  public name!: string;
  public access?: Array<string>;
  public encoded?: string;
  public limit: number;
  public periodUnit: number;
  public periodValue: number;

  public misc: any;

  public created?: Date;
  public expires?: Date;

  public load(data: any): this {

    Object.assign(this, data);

    this.access = new Array<string>();

    data?.access
        ?.forEach((a: string): void => {

      this.access
          .push(a);
    });

    if(data?.created){
      this.created = new Date(data.created);
    }

    if(data?.expires){
      this.expires = new Date(data.expires);
    }

    return this;
  }
}
