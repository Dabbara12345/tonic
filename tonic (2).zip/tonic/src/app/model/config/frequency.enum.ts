export enum Frequency {
  None = 'n',
  Monthly = 'm',
  Yearly = 'y',
  Weekly = 'w'
}
