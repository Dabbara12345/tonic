import { Time } from 'src/app/model/config/time.model';
import { Range } from 'src/app/model/config/range.model'
import { Schedule } from "./schedule.model";

export class OloSchedule extends Schedule {

  public type!: number;
  public seqNo!: number;
  public map?: Map<number, Range<Time>[]>;

  public load(data: any): this {
    Object.assign(this,
                  data);

    return this;
  }

  public isEmpty(): boolean {
    return this.count() === 0;
  }

  public count(): number {
    let count = 0;

    this.map
        .forEach((value, key) => count += value.length);

    return count;
  }
}
