export enum Anchor {
  Day = 'd',
  Start = 's',
  End = 'e'
}
