export class Mapping {

  public name: string;
  public type: string;
  public value: string;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
