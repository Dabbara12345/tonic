import { Store } from "../store.model";

export class Setting {

  public name:    string;
  public value:   string;

  public created:   Date;
  public updated:   Date;

  public store:     Store;

  public load(data: any): this {

    Object.assign(this, data);

    if (data?.created) {
      this.created = new Date(this.created);
    }

    if (data?.updated) {
      this.updated = new Date(this.updated);
    }

    if (data?.store) {
      this.store = new Store().load(this.store);
    }

    return this;
  }
}
