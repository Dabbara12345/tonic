import { Time } from './time.model';
import { Range } from './range.model';
import * as moment from 'moment-timezone';
import { Frequency } from './frequency.enum';
import { Anchor } from './anchor.enum';

export class EventInfo {

  /* ALL WAYS TO REPEAT
   Monthly on [x] day
   Monthly on [x]th [day of the week]
   Monthly on [x]th to last [day of the week]
   Yearly on [x] day
   Yearly on [x]th [day of the week] of [month of the year]
   Special case
  */

  /* SPECIAL CASE
   static readonly REPEAT_TYPE_HANUKKAH
   static readonly REPEAT_TYPE_LUNAR_NEW_YEAR
   static readonly REPEAT_TYPE_RAMADAN
   static readonly REPEAT_TYPE_EASTER
   static readonly REPEAT_TYPE_PASSOVER
   */

  public eventId!: number;

  public dateRange!: Range<Date>;
  public timeRange!: Range<Time>;

  public name!: string;

  public frequency!: Frequency;
  public anchor!: Anchor;

  private getWeekOfMonth(m: moment.Moment): number {

    let week: number;

    if (this.anchor === Anchor.End) {
      week = Math.floor(1 + (m.daysInMonth() - m.date()) / 7);
    } else {
      week = Math.ceil(m.date() / 7);
    }

    return week;
  }

  private getOrdinal(week: number): string {

    let ord: string = '';

    switch (week) {
      case 1:
        ord = 'First';
        break;

      case 2:
        ord = 'Second';
        break;

      case 3:
        ord = 'Third';
        break;

      case 4:
        ord = 'Fourth';
        break;

      case 5:
        ord = 'Fifth';
        break;
    }

    return ord;
  }

  private getWeekOrdinal(num: number): string {

    let ordinalStr: string;

    if (this.anchor === Anchor.Start) {
      ordinalStr = this.getOrdinal(num);
    } else if (num === 1) {
      ordinalStr = 'last';
    } else {
      ordinalStr = this.getOrdinal(num) + ' to last';
    }

    return ordinalStr;
  }

  public getAnchorString(): string {

    const start: moment.Moment = moment(this.dateRange.start);
    const end: moment.Moment = moment(this.dateRange.end);
    let dateStr: string;

    if (this.frequency) {

      if (this.frequency === Frequency.Monthly) {

        const sameDay: boolean = start.isSame(end, 'day');
        const startDate: number = start.date();
        const endDate: number = end.date();

        if (this.anchor && this.anchor === Anchor.Start || this.anchor === Anchor.End) {

          const startDay: string = start.format('dddd');
          const weeksPassed: number = Math.floor(moment.duration(end.diff(start)).asWeeks());
          const week: number = this.getWeekOfMonth(start);
          const startOrdinal: string = this.getWeekOrdinal(week);

          if (sameDay) {

            dateStr = startOrdinal + ' ' + startDay;
          } else {

            const endDay: string = end.format('dddd');
            let endOrdinal: string = this.getWeekOrdinal((this.anchor === Anchor.End) ?
                                week - weeksPassed :
                                week + weeksPassed);

            endOrdinal = endOrdinal[0].toUpperCase() + endOrdinal.slice(1);

            dateStr = startOrdinal + ' ' + startDay + ' - ' + endOrdinal + ' ' + endDay
          }
        } else {

          if (sameDay) {
            dateStr = 'Day ' + startDate;
          } else {
            dateStr = 'Days ' + startDate + '-' + endDate;
          }
        }
      } else if (this.frequency === Frequency.Yearly) {

        const sameDay: boolean = start.isSame(end, 'day');

        if (this.anchor && this.anchor === Anchor.Start || this.anchor === Anchor.End) {

          const startDay: string = start.format('dddd');
          const week: number = this.getWeekOfMonth(start);
          const startOrdinal: string = this.getWeekOrdinal(week);

          if (sameDay) {

            dateStr = startOrdinal + ' ' + startDay + ' of ' + start.format('MMM');
          } else {

            const weeksPassed: number = Math.floor(moment.duration(end.diff(start)).asWeeks());
            const endDay: string = end.format('dddd');
            let endOrdinal: string = this.getWeekOrdinal((this.anchor === Anchor.End) ?
                                                            week - weeksPassed :
                                                            week + weeksPassed);

            endOrdinal = endOrdinal[0].toUpperCase() + endOrdinal.slice(1);

            dateStr = startOrdinal + ' ' + startDay + ' of ' + start.format('MMM') + ' - ' +
                      endOrdinal + ' ' + endDay + ' of ' + end.format('MMM');
          }
        } else {

          if (sameDay) {
            dateStr = start.format('MMM Do');
          } else {
            dateStr = start.format('MMM Do') + ' - ' + end.format('MMM Do');
          }
        }
      }
    }

    if (!dateStr) {

      const startStr: string = start.format('M/D/YYYY');

      if (start.isSame(end, 'day')) {
        dateStr = startStr
      } else {
        dateStr = startStr + ' - ' + end.format('M/D/YYYY');
      }
    }

    if (dateStr.length > 0) {
      dateStr = dateStr[0].toUpperCase() + dateStr.slice(1);
    }

    return dateStr;
  }

  public getFrequencyString(): string {

    let frequencyStr: string;

    if (!this.frequency ||
        this.frequency === Frequency.None) {
      frequencyStr = 'Does not repeat';
    } else if (this.frequency === Frequency.Monthly) {
      frequencyStr = 'Monthly';
    } else if (this.frequency === Frequency.Yearly) {
      frequencyStr = 'Annually';
    }

    return frequencyStr;
  }

  public getTimeString(): string {

    const start: Time = this.timeRange.start;
    const end: Time = this.timeRange.end;

    return (end.percent - start.percent === 100) ?
              'All Day' :
              start.get12HourString() + ' - ' + end.get12HourString();
  }

  public load(data: any): EventInfo {

    Object.assign(this, data);

    if (data.dateRange) {
      this.dateRange = new Range<Date>().load(data.dateRange);
    }

    if (data.timeRange) {
      this.timeRange = new Range<Time>().load(data.timeRange);
    }

    return this;
  }

  public equals(event: EventInfo): boolean {

    return event.name === this.name &&

           ((!event.dateRange.start && !this.dateRange.start) ||
           (event.dateRange.start && this.dateRange.start &&
           moment(event.dateRange.start).year(this.dateRange.start.getFullYear()).isSame(moment(this.dateRange.start), 'day'))) &&

           ((!event.dateRange.end && !this.dateRange.end) ||
           (event.dateRange.end && this.dateRange.end &&
           moment(event.dateRange.end).year(this.dateRange.end.getFullYear()).isSame(moment(this.dateRange.end), 'day'))) &&

           ((!event.timeRange.start && !this.timeRange.start) ||
           (event.timeRange.start && this.timeRange.start && event.timeRange.start.percent === this.timeRange.start.percent)) &&

           ((!event.timeRange.end && !this.timeRange.end) ||
           (event.timeRange.end && this.timeRange.end && event.timeRange.end.percent === this.timeRange.end.percent)) &&

           event.frequency === this.frequency &&
           event.anchor === this.anchor;
  }
}
