import { SelectionBase } from './selectionBase.model';

export class Side extends SelectionBase {

  public defaultCount!: number;
  public extraCount!: number;

  public load(data: any): this {

    super.load(data);

    Object.assign(this, data);

    return this;
  }
}
