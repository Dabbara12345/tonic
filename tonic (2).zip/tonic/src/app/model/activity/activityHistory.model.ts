export class UserAction {

  public id: number;
  public userName: string;
  public comment: string;
  public created: string;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
