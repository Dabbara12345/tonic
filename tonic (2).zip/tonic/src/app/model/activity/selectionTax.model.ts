export class SelectionTax {

  public id!: number;
  public name?: string;
  public exempt!: boolean;
  public exemptByDefault!: boolean;
  public taxAmount!: number;
  public taxAmountCash?: number;
  public taxAmountCredit?: number;
  public additionTaxAmount!: number;
  public additionTaxAmountCash?: number;
  public additionTaxAmountCredit?: number;
  public totalAmount!: number;
  public totalAmountCash?: number;
  public totalAmountCredit?: number;
  public paidCredit?: boolean;
  public created!: string;

  public load(data: any): this {

    Object.assign(this, data);

    return this;
  }
}
