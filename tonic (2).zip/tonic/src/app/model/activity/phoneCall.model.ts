export class PhoneCall {

  public id!: string;
  public uri!: string;
  public from!: string;
  public to!: string;
  public elapsed!: number;
  public size!: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
