import { CashInOut } from "src/app/model/activity/cashInOut.model";

export class ForeignCurrencyCashOut {

  public count: number;
  public amount: number;
  public calculatedAmount: number;
  public interimDepositTotal: number;
  public pettyCashTotal: number;
  public tendered: number;
  public adjustmentTendered: number;

  public created: Date;

  public cashInOut: CashInOut;

  public load(data: any): this {
    Object.assign(this, data);

    if(data?.created) {

      this.created = new Date(data.created);

    }

    if(data?.cashInOut) {

      this.cashInOut = new CashInOut().load(data.cashInOut);

    }

    return this;

  }

}
