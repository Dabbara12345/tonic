export class FileStored {

  public bucketName!: string;
  public key!: string;
  public eTag!: string;
  public size!: number;
  public lastModified!: Date;

  public load(data: any): this {
    Object.assign(this, data);

    if (data?.lastModified) {
      this.lastModified = new Date(data.lastModified);
    }

    return this;
  }
}
