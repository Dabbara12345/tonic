import { CashInOut } from "src/app/model/activity/cashInOut.model";

export class OrderTypeSummary {

  public type: number;
  public count: number;
  public closed: number;
  public total: number;
  public tax: number;
  public seats: number;
  public averageItems: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;

  }

}
