
import { Choice } from '../menu/choice.model';
import { Selection } from './selection.model';

export class SelectionChoiceTax {

  public taxAmount!: number;
  public created!: string;
  public updated!: string;
  public selection!: Selection;
  public choice!: Choice;
}
