export class ChangeTax {

  public taxAmount!: number;
  public created!: string;
  public updated!: string;

  public load(data: any): ChangeTax {

    Object.assign(this, data);

    return this;
  }
}
