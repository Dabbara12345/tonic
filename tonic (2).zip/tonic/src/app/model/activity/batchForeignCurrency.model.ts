export class BatchForeignCurrency {

  public code!: string;
  public exchangeRate!: number;

  public load(data: any): BatchForeignCurrency {
    Object.assign(this, data);

    return this;
  }
}
