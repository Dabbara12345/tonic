import { Store } from 'src/app/model/store.model';
import { User } from 'src/app/model/access/user.model';
import { Drawer } from 'src/app/model/equipment/drawer.model';
import { Payment } from 'src/app/model/activity/payment.model';
import { Terminal } from 'src/app/model/equipment/terminal.model';
import { OrderTypeSummary } from 'src/app/model/activity/order-type-summary.model';
import { CashInOutBreakdown } from 'src/app/model/activity/cash-in-out-breakdown.model';
import { ForeignCurrencyCashOut } from 'src/app/model/activity/foreign-currency-cash-out.model';

export class CashInOut {

  public id!: number;
  public batchNumber!: number;
  public cashInAmount!: number;
  public interimDepositTotal!: number;
  public pettyCashTotal!: number;
  public cashInDate!: string;
  public calculatedCashOutAmount!: number;
  public cashOutCount!: number;
  public cashOutAmount!: number;
  public cashOutDate!: string;
  public cashSubTotal?: number;

  public cashGratuity: number;
  public cashGratuityInCashDrawer: number;
  public cashTip: number;
  public cashTipInCashDrawer: number;
  public nonCashSubTotal: number;
  public nonCashSurcharge: number;
  public nonCashGratuity: number;
  public nonCashTip: number;
  public nonCashDiscountAmount: number;
  public creditSubTotal: number;
  public creditSurcharge: number;
  public creditGratuity: number;
  public creditTip: number;
  public creditDiscountAmount: number;
  public extCreditSubTotal: number;
  public extCreditSurcharge: number;
  public extCreditGratuity: number;
  public extCreditTip: number;
  public extCreditDiscountAmount: number;
  public debitSubTotal: number;
  public debitGratuity: number;
  public debitTip: number;
  public debitDiscountAmount: number;
  public extDebitSubTotal: number;
  public extDebitGratuity: number;
  public extDebitTip: number;
  public extDebitDiscountAmount: number;
  public couponSubTotal: number;
  public couponGratuity: number;
  public couponTip: number;
  public checkSubTotal: number;
  public checkGratuity: number;
  public checkTip: number;
  public giftSubTotal: number;
  public giftGratuity: number;
  public giftTip: number;
  public extGiftSubTotal: number;
  public extGiftGratuity: number;
  public extGiftTip: number;
  public billSubTotal: number;
  public billGratuity: number;
  public billTip: number;
  public roomChargeSubTotal: number;
  public roomChargeGratuity: number;
  public roomChargeTip: number;
  public onlineCreditSubTotal: number;
  public onlineCreditSurcharge: number;
  public onlineCreditGratuity: number;
  public onlineCreditTip: number;
  public onlineCreditDiscountAmount: number;
  public playCardSubTotal: number;
  public playCardGratuity: number;
  public playCardTip: number;
  public otherSubTotal: number;
  public otherGratuity: number;
  public otherTip: number;
  public gratuityTaxAmount: number;
  public deliveryCharges: number;
  public adjustmentCashSubTotal: number;
  public adjustmentCashGratuity: number;
  public adjustmentCashGratuityInCashDrawer: number;
  public adjustmentCashTip: number;
  public adjustmentCashTipInCashDrawer: number;
  public adjustmentNonCashSubTotal: number;
  public adjustmentNonCashSurchage: number;
  public adjustmentNonCashGratuity: number;
  public adjustmentNonCashTip: number;
  public adjustmentNonCashDiscountAmount: number;
  public adjustmentCreditSubTotal: number;
  public adjustmentCreditSurcharge: number;
  public adjustmentCreditGratuity: number;
  public adjustmentCreditTip: number;
  public adjustmentCreditDiscountAmount: number;
  public adjustmentExtCreditSubTotal: number;
  public adjustmentExtCreditSurcharge: number;
  public adjustmentExtCreditGratuity: number;
  public adjustmentExtCreditTip: number;
  public adjustmentExtCreditDiscountAmount: number;
  public adjustmentDebitSubTotal: number;
  public adjustmentDebitGratuity: number;
  public adjustmentDebitTip: number;
  public adjustmentDebitDiscountAmount: number;
  public adjustmentExtDebitSubTotal: number;
  public adjustmentExtDebitGratuity: number;
  public adjustmentExtDebitTip: number;
  public adjustmentExtDebitDiscountAmount: number;
  public adjustmentCouponSubTotal: number;
  public adjustmentCouponGratuity: number;
  public adjustmentCouponTip: number;
  public adjustmentCheckSubTotal: number;
  public adjustmentCheckGratuity: number;
  public adjustmentCheckTip: number;
  public adjustmentGiftSubTotal: number;
  public adjustmentGiftGratuity: number;
  public adjustmentGiftTip: number;
  public adjustmentExtGiftSubTotal: number;
  public adjustmentExtGiftGratuity: number;
  public adjustmentExtGiftTip: number;
  public adjustmentBillSubTotal: number;
  public adjustmentBillGratuity: number;
  public adjustmentBillTip: number;
  public adjustmentRoomChargeSubTotal: number;
  public adjustmentRoomChargeGratuity: number;
  public adjustmentRoomChargeTip: number;
  public adjustmentOnlineCreditSubTotal: number;
  public adjustmentOnlineCreditSurcharge: number;
  public adjustmentOnlineCreditGratuity: number;
  public adjustmentOnlineCreditTip: number;
  public adjustmentOnlineCreditDiscountAmount: number;
  public adjustmentPlayCardSubTotal: number;
  public adjustmentPlayCardGratuity: number;
  public adjustmentPlayCardTip: number;
  public adjustmentOtherSubTotal: number;
  public adjustmentOtherGratuity: number;
  public adjustmentOtherTip: number;
  public adjustmentGratuityTaxAmount: number;
  public adjustmentDeliveryCharges: number;
  public selectionCreatorCashSubTotal: number;
  public selectionCreatorCashGratuity: number;
  public selectionCreatorCashGratuityInCashDrawer: number;
  public selectionCreatorCashTip: number;
  public selectionCreatorCashTipInCashDrawer: number;
  public selectionCreatorNonCashSubTotal: number;
  public selectionCreatorNonCashSurcharge: number;
  public selectionCreatorNonCashGratuity: number;
  public selectionCreatorNonCashTip: number;
  public selectionCreatorNonCashDiscountAmount: number;
  public selectionCreatorCreditSubTotal: number;
  public selectionCreatorCreditSurcharge: number;
  public selectionCreatorCreditGratuity: number;
  public selectionCreatorCreditTip: number;
  public selectionCreatorCreditDiscountAmount: number;
  public selectionCreatorExtCreditSubTotal: number;
  public selectionCreatorExtCreditSurcharge: number;
  public selectionCreatorExtCreditGratuity: number;
  public selectionCreatorExtCreditTip: number;
  public selectionCreatorExtCreditDiscountAmount: number;
  public selectionCreatorDebitSubTotal: number;
  public selectionCreatorDebitGratuity: number;
  public selectionCreatorDebitTip: number;
  public selectionCreatorDebitDiscountAmount: number;
  public selectionCreatorExtDebitSubTotal: number;
  public selectionCreatorExtDebitGratuity: number;
  public selectionCreatorExtDebitTip: number;
  public selectionCreatorExtDebitDiscountAmount: number;
  public selectionCreatorCouponSubTotal: number;
  public selectionCreatorCouponGratuity: number;
  public selectionCreatorCouponTip: number;
  public selectionCreatorCheckSubTotal: number;
  public selectionCreatorCheckGratuity: number;
  public selectionCreatorCheckTip: number;
  public selectionCreatorGiftSubTotal: number;
  public selectionCreatorGiftGratuity: number;
  public selectionCreatorGiftTip: number;
  public selectionCreatorExtGiftSubTotal: number;
  public selectionCreatorExtGiftGratuity: number;
  public selectionCreatorExtGiftTip: number;
  public selectionCreatorBillSubTotal: number;
  public selectionCreatorBillGratuity: number;
  public selectionCreatorBillTip: number;
  public selectionCreatorRoomChargeSubTotal: number;
  public selectionCreatorRoomChargeGratuity: number;
  public selectionCreatorRoomChargeTip: number;
  public selectionCreatorOnlineCreditSubTotal: number;
  public selectionCreatorOnlineCreditSurcharge: number;
  public selectionCreatorOnlineCreditGratuity: number;
  public selectionCreatorOnlineCreditTip: number;
  public selectionCreatorOnlineCreditDiscountAmount: number;
  public selectionCreatorPlayCardSubTotal: number;
  public selectionCreatorPlayCardGratuity: number;
  public selectionCreatorPlayCardTip: number;
  public selectionCreatorOtherSubTotal: number;
  public selectionCreatorOtherGratuity: number;
  public selectionCreatorOtherTip: number;
  public selectionCreatorGratuityTaxAmount: number;
  public selectionCreatorDeliveryCharges: number;
  public selectionCreatorCalculatedCashOutAmount: number;
  public selectionCreatorAdjustmentCashSubTotal: number;
  public selectionCreatorAdjustmentCashGratuity: number;
  public selectionCreatorAdjustmentCashGratuityInCashDrawer: number;
  public selectionCreatorAdjustmentCashTip: number;
  public selectionCreatorAdjustmentCashTipInCashDrawer: number;
  public selectionCreatorAdjustmentNonCashSubTotal: number;
  public selectionCreatorAdjustmentNonCashSurcharge: number;
  public selectionCreatorAdjustmentNonCashGratuity: number;
  public selectionCreatorAdjustmentNonCashTip: number;
  public selectionCreatorAdjustmentNonCashDiscountAmount: number;
  public selectionCreatorAdjustmentCreditSubTotal: number;
  public selectionCreatorAdjustmentCreditSurcharge: number;
  public selectionCreatorAdjustmentCreditGratuity: number;
  public selectionCreatorAdjustmentCreditTip: number;
  public selectionCreatorAdjustmentCreditDiscountAmount: number;
  public selectionCreatorAdjustmentExtCreditSubTotal: number;
  public selectionCreatorAdjustmentExtCreditSurcharge: number;
  public selectionCreatorAdjustmentExtCreditGratuity: number;
  public selectionCreatorAdjustmentExtCreditTip: number;
  public selectionCreatorAdjustmentExtCreditDiscountAmount: number;
  public selectionCreatorAdjustmentDebitSubTotal: number;
  public selectionCreatorAdjustmentDebitGratuity: number;
  public selectionCreatorAdjustmentDebitTip: number;
  public selectionCreatorAdjustmentDebitDiscountAmount: number;
  public selectionCreatorAdjustmentExtDebitSubTotal: number;
  public selectionCreatorAdjustmentExtDebitGratuity: number;
  public selectionCreatorAdjustmentExtDebitTip: number;
  public selectionCreatorAdjustmentExtDebitDiscountAmount: number;
  public selectionCreatorAdjustmentCouponSubTotal: number;
  public selectionCreatorAdjustmentCouponGratuity: number;
  public selectionCreatorAdjustmentCouponTip: number;
  public selectionCreatorAdjustmentCheckSubTotal: number;
  public selectionCreatorAdjustmentCheckGratuity: number;
  public selectionCreatorAdjustmentCheckTip: number;
  public selectionCreatorAdjustmentGiftSubTotal: number;
  public selectionCreatorAdjustmentGiftGratuity: number;
  public selectionCreatorAdjustmentGiftTip: number;
  public selectionCreatorAdjustmentExtGiftSubTotal: number;
  public selectionCreatorAdjustmentExtGiftGratuity: number;
  public selectionCreatorAdjustmentExtGiftTip: number;
  public selectionCreatorAdjustmentBillSubTotal: number;
  public selectionCreatorAdjustmentBillGratuity: number;
  public selectionCreatorAdjustmentBillTip: number;
  public selectionCreatorAdjustmentRoomChargeSubTotal: number;
  public selectionCreatorAdjustmentRoomChargeGratuity: number;
  public selectionCreatorAdjustmentRoomChargeTip: number;
  public selectionCreatorAdjustmentOnlineCreditSubTotal: number;
  public selectionCreatorAdjustmentOnlineCreditSurcharge: number;
  public selectionCreatorAdjustmentOnlineCreditGratuity: number;
  public selectionCreatorAdjustmentOnlineCreditTip: number;
  public selectionCreatorAdjustmentOnlineCreditDiscountAmount: number;
  public selectionCreatorAdjustmentPlayCardSubTotal: number;
  public selectionCreatorAdjustmentPlayCardGratuity: number;
  public selectionCreatorAdjustmentPlayCardTip: number;
  public selectionCreatorAdjustmentOtherSubTotal: number;
  public selectionCreatorAdjustmentOtherGratuity: number;
  public selectionCreatorAdjustmentOtherTip: number;
  public selectionCreatorAdjustmentGratuityTaxAmount: number;
  public selectionCreatorAdjustmentDeliveryCharges: number;

  public paymentsByOrderCreator!: boolean;
  public gratuityAndTipBySelectionCreator!: boolean;

  public tipPoolName: string;
  public tipPoolRemoteId: string;
  public tipPoolCashTipTotal!: boolean;
  public tipPoolWeight: number;
  public tipPoolTimeBased!: boolean;
  public tipPoolTimeBasedGroup!: string;
  public creditCardDiscountRate!: number;
  public onlineCreditCardDiscountRate!: number;
  public debitCardDiscountRate!: number;
  public currencyCode!: string;
  public roundCashDue!: boolean;
  public attendanceRemoteId: string;

  public created: Date;
  public updated: Date;

  public storeId: number;
  public drawerId: number;

  public store!: Store;
  public cashInTerminal: Terminal;
  public cashInForcedBy: User;
  public cashOutTerminal: Terminal;
  public cashOutForcedBy: User;

  public drawer?: Drawer;
  public user?: User;

  public payments: Array<Payment> = new Array<Payment>();
  public breakdowns: Array<CashInOutBreakdown>;
  public foreignCurrencies: Array<ForeignCurrencyCashOut>;
  public orderTypeSummaries: Array<OrderTypeSummary>;

  public load(data: any): CashInOut {
    Object.assign(this, data);

    if (data.created) {
      this.created = new Date(data.created);
    }

    if (data.updated) {
      this.updated = new Date(data.updated);
    }

    if (data.store) {
      this.store = new Store().load(data.store);
    }

    if (data.cashInTerminal) {
      this.cashInTerminal = new Terminal().load(data.cashInTerminal);
    }

    if (data.cashInForcedBy) {
      this.cashInForcedBy = new User().load(data.cashInForcedBy);
    }

    if (data.cashOutTerminal) {
      this.cashOutTerminal = new Terminal().load(data.cashOutTerminal);
    }

    if (data.cashOutForcedBy) {
      this.cashOutForcedBy = new User().load(data.cashOutForcedBy);
    }

    if (data.drawer) {
      this.drawer = new Drawer().load(data.drawer);
    }

    if (data.user) {
      this.user = new User().load(data.user);
    }

    this.payments = new Array<Payment>();

    data?.payments
        ?.forEach((p: Payment): void => {

          this.payments
              .push(new Payment().load(p));
        });

    this.breakdowns = new Array<CashInOutBreakdown>();

    data?.breakdowns
        ?.forEach((c: CashInOutBreakdown): void => {

          this.breakdowns
              .push(new CashInOutBreakdown().load(c));
        });

    this.foreignCurrencies = new Array<ForeignCurrencyCashOut>();

    data?.foreignCurrencies
        ?.forEach((f: ForeignCurrencyCashOut): void => {

          this.foreignCurrencies
              .push(new ForeignCurrencyCashOut().load(f));
        });

    this.orderTypeSummaries = new Array<OrderTypeSummary>();

    data?.orderTypeSummaries
        ?.forEach((o: OrderTypeSummary): void => {

          this.orderTypeSummaries
              .push(new OrderTypeSummary().load(o));
        });

    return this;
  }

  public get name(): string {
    let name: string = '';

    if (this.isDrawer()) {
      name = this.drawer.name;
    } else {
      name = 'Server';
    }

    return name;
  }

  public hasDifference(): boolean {
    return this.cashOutAmount !== this.calculatedCashOutAmount;
  }

  public isExact(): boolean {
    return this.cashOutAmount === this.calculatedCashOutAmount;
  }

  public isUnder(): boolean {
    return this.cashOutAmount < this.calculatedCashOutAmount;
  }

  public isOver(): boolean {
    return this.cashOutAmount > this.calculatedCashOutAmount;
  }

  public difference(): number {
    return this.calculatedCashOutAmount - this.cashOutAmount;
  }

  public isDrawer(): boolean {
    return this.drawer !== undefined;
  }
}
