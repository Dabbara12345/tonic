import { User } from '../access/user.model';

export class Article{

  public articleId!: number;
  public name!: string;
  public description!: string;
  public link!: string;

  public submitter!: User;
  public approver!: User;

  public created!: string;
  public published!: string;
  public approved!: string;

  public load(data: any): Article {

    Object.assign(this, data);

    if (data.submitter){
      this.submitter = new User().load(data.submitter);
    }

    if (data.approver){
      this.approver = new User().load(data.approver);
    }

    return this;
  }
}
