import { NameValue } from '../utils/nameValue.model';

export class Alert {

  public id?: number;
  public storeId?: number;
  public userId?: number;
  public type!: string;
  public name!: string;
  public sms?: string;
  public mailTo?: string;
  public disabled?: string;

  public settings?: Array<NameValue>;

  public load(data: any): Alert {

    this.init(data);

    data?.settings
        ?.forEach((nV: NameValue): void => {

      this.settings
          .push(new NameValue().load(nV));
    });

    return this;
  }

  private init(data: any): void {
    Object.keys(this)
          .forEach(key => delete this[key]);

    Object.assign(this, data);

    this.settings = new Array(); 
  }
}
