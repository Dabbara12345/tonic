import { User } from '../access/user.model';

export class Recipient {

  public recipientId!: number;
  public user!: User;

  public load(data: any): Recipient {

    Object.assign(this.load, data);

    return this;
  }
}
