import { Acceptance } from './acceptance.model';

export class Agreement {

  public id?: number;

  public name?: string;
  public description?: string;
  public mimeType?: string;
  public text!: string;
  public data!: any[];
  public button!: string;

  public disabled?: Date;
  public created?: Date;
  public updated?: Date;

  public acceptances?: Array<Acceptance>;

  public load(data: any): this {

    Object.assign(this, data);

    this.acceptances = new Array<Acceptance>();

    data?.acceptances
        ?.forEach((a: Acceptance): void => {

      this.acceptances
          .push(new Acceptance().load(a));
    });

    return this;
  }
}
