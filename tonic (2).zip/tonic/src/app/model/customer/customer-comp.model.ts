export class CustomerComp {

  public storeId?: number;
  public id?: number;

  public load(data: any): CustomerComp {

    Object.assign(this, data);

    return this;
  }
}
