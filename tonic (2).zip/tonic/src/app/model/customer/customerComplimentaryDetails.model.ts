export class CustomerComplimentaryDetails {
  public date: string;
  public orderId: number;
  public name: string;
  public seats: number;
  public item: string;
  public server: string;
  public reason: string;
  public comments: string;
  public authorize: string;
  public qty: number;
  public amount: number;
  public total: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
