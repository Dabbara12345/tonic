import { Payment } from "../activity/payment.model";

export class BillReconciled {

  public amount:          number;
  public reconciledById:  number;

  public reconciled!:     Date;
  public created!:        Date;
  public updated!:        Date;

  public payment:         Payment;

  public load(data: any): this {

    Object.assign(this, data);

    if(data?.reconciled) {
      this.reconciled = new Date(data.reconciled);
    }

    if(data?.created) {
      this.created = new Date(data.created);
    }

    if(data?.updated) {
      this.updated = new Date(data.updated);
    }

    if(data?.payment) {
      this.payment = new Payment().load(data.payment);
    }

    return this;
  }
}
