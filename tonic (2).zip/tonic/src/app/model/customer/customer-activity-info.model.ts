export class CustomerActivityInfo {

  public customerName:  string;
  public TZ:            string;
  public actionText:    string;

  public customerId:    number;
  public action:        number;
  public oldBalance:    number;
  public newBalance:    number;
  public amount:        number;
  public refId:         number;
  public depositId:     number;

  public created:       Date;

  public load(data: any): CustomerActivityInfo {

    Object.assign(this, data);

    if(data?.created){
      this.created = new Date(data.created);
    }

    return this;
  }
}
