export class ChoicesCount {

  public groupName: string;
  public preparationName: string;
  public selectionName: string;
  public areaName: string;
  public orderedBy: string;

  public quantity: number;
  public multiplier: number;

  public load(data: any): ChoicesCount {
    Object.assign(this, data);

    return this;
  }
}
