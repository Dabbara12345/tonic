import { HttpParams } from '@angular/common/http';

import { AnalyticOrderReport } from "../reportPaths/analyticOrderReport";
import { OrderDetails } from 'src/app/model/analytics/order/orderDetails.model';

export class OrderDetailsReport extends AnalyticOrderReport {

  public value: Array<OrderDetails>;

  public uri(): string {
    return super.uri() + '/details';
  }
}
