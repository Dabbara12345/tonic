export class SidesCount {

  public name: string;
  public groupName: string;
  public sideName: string;
  public areaName: string;

  public quantity: number;
  public orderedById: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
