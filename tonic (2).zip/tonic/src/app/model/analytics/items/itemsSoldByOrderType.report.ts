import { AnalyticSelectionReport } from '../reportPaths/analyticSelectionReport';
import { ItemsSold } from './itemsSold.model';

export class ItemsSoldByOrderTypeReport extends AnalyticSelectionReport {
  public value: Array<ItemsSold>;
}
