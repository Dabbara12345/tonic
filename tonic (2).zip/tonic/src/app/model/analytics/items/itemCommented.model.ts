export class ItemsCommented {

  public created: Date;
  public orderName: string;
  public id: number;
  public server: string;
  public type: string;
  public item: string;
  public comment: string;

  public load(data: any): ItemsCommented {

    Object.assign(this, data);

    return this;
  }

}
