import { SidesReport } from '../reportPaths/sidesReport';
import { SidesCount } from './sidesCount.model';

export class SidesSoldByItemReport extends SidesReport {

  public value: Array<SidesCount>;

}
