import { TaxExempt } from 'src/app/model/analytics/items/taxExempt.model';
import { SelectionReport } from 'src/app/model/analytics/reportPaths/selectionReport';

export class TaxExemptReport extends SelectionReport {

  public value: Array<TaxExempt>;

  public uri(): string {
    return super.uri() + '/exemptOrder';
  }

}
