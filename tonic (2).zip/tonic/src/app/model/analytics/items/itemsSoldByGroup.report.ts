import { AnalyticSelectionReport } from '../reportPaths/analyticSelectionReport';
import { ItemsSold } from './itemsSold.model';

export class ItemsSoldByGroupReport extends AnalyticSelectionReport {

  public value: Array<ItemsSold>;
}
