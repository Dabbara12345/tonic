import { AnalyticSelectionReport } from '../reportPaths/analyticSelectionReport';
import { ItemsSold } from './itemsSold.model';

export class ItemsSoldReport extends AnalyticSelectionReport {
  public value: Array<ItemsSold>;
}
