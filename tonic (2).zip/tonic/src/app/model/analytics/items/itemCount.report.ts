import { HttpParams } from '@angular/common/http';
import { AnalyticSelectionReport } from '../reportPaths/analyticSelectionReport';
import { ItemsSold } from './itemsSold.model';

export class ItemCountReport extends AnalyticSelectionReport {

  public value: Array<ItemsSold>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('count', true);

    return params;
  }
}
