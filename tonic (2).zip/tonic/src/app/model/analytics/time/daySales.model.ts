export class DaySales {

  public day: number;
  public quantity: number;
  public guests: number;
  public gross: number;
  public tax: number;
  public net: number;

  public load(data: any): DaySales {
    Object.assign(this, data);

    return this;
  }
}
