import { NameValue } from '../../utils/nameValue.model';
import { DaySales } from './daySales.model';

export class Shift {

  public id: number;
  public name: string;
  public start: number;
  public end: number;
  public details: Map<number, DaySales>;
  public totals: DaySales;

  public load(data: any): Shift {
    Object.assign(this, data);

    return this;
  }
}
