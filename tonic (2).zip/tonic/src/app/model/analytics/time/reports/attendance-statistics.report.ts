import { Criteria } from "../../criteria.model";
import { AdminReport } from "../../admin-report.model";
import { AttendanceReport } from "../attendanceReport.model";
import { AttendanceDetails } from "src/app/model/vas/attendance-details.model";
import { AttendanceAverages } from "src/app/model/vas/attendance-averages.model";
import { TimeAttendanceReportService } from '../../../../service/vas/time/time-attendance-report.service';

export class AttendanceStatisticsReport extends AttendanceReport {
  public value: Array<AttendanceDetails>;

  private timeAttendanceReportService: TimeAttendanceReportService

  constructor() {
    super();
    this.criteria = new Criteria();
  }

  public load(data: AdminReport): this {
    Object.assign(this, data);

    this.value = data.value;

    return this;
  }

  public setTimeAttendanceService(timeAttendanceReportService?: TimeAttendanceReportService): void {
    this.timeAttendanceReportService = timeAttendanceReportService;
  }

  public conciseData(): Array<AttendanceAverages> {
    let avgsData = new Array<AttendanceAverages>();
    console.log('MAPPED DATA', this.timeAttendanceReportService.mapOutData(this.value));

    for (let entry of this.timeAttendanceReportService
                          .mapOutData(this.value)) {
      let averageData = new AttendanceAverages();

      averageData.firstName = entry[1][0].firstName;
      averageData.lastName = entry[1][0].lastName;
      averageData.shifts = entry[1].length;
      averageData.avg_hours = this.calcSumFor('hours', entry[1])/averageData.shifts;
      averageData.avg_tip_out = this.calcSumFor('tipOut', entry[1])/averageData.shifts;
      averageData.avg_cash_tips = this.calcSumFor('cashTips', entry[1])/averageData.shifts;
      averageData.avg_non_cash_tips = this.calcSumFor('nonCashTips', entry[1])/averageData.shifts;
      averageData.avg_reported_tip_total = this.calcSumFor('reportedTipTotal', entry[1])/averageData.shifts;

      avgsData.push(averageData);

    }

    return avgsData;
  }

  private calcSumFor(property: string,
                        attendances: Array<AttendanceDetails>): number {
    let sum = 0;

    attendances.forEach(a => {
      switch (property) {
        case 'reportedTipTotal':
          sum += this.timeAttendanceReportService
                     .calculateReportedTip(a);
          break;
        case 'hours':
          if (a.userAttendance
               .payroll
               .hours !== undefined || a.userAttendance
                                        .payroll
                                        .hours === 0) {
            sum += a.userAttendance
                   .payroll
                   .hours;
          }
          break;
        case 'cashTips':
          sum += (a.userAttendance
                             .cashTips !== undefined ? a.userAttendance
                                                                 .cashTips
                                                     : 0);
          break;
        default:
          if (a.userAttendance[property] !== undefined) {
            sum += a.userAttendance[property];
          }
          break;
      }

    });

    return sum;
  }
}
