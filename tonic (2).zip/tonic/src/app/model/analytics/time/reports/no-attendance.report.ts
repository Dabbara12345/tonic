import { Criteria } from "../../criteria.model";
import { AdminReport } from "../../admin-report.model";
import { AttendanceReport } from "../attendanceReport.model";
import { TimeAttendanceReportService } from '../../../../service/vas/time/time-attendance-report.service';
import { User } from "src/app/model/access/user.model";

export class NoAttendanceReport extends AttendanceReport {
  public value: Array<User>;

  private timeAttendanceReportService: TimeAttendanceReportService

  constructor() {
    super();
    this.criteria = new Criteria();
  }

  public uri(): string {
    return super.uri() +'/noAttendance';
  }

  public load(data: AdminReport): this {
    Object.assign(this, data);

    this.value = data.value;

    return this;
  }

  public setTimeAttendanceService(timeAttendanceReportService?: TimeAttendanceReportService): void {
    this.timeAttendanceReportService = timeAttendanceReportService;
  }

}
