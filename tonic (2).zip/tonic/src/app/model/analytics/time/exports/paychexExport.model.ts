import { AttendanceDetails } from "../../../vas/attendance-details.model";
import { AttendanceReport } from "../attendanceReport.model";

export class PaychexExport extends AttendanceReport {

  public value: Array<AttendanceDetails>;

}
