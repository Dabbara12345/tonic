import { AttendanceDetails } from "../../../vas/attendance-details.model";
import { AttendanceReport } from "../attendanceReport.model";

export class PaymasterExport extends AttendanceReport {

  public value: Array<AttendanceDetails>;

}
