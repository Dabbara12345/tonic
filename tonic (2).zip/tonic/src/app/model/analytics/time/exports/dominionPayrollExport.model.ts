import { AttendanceDetails } from "../../../vas/attendance-details.model";
import { AttendanceReport } from "../attendanceReport.model";

export class DominionPayrollExport extends AttendanceReport {

  public value: Array<AttendanceDetails>;

}
