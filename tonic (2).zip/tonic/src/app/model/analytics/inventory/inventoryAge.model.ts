export class InventoryAge {

  public ingredient:  string;
  public recieved:    string;
  public used:        string;
  public available:   string;

  public date:        Date;

  public load(data: any): this {
    Object.assign(this, data);

    if (data?.date) {
      this.date = new Date(this.date);
    }

    return this;
  }
}
