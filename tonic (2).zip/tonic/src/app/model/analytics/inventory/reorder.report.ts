import { Reorder } from "./reorder.model";
import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";

export class ReorderReport extends AnalyticInventoryReport {

  public value: Array<Reorder>;

  public uri(): string {
    return super.uri() + '/reorder';
  }

}
