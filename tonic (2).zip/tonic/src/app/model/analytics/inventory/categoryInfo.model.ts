export class CategoryInfo {

  public name: string;
  public cost: number;
  public type: number;

  public load(data: any): CategoryInfo {
    Object.assign(this, data);

    return this;
  }
}
