export class PurchaseOrdersAnalytic {

  public poNum:       string;
  public vendor:      string;

  public ingredients: number;
  public other:       number;
  public total:       number;

  public ordered:     Date;
  public promised:    Date;
  public recieved:    Date;

  public load(data: any): this {
    Object.assign(this, data);

    if (data?.ordered) {
      this.ordered = new Date(this.ordered);
    }

    if (data?.promised) {
      this.promised = new Date(this.promised);
    }

    if (data?.recieved) {
      this.recieved = new Date(this.recieved);
    }

    return this;
  }
}
