import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { InTransit } from "./inTransit.model";

export class InTransitReport extends AnalyticInventoryReport {

  public value: Array<InTransit>;

  public uri(): string {
    return super.uri() + '/inTransit';
  }
}
