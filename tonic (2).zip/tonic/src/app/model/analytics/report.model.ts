import { Header } from './header.model';

export class Report {

  public header: Header;
  public filters: Map<string, string>;
  public data: Array<any>;

  public load(data: any): Report {

    Object.assign(this, data);

    if (data.filters){
      this.filters = new Map(Object.entries(data.filters));
    }

    if (data.header){
      this.header = new Header().load(data.header);
    }

    return this;
  }
}
