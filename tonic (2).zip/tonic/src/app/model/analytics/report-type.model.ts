import { HttpParams } from "@angular/common/http";
import { DataComparison } from "./data-comparison";

export interface ReportType {

  uri(): string;
  params(): HttpParams;
  compare(previous: this): Array<DataComparison>;
}
