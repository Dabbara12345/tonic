import { ItemsSold } from 'src/app/model/analytics/items/itemsSold.model';
import { AnalyticSelectionReport } from 'src/app/model/analytics/reportPaths/analyticSelectionReport';

export class FutureOrdersItemsOrderedReport extends AnalyticSelectionReport {
  public value: Array<ItemsSold>;


  public uri(): string {
    return super.uri() + '/future';
  }
}
