import { FutureOrderIngredient } from "src/app/model/analytics/future-orders/future-order-ingredient.model";
import { AnalyticInventoryReport } from "src/app/model/analytics/reportPaths/analyticInventoryReport";

export class FutureOrdersQuantityChangesReport extends AnalyticInventoryReport {

  public value: Array<FutureOrderIngredient>;

  public uri(): string {
    return super.uri() + '/futureQuantityChange';
  }
}
