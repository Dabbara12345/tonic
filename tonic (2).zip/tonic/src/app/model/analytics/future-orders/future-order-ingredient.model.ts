import { Ingredient } from "src/app/model/inventory/ingredient.model";
import { MeasurementUnit } from "src/app/model/inventory/measurementUnit.model";

export class FutureOrderIngredient {

  public quantity: number;
  public unitPrice: number;

  public ingredient: Ingredient;
  public measurement: MeasurementUnit;

  public load(data: any): this {

    Object.assign(this, data);

    if (data?.ingredient) {

      this.ingredient = new Ingredient().load(data.ingredient);

    }

    if (data?.measurement) {

      this.measurement = new MeasurementUnit().load(data.measurement);

    }

    return this;

  }

}
