import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';
import { SalesByGroupByDay } from './salesByGroupByDay.model';

export class SalesByGroupDailyReport extends AnalyticSalesReport {

  public value: Array<SalesByGroupByDay>;

  public uri(): string {
    return super.uri() + '/salesByGroupByDay';
  }
}
