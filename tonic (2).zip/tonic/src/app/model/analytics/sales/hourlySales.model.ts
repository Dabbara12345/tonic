export class HourlySales {

  public hour: number;
  public date: string;
  public orders: number;
  public seats: number;
  public items: number;
  public amount: number;
  public comp: number;
  public total: number;
  public subTotal: number;
  public discTotal: number;
  public gratuityTip: number;

  public load(data: any): HourlySales {

    Object.assign(this, data);

    return this;
  }
}
