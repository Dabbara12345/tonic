import { HttpParams } from '@angular/common/http';
import { SalesByArea } from './salesByArea.model';

import { AnalyticSalesReport } from 'src/app/model/analytics/reportPaths/analyticSalesReport';

export class SalesByAreaReport extends AnalyticSalesReport {

  public value: Array<SalesByArea[]>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('salesByArea', true);
    params = params.append('salesByAreaTax', true);
    params = params.append('salesByAreaTip', true);

    return params;

  }

}
