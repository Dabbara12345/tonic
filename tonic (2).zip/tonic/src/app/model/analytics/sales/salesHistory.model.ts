export class SalesHistory {
  public opened: string;
  public closed: string;
  public openedBy: string;
  public closedBy: string;
  public count: number = 0;
  public gross: number = 0;
  public tax: number = 0;
  public net: number = 0;
  public mealTime?: string;
  public cashIn: number = 0;
  public cashOut: number = 0;
  public expected: number = 0;
  public overShort: number = 0;
  public hours: number = 0;
  public weekday: string = '';
  public byMealTime?: Map<string, SalesHistory> = new Map();
}
