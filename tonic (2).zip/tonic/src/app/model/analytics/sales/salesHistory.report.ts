import { HttpParams } from '@angular/common/http';
import { SalesHistory } from './salesHistory.model';
import { AnalyticBatchReport } from '../reportPaths/analyticBatchReport';

export class SalesHistoryReport extends AnalyticBatchReport {

  public value: Array<SalesHistory>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('salesHistory', true);

    return params;
  }
}
