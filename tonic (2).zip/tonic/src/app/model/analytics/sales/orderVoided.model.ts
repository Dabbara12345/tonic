export class OrderVoided {

  public voidedBy: string;
  public forcedBy: string;
  public price: number;
  public quantity: number;

  public load(data: any): OrderVoided {

    Object.assign(this,
                    data);

    return this;

  }

}
