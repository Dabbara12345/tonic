import { SalesByArea } from "src/app/model/analytics/sales/salesByArea.model";
import { OrderVoided } from "src/app/model/analytics/sales/orderVoided.model";
import { SalesByGroup } from "src/app/model/analytics/sales/salesByGroup.model";

export class DailySummary {

  public salesByGroup: Array<SalesByGroup>;
  public taxes: Array<SalesByGroup>;
  public salesByArea: Array<SalesByArea>;
  public voided: Array<OrderVoided>;

  public load(data: any): DailySummary {

    Object.assign(this,
                    data);

    this.salesByGroup = new Array<SalesByGroup>();

    data?.salesByGroup
        ?.forEach((g: SalesByGroup): void => {

          this.salesByGroup
              .push(new SalesByGroup().load(g));
      });

    this.taxes = new Array<SalesByGroup>();

    data?.taxes
        ?.forEach((t: SalesByGroup): void => {

          this.taxes
              .push(new SalesByGroup().load(t));
      });

    this.salesByArea = new Array<SalesByArea>();

    data?.salesByArea
        ?.forEach((a: SalesByArea): void => {

          this.salesByArea
              .push(new SalesByArea().load(a));
      });

    this.voided = new Array<OrderVoided>();

    data?.voided
        ?.forEach((v: OrderVoided): void => {

          this.voided
              .push(new OrderVoided().load(v));
      });

    return this;

  }

}
