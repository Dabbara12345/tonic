import { Store } from "../../store.model";

export class StoresNotClosed {

  public onlineTerminals:   number;
  public offlineTerminals:  number;
  public totalTerminals:    number;

  public lastLogin:         Date;

  public store:             Store;

  public load(data: any): StoresNotClosed {

    Object.assign(this, data);

    if (data?.lastLogin) {
      this.lastLogin = new Date(this.lastLogin);
    }

    if (data?.store) {
      this.store = new Store().load(this.store);
    }

    return this;
  }
}
