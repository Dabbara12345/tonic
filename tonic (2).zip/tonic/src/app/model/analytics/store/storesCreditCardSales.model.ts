export class StoresCreditCardSales {

  public storeId: number;
  public count:   number;
  public total:   number;

  public name:    string;
  public date:    string;

  public load(data: any): StoresCreditCardSales {
    Object.assign(this, data);

    return this;
  }
}
