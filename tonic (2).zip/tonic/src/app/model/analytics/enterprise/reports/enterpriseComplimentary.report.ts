import { EnterpriseReport } from "../enterpriseReport.model";

export class EnterpriseComplimentary extends EnterpriseReport {

  public value: Array<any>;

  public uri(): string {
    return super.uri() + '/complimentary';
  }
}
