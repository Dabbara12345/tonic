import { EnterpriseReport } from "../enterpriseReport.model";

export class EnterpriseCustomerPromotionEnrollment extends EnterpriseReport {

  public value: Array<any>;

  public uri(): string {
    return super.uri() + '/promotionEnrollmentDetails';
  }
}
