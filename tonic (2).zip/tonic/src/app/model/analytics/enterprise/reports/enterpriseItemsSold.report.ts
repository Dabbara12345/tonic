import { Store } from "src/app/model/store.model";
import { ItemsSold } from "../../items/itemsSold.model";
import { EnterpriseReport } from "../enterpriseReport.model";

export class EnterpriseItemsSold extends EnterpriseReport {

  public value: Map<any, Array<ItemsSold>>;//TODO TYPE OF Map<Store, List<ItemSold>>????

  public uri(): string {
    return super.uri() + '/' + this.enterpriseId + '/itemsSold';
  }
}
