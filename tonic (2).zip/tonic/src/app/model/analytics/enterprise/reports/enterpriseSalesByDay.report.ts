import { EnterpriseReport } from "../enterpriseReport.model";

export class EnterpriseSalesByDay extends EnterpriseReport {

  public value: Array<any>;

  public uri(): string {
    return super.uri() + '/salesByDay';
  }
}
