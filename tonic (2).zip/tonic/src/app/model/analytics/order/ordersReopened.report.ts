import { OrdersReopened } from "src/app/model/analytics/order/ordersReopened.model";
import { AnalyticOrderReport } from "src/app/model/analytics/reportPaths/analyticOrderReport";

export class OrdersReOpenedReport extends AnalyticOrderReport {
  public value: Array<OrdersReopened>;

  public uri(): string {
    return super.uri() + '/reopened';
  }
}
