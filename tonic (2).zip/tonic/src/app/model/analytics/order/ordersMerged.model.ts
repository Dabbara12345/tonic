export class OrdersMerged {

  public id: number;
  public name: string;
  public created: Date;
  public total: number;
  public itemName: string;
  public terminal: string;
  public user: string;
  public forcedBy: string;
  public dateOfChange: Date;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
