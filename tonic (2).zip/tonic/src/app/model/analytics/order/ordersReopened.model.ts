export class OrdersReopened {
  public created: string;
  public name: string;
  public id: number;
  public price: number;
  public terminalName: string;
  public userName: string;
  public reopened: string;
}
