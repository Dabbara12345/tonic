import { HttpParams } from '@angular/common/http';
import { OrderReport } from '../reportPaths/orderReport';
import { Order } from '../../activity/order.model';

export class OrdersRefundsReport extends OrderReport {

  public uri(){
    return super.uri();
  }

  public value: Array<Order>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('withServer', true);

    params = params.append('withTerminal', true);

    params = params.append('withRefunds', true);

    params = params.append('withDiscounts', false);

    return params;
  }
}
