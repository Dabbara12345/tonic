export class TaxExemptOrders {

  public created: string;

  public name: string;
  public item: string;
  public server: string;
  public taxName: string;
  public group: string;

  public id: number;
  public quantity: number;
  public percentage: number;
  public total: number;
  public taxAmount: number;

  public load(data: any): TaxExemptOrders {

    Object.assign(this, data);

    return this;
  }
}
