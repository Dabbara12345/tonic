export class OrderDetails {

  public orderId: number;
  public name: string;
  public area: string;
  public orderDate: string;
  public salesGroup: string;
  public item: string;
  public preparation: string;
  public server: string;
  public date: string;
  public price: number;
  public quantity: number;
  public count: number;
  public amount: number;
  public ruleName: string;
  public multi: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
