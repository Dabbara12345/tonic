import { HttpParams } from '@angular/common/http';

import { TaxExemptOrders } from "src/app/model/analytics/order/taxExemptOrders.model";
import { AnalyticTaxReport } from 'src/app/model/analytics/reportPaths/analyticTaxReport';

export class TaxExemptOrdersReport extends AnalyticTaxReport {

  public value: Array<TaxExemptOrders>;

  public uri(): string {
    return super.uri() + '/exemptOrder';
  }

}
