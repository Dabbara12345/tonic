import { NameValue } from "../utils/nameValue.model";

export class DataComparison {

    public id!: string;
    public current!: NameValue;
    public previous!: NameValue;

    public load(data: any): DataComparison {

        Object.assign(this, data);

        if(data?.current){
            this.current = new NameValue().load(data.current);
        }

        if(data?.previous){
            this.previous = new NameValue().load(data.previous);
        }

        return this;
    }
}
