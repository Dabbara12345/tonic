export class ShiftSale {

  public days: number;
  public quantity: number;
  public quantityDineIn: number;
  public guests: number;
  public gross: number;
  public grossDineIn: number;
  public tax: number;
  public taxDineIn: number;
  public net: number;
  public netDineIn: number;

  public load(data: any): ShiftSale {
    Object.assign(this, data);

    return this;
  }

  public add(shiftSale: ShiftSale): void {

    this.gross += shiftSale.gross;
    this.grossDineIn += shiftSale.grossDineIn;
    this.net += shiftSale.net;
    this.netDineIn += shiftSale.netDineIn;
    this.quantity += shiftSale.quantity;
    this.quantityDineIn += shiftSale.quantityDineIn;
    this.tax += shiftSale.tax;
    this.taxDineIn += shiftSale.taxDineIn;
    this.guests += shiftSale.guests;
  }
}
