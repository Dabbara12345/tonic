import { HttpParams } from '@angular/common/http';
import { UserAction } from '../../activity/activityHistory.model';
import { LogActivityReport } from '../reportPaths/logActivityReport';

export class StoreActivityLogReport extends LogActivityReport {

  public value: Array<UserAction>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('log',
                            true);

    return params;
  }
}
