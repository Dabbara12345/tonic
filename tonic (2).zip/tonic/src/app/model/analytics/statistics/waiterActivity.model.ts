export class WaiterActivity {

  public date: string;
  public time: string;
  public activity: string;
  public details: Map<string, string>;

  public load(data: any): WaiterActivity {
    Object.assign(this, data);

    return this;
  }
}
