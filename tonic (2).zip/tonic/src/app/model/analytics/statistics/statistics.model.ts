export class Statistics {

  public date: Date;
  public customerDate: Date;

  public type: number;
  public seats: number;
  public net: number;
  public gross: number;
  public items: number;
  public customerId?: number;
  public tax: number;
  public dineInSales: number;
  public dineInCount: number;
  public dineInTaxes: number;
  public count : number;

  public mealTime: string;
  public dayName: string;

  public load(data: any): Statistics {
    Object.assign(this, data);

    return this;
  }
}
