import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';
import { Statistics } from './statistics.model';

export class StatisticsNetReport extends AnalyticSalesReport {

  public value: Array<Statistics>;

  public uri(): string {

    return super.uri() + '/statistics';
  }

}
