import { AdminReport } from "../admin-report.model";

export abstract class AnalyticPaymentReport extends AdminReport {

  public uri(): string {
    return 'analytic/payment';
  }
}
