import { AdminReport } from "src/app/model/analytics/admin-report.model";

export abstract class PettyReport extends AdminReport {

  public uri(): string {
    return 'activity/petty';
  }
}
