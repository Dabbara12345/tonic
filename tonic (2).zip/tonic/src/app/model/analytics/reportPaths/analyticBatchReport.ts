import { AdminReport } from "../admin-report.model";

export abstract class AnalyticBatchReport extends AdminReport {

  public uri(): string {
    return 'analytic/batch';
  }
}
