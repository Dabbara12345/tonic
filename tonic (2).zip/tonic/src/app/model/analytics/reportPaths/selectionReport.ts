import { AdminReport } from "../admin-report.model";

export abstract class SelectionReport extends AdminReport {

  public uri(): string {
    return 'activity/selection';
  }
}
