import { AdminReport } from "../admin-report.model";

export abstract class CashInOutReport extends AdminReport {

  public uri(): string {
    return 'analytic/cashInOut';
  }
}
