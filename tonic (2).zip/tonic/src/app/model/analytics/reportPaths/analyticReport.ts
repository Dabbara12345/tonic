import { AdminReport } from "../admin-report.model";

export abstract class AnalyticReport extends AdminReport {

  public uri(): string {
    return 'analytic/report';
  }
}
