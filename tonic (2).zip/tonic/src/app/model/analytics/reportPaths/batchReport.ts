import { AdminReport } from "../admin-report.model";

export abstract class BatchReport extends AdminReport {

  public uri(): string {
    return 'activity/batch';
  }
}
