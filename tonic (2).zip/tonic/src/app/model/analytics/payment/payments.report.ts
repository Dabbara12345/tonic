import { Payment } from '../../activity/payment.model';
import { AnalyticPaymentReport } from '../reportPaths/analyticPaymentReport';

export class PaymentsReport extends AnalyticPaymentReport {

  public value: Array<Payment>;

  public uri(): string {
    return super.uri() + '/payment/payments';
  }

}
