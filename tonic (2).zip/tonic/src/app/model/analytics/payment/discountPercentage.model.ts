export class DiscountPercentage {
  public opened: string;
  public orderName: string;
  public orderId: number;
  public type: string;
  public item: string;
  public server: number;
  public reason: string;
  public comments: string;
  public authorizedBy: number;
  public qty: number;
  public percent: number;
  public amount: number;
  public total: number;
  public multi: number;
}
