import { DiscountAmount } from 'src/app/model/analytics/payment/discountAmount.model';
import { AnalyticOrderReport } from 'src/app/model/analytics/reportPaths/analyticOrderReport';

export class DiscountsReport extends AnalyticOrderReport {

  public value: Array<DiscountAmount>;

  public uri(): string {
    return super.uri() + '/discountAmount';
  }
}
