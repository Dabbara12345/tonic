import { Payment } from 'src/app/model/activity/payment.model';
import { AnalyticPaymentReport } from 'src/app/model/analytics/reportPaths/analyticPaymentReport';

export class PaymentsDetailsReport extends AnalyticPaymentReport {

  public value: Array<Payment>;

  public uri(): string {
    return super.uri() + '/payment/payments';
  }

}
