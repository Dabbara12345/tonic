import { HttpParams } from '@angular/common/http';

import { SelectionSummary } from 'src/app/model/analytics/payment/selectionSummary.model';
import { AnalyticSelectionReport } from 'src/app/model/analytics/reportPaths/analyticSelectionReport';

export class ComplimentarySummaryReport extends AnalyticSelectionReport {

  public value: Array<SelectionSummary>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('dailySummary', true);
    params = params.append('hasComp', true);

    return params;
  }

}
