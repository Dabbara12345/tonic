export class PaymentByOrderType {

  public orderType: number;
  public paymentType: number;
  public cardType: number;
  public count: number;
  public paymentTotal: number;
  public gratuityTotal: number;
  public tipTotal: number;
  public changeTotal: number;
  public subTotal: number;
  public surchargeTotal: number;

  public load(data: any): PaymentByOrderType {
    Object.assign(this, data);

    return this;
  }
}
