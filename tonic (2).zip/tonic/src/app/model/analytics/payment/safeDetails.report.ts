import { SafeReport } from 'src/app/model/analytics/reportPaths/safeReport';
import { SafeDetails } from 'src/app/model/analytics/payment/safeDetails.model';

export class SafeDetailsReport extends SafeReport {
  public value: Array<SafeDetails>;

  public uri(): string {
    return super.uri() + '/safeDetails';
  }
}
