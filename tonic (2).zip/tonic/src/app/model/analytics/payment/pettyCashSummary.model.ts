export class PettyCashSummary {

  public name: string;

  public amount: number;
  public count: number;

  public load(data: any): PettyCashSummary {
    Object.assign(this, data);

    return this;
  }
}
