import { User } from '../../access/user.model';
import { Terminal } from '../../equipment/terminal.model';

export class PettyCash {

  public cashInOutId: number;
  public drawerId: number;
  public userId: number;
  public terminalId: number;
  public batchNumber?: number;
  public amount: number;

  public currencyCode: string;

  public type: string;
  public note: string;

  public interimDeposit: boolean;

  public created: Date;
  public date: Date;

  public user: User;
  public terminal: Terminal;

  public load(data: any): PettyCash {
    Object.assign(this, data);

    if (data?.user) {
      this.user = new User().load(data.user);
    }

    if (data?.terminal) {
      this.terminal = new Terminal().load(data.terminal);
    }

    return this;
  }
}
