export class ReportCharity {

  public name: string;
  public amount: number;
  public orderId: number;
  public orderName: string;
  public source: string;

  public load(data: any): ReportCharity {
    Object.assign(this, data);

    return this;
  }
}
