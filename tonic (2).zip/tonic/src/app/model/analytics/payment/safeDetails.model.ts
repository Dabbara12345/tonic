export class SafeDetails {
  public name: string;
  public currency: string;
  public id: number;
  public date: string;
  public count: number;
  public amount: number;
  public total: number;
}
