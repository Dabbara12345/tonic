export class ServerHistory {

  public depositId: number;
  public servedBy: string;
  public customerId: number;
  public created: string;
  public type: any;
  public amount: number;
  public orderTypeLabel?: string;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
