import { HttpParams } from '@angular/common/http';
import { Batch } from '../../activity/batch.model';
import { BatchReport } from '../reportPaths/batchReport';

export class DepositsStoreHistoryReport extends BatchReport {

  public value: Array<Batch>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('history', true);

    return params;
  }
}
