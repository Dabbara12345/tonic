import { HttpParams } from '@angular/common/http';
import { DepositHistory } from './depositHistory.model';
import { AnalyticBatchReport } from '../reportPaths/analyticBatchReport';

export class DepositHistoryReport extends AnalyticBatchReport {

  public value: Array<DepositHistory>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('depositHistory', true);

    return params;
  }
}
