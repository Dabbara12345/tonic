export class DiscountAmount {
  public date: string;
  public orderName: string;
  public orderId: number;
  public name: string;
  public comments: string;
  public discountedBy: number;
  public authorizedBy: number;
  public amount: number;
}
