import { HttpParams } from '@angular/common/http';

import { CashInOut } from 'src/app/model/activity/cashInOut.model';
import { ActivityCashInOutReport } from 'src/app/model/analytics/reportPaths/activityCashInOutReport';

export class PaymentsCashDrawerCashOutsReport extends ActivityCashInOutReport  {
  public value: Array<CashInOut>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('cashDrawer', true);

    return params;
  }
}
