import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';
import { ReportCharity } from './reportCharity.model';

export class DonationsSummaryReport extends AnalyticSalesReport {

  public value: Array<ReportCharity>;

  public uri(): string {
    return super.uri() + '/donations';
  }
}
