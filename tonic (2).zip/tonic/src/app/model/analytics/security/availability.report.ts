import { AnalyticOrderReport } from "../reportPaths/analyticOrderReport";
import { Availability } from './availability.model';

export class AvailabilityReport extends AnalyticOrderReport {

  public value: Availability;

  public uri(): string {
    return super.uri() + '/availability';
  }
}
