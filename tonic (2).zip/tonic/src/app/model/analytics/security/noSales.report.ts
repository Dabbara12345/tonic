import { HttpParams } from "@angular/common/http";
import { NoSales } from "./noSale.model";
import { CashInOutReport } from "../reportPaths/cashInOutReport";

export class NoSalesReport extends CashInOutReport {

  constructor() {
      super();
  }

  public uri(): string {
    return super.uri() + '/noSale';
  }

  public value: Array<NoSales>;

  // public params(): HttpParams {

  //   let params: HttpParams = new HttpParams();

  //   params = params.append('noSale', true);

  //   return params;
  // }
}
