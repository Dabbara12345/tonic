import { AnalyticOrderReport } from "../reportPaths/analyticOrderReport";
import { OrderAction } from "../security/orderAction.model";

export class KVDOrderBroadcastMessagesReport extends AnalyticOrderReport {

  public value: Array<OrderAction>;

  public uri(): string {
    return super.uri() + '/kvdorderbroadcastmessages';
  }
}
