import { CustomerActionSummary } from 'src/app/model/customer/customer-action-summary.model';
import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';

export class TransactionTransfersReport extends AnalyticCustomerReport {

  public value: Array<CustomerActionSummary>;

  public uri(): string {
    return super.uri() + 'transactiontransfers';
  }

}
