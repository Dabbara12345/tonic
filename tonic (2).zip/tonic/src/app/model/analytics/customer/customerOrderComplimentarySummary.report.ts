import { AnalyticCustomerReport } from "src/app/model/analytics/customer/analyticCustomer.report";
import { CustomerComplimentarySummary } from "src/app/model/customer/customerComplimentarySummary.model";

export class CustomerOrderComplimentarySummaryReport extends AnalyticCustomerReport {

  public value: Array<CustomerComplimentarySummary>;

  public uri(): string {
    return super.uri() + 'customerComplimentarySummary';
  }

}
