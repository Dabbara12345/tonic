import { PromotionEnrollment } from 'src/app/model/customer/promotionEnrollment.model';
import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';

export class CustomerPromotionEnrollmentReport extends AnalyticCustomerReport {

  public value: Array<PromotionEnrollment>;

  public uri(): string {
    return super.uri() + 'promotionEnrolled';
  }

}
