import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';
import { CustomerComplimentaryDetails } from 'src/app/model/customer/customerComplimentaryDetails.model';

export class CustomerOrderComplimentaryReport extends AnalyticCustomerReport {
  public value: Array<CustomerComplimentaryDetails>;

  public uri(): string {
    return super.uri() + 'customerComplimentaryDetails';
  }
}
