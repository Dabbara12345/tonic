import { CustomerInfo } from 'src/app/model/customer/customer-info.model';
import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';

export class AllowanceAdjustmentReport extends AnalyticCustomerReport {

  public value: Array<CustomerInfo>;

  public uri(): string {
    return super.uri() + 'allowanceInfo';
  }

}
