import { LoyaltyActivity } from 'src/app/model/customer/loyaltyActivity.model';
import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';

export class LoyaltyActivityReport extends AnalyticCustomerReport {

  public value: Array<LoyaltyActivity>;

  public uri(): string {
    return super.uri() + 'loyaltyActivity';
  }

}
