import { CustomerActivities } from 'src/app/model/customer/customer-activities.model';
import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';

export class CustomerOrderHistoryReport extends AnalyticCustomerReport {

  public value: Array<CustomerActivities>;

  public uri(): string {
    return super.uri() + 'orderHistory';
  }

}
