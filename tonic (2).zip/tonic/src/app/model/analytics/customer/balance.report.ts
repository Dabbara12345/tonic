import { CustomerBalance } from '../../customer/customerBalance.model';
import { AnalyticReport } from '../reportPaths/analyticReport';

export class BalanceReport extends AnalyticReport {

  public value: Array<CustomerBalance>;

  public uri(): string {
    return super.uri() + '/customerBalance/balance';
  }
}
