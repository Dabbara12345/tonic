import { LoyaltyHistory } from 'src/app/model/customer/loyaltyHistory.model';
import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';

export class LoyaltyHistoryReport extends AnalyticCustomerReport {

  public value: Array<LoyaltyHistory>;

  public uri(): string {
    return super.uri() + 'loyaltyHistory';
  }

}
