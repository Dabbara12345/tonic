import { OnInit } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Input } from '@angular/core';
import { Directive } from '@angular/core';
import { ElementRef } from '@angular/core';

declare var $: any;

@Directive({
    selector: '[appSparkline]'
})

export class SparklineDirective implements OnInit, OnDestroy {

    @Input() sparkline: any;
    @Input() values: any;

    // generate a unique resize event so we can detach later
    private resizeEventId: string = 'resize.sparkline' + 1324;
    private $element: any;

    constructor(private el: ElementRef) {
        this.$element = $(el.nativeElement);
    }

    public ngOnInit(): void {
        this.initSparkLine();
    }

    public initSparkLine(): void {

        let options: any = this.sparkline;
        let data: any = this.$element.data();

        if (!options) {// if no scope options, try with data attributes
          options = data;
        }
        else {
          if (data) {// data attributes overrides scope options
            options = $.extend({}, options, data);
          }
        }

        options.type = options.type || 'bar'; // default chart is bar
        options.disableHiddenCheck = true;

        this.runSparkline(options);

        if (options.resize) {

          $(window).on(this.resizeEventId, (): void => {
            this.runSparkline(options);
          });
        }
    }

    public runSparkline(options: any): void {

      if(this.values) {
        if( typeof this.values === 'string')
          this.values = this.values.split(','); // assume comma separated string
        this.$element.sparkline(this.values, options);
      }
      else {
        this.$element.sparkline('html', options);
      }
    }

    public ngOnDestroy(): void {
      $(window).off(this.resizeEventId);
    }
}
