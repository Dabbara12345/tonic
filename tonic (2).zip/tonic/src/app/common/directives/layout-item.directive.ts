import { OnChanges } from '@angular/core';
import { Input } from '@angular/core';
import { Directive } from '@angular/core';
import { ViewContainerRef } from '@angular/core';
import { ComponentRef } from '@angular/core';

const components: {} = {};

@Directive({
  selector: '[appLayoutItem]'
})
export class LayoutItemDirective implements OnChanges {

  @Input() componentRef: string;

  public component: ComponentRef<any>;

  constructor(private viewContainerRef: ViewContainerRef) { }

  public ngOnChanges(): void {

    const component: any = components[this.componentRef];

    if (component) {
      this.component = this.viewContainerRef.createComponent(component);
    }
  }
}
