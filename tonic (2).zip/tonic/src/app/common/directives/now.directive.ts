import { OnInit } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Input } from '@angular/core';
import { Directive } from '@angular/core';
import { ElementRef } from '@angular/core';

import * as moment from 'moment';

@Directive({
    selector: '[appNow]'
})
export class NowDirective implements OnInit, OnDestroy {

    @Input() format: string;

    private intervalId: ReturnType<typeof setInterval>;

    constructor(public element: ElementRef) { }

    public ngOnInit(): void {

        this.updateTime();
        this.intervalId = setInterval(this.updateTime.bind(this), 1000);
    }

    public updateTime(): void {

        let dt: string = moment().format(this.format);
        this.element.nativeElement.innerHTML = dt;
    }

    public ngOnDestroy(): void {

        clearInterval(this.intervalId);
    }
}
