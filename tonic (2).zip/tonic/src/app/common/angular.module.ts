import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ReactiveFormsModule } from '@angular/forms';

import { DateAdapter } from 'angular-calendar';
import { CalendarModule } from 'angular-calendar';
import { TextMaskModule } from 'angular2-text-mask';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { GridsterModule } from 'angular-gridster2';

import { BdcWalkModule } from 'bdc-walkthrough';
import { NgxPrintModule } from 'ngx-print';
import { TagInputModule } from 'ngx-chips';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { FileSaverModule } from 'ngx-filesaver';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NouisliderModule } from 'ng2-nouislider';
import { SatPopoverModule } from '@ncstate/sat-popover';
import { NgxBarcode6Module } from 'ngx-barcode6';
import { ColorPickerModule } from 'ngx-color-picker';
import { ColorChromeModule } from 'ngx-color/chrome';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { MaterialFileInputModule } from 'ngx-material-file-input';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    RouterModule,
    DragDropModule,
    ScrollingModule,
    ReactiveFormsModule,

    TextMaskModule,
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
    GridsterModule,

    BdcWalkModule,
    NgxPrintModule,
    TagInputModule,
    AccordionModule.forRoot(),
    FileSaverModule,
    NouisliderModule,
    NgxSpinnerModule,
    NgxBarcode6Module,
    SatPopoverModule,
    ColorPickerModule,
    ColorChromeModule,
    CurrencyMaskModule,
    SelectDropDownModule,
    MaterialFileInputModule,
  ],
  declarations: [
  ],
  exports: [
    FormsModule,
    CommonModule,
    RouterModule,
    DragDropModule,
    ScrollingModule,
    ReactiveFormsModule,

    TextMaskModule,
    CalendarModule,
    GridsterModule,

    BdcWalkModule,
    NgxPrintModule,
    TagInputModule,
    AccordionModule,
    FileSaverModule,
    NouisliderModule,
    NgxSpinnerModule,
    NgxBarcode6Module,
    SatPopoverModule,
    ColorPickerModule,
    ColorChromeModule,
    CurrencyMaskModule,
    SelectDropDownModule,
    MaterialFileInputModule,
  ],
  entryComponents: [
  ]
})
export class AngularXModule {}
