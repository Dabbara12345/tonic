import { NgModule } from '@angular/core';
import { ModuleWithProviders } from '@angular/core';

import { TabsModule } from 'ngx-bootstrap/tabs';
import { AlertModule } from 'ngx-bootstrap/alert';
import { ModalModule } from 'ngx-bootstrap/modal';
import { RatingModule } from 'ngx-bootstrap/rating';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { SortableModule } from 'ngx-bootstrap/sortable';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TranslateModule } from '@ngx-translate/core';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

// https://angular.io/styleguide#!#04-10
@NgModule({
    imports: [
        TranslateModule,

        TabsModule.forRoot(),
        AlertModule.forRoot(),
        ModalModule.forRoot(),
        RatingModule.forRoot(),
        TooltipModule.forRoot(),
        PopoverModule.forRoot(),
        ButtonsModule.forRoot(),
        SortableModule.forRoot(),
        CarouselModule.forRoot(),
        CollapseModule.forRoot(),
        TypeaheadModule.forRoot(),
        AccordionModule.forRoot(),
        BsDropdownModule.forRoot(),
        TimepickerModule.forRoot(),
        PaginationModule.forRoot(),
        ProgressbarModule.forRoot(),
        BsDatepickerModule.forRoot(),
    ],
    declarations: [
    ],
    providers: [
    ],
    exports: [
        TabsModule,
        AlertModule,
        ModalModule,
        RatingModule,
        ButtonsModule,
        TooltipModule,
        PopoverModule,
        CollapseModule,
        SortableModule,
        CarouselModule,
        TypeaheadModule,
        AccordionModule,
        TranslateModule,
        TimepickerModule,
        BsDropdownModule,
        PaginationModule,
        ProgressbarModule,
        BsDatepickerModule,
    ]
})

// https://github.com/ocombe/ng2-translate/issues/209
export class BootstrapXModule {
    static forRoot(): ModuleWithProviders<BootstrapXModule> {
        return {
            ngModule: BootstrapXModule
        };
    }
}
