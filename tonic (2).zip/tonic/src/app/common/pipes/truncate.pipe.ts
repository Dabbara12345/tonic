import { Pipe } from '@angular/core';
import { PipeTransform } from '@angular/core';

@Pipe({
  name: 'Truncate'
})
export class TruncatePipe implements PipeTransform {

  transform(value: number,
            isCurrency: boolean = true,
            currency: string = 'USD',
            locale: string = 'en-US'): string {

    const factor = Math.pow(10, 2);
    const truncated = Math.trunc(value * factor) / factor;

    if (isCurrency) {

      return new Intl.NumberFormat(locale, {
        style: 'currency',
        currency: currency
      }).format(truncated);

    } else {

      return new Intl.NumberFormat(locale).format(truncated);

    }

  }

}
