import { CategoryAvailableFilterItems } from "src/app/model/v3/menu-configuration.model";

export type OptionList = {value: string, displayText: string}; // TODO: Can be used globally for any dropdown opions list.

export const CategoryFilterOptionsList: OptionList[] = [
  {value: CategoryAvailableFilterItems.ALL, displayText: 'All'},
  {value: CategoryAvailableFilterItems.STORE, displayText: 'Store'},
  {value: CategoryAvailableFilterItems.ONLINE, displayText: 'Online Order'},
  {value: CategoryAvailableFilterItems.FAVORITES, displayText: 'Favorites'},
];
