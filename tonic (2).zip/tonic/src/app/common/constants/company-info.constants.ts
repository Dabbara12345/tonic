export const COMPANY_ADDRESS = '301 Perimeter Center N Suite 225, Atlanta, GA 30346';
export const COMPANY_INFO_PHONE = '(877) 515-8472';
export const COMPANY_INFO_EMAIL = 'info@tonicpos.com'
