export const COMMON_URLS = {
  SHOP: 'https://shop.ordyx.com/',
  GOOGLE_PLAY_STORE: 'https://play.google.com/store/apps/details?id=com.ordyx.one&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1',
  APPLE_STORE: 'https://apps.apple.com/us/app/ordyxone/id1540796532?itsct=apps_box&itscg=30200',
  PCI_COMPLIANCE: 'https://tonicpos.com/pci-compliance/',
  MERCHANT_FUNDING: "https://tonicpos.com/merchant-funding/",
  INTEGRATIONS: "https://tonicpos.com/integrations/",
  CAREERS: "https://tonicpos.com/careers/",
  TONIC_SETUP_INFORMATION: "https://tonicpos.com/tonic-setup-information/",
  REQUEST_A_DEMO: "https://tonicpos.com/request-a-demo/",
  CONTACT: "https://tonicpos.com/contact",
  FEATURE_REQUEST: "https://tonicpos.com/feature-request/",
  GIFT_CARD: "https://tonicpos.com/gift-card/",
  SAFE_HARBOR_STATEMENT: "https://tonicpos.com/safe-harbor-statement/",
  APPS: "https://app.ordyx.com",
  DEALER_PORTAL: "https://portal.ordyx.com/login",
}

export enum DASHBOARD_ROUTES {
  HOME = '/app/v3/dashboard',
  APPS = 'http://app.ordyx.com'
}

export const V2_ROUTES = {
  DASHBOARD: {
    path: '/system/dashboard',
    text: 'Dashboard',
    WIDGET:{
      path:'/system/dashboard?widget=true',
      text: 'Widget'
    },
    REPORTS:{
      path:'/system/dashboard?reports=true',
      text: 'Reports'
    },
    ACTIVITY:{
      path:'/system/dashboard?activity=true',
      text: 'Activity'
    }
  },
  CONFIGURATION: {
    MENU: {
      MENU_CONFIGURATION: {
        path: '/system/menu/menu',
        text: 'Categories'
      },
      MODIFIERS: {
        path: '/system/menu/preparation?showModal=true',
        text: 'Modifier Sets'
      },
      MODIFIERS_SETS: {
        path: '/system/menu/preparation',
        text: 'Modifier Sets'
      },
      SALES_GROUPS: {
        path: '/system/menu/recipe?showModal=true',
        text: 'Items'
      },
      COMBO_GROUPS: {
        path: '/system/menu/combo_group',
        text: 'Combo Groups'
      },
      ITEMS: {
        path: '/system/menu/recipe',
        text: 'Items'
      },
      RULES: {
        path: '/system/menu/rules',
        text: 'Rules'
      },
    },
    LABOR: {
      STAFF: {
        path: '/system/staff/user',
        text: 'Staff'
      },
      ROLES: {
        path: '/system/staff/role',
        text: 'Roles'
      }
    },
    PAYMENT: {
      TYPES: {
        path: '/system/payment/type',
        text: 'Types'
      },
      DISCOUNTS: {
        path: '/system/payment/discount',
        text: 'Discounts'
      },
      DONATIONS: {
        path: '/system/payment/donation',
        text: 'Donations'
      },
      TAXES: {
        path: '/system/payment/tax',
        text: 'Taxes'
      },
      CURRENCIES: {
        path: '/system/payment/foreign_currency',
        text: 'Currencies'
      },
    },
    HARDWARE: {
      TERMINALS: {
        path: '/system/equipment/terminal',
        text: 'Terminals'
      },
      EMVS: {
        path: '/system/equipment/emv',
        text: 'EMVs'
      },
      PERIPHERALS: {
        path: '/system/equipment/annunciator',
        text: 'Peripherals'
      },
      SAFES: {
        path: '/system/equipment/safe',
        text: 'Safes'
      }
    },
    UI: {
      TABLE_MAP: {
        path: '/system/ui/layout',
        text: 'Table Map'
      },
      SETTINGS: {
        path: '/system/ui/settings',
        text: 'Settings'
      }
    }
  },
  ACTIVITY: {
    ACTIVITY: {
      BATCH: {
        path: '/system/activity/batch',
        text: 'Batch'
      },
      FUTURE_ORDER: {
        path: '/system/activity/futureOrders',
        text: 'Futureorder'
      },
    },
    ARCHIVE:{
      ORDERS:{
        path: '/system/activity/orders',
        text: 'Orders'
      },
      PAYMENTS:{
        path: '/system/activity/payments',
        text: 'Payments'
      },
    }
  },
  TIME: {
    path: '/system/time',
    text: 'Time & Attendance'
  },
  CUSTOMER: {
    path: '/system/customer',
    text: 'Customers'
  },
  INVENTORY: {
    path: '/system/inventory',
    text: 'Inventory'
  },
  QUICKBOOKS: {
    path: '/system/quickbooks',
    text: 'Quickbooks'
  },
  ADMIN: {
    STORES: {
      path: '/system/admin/stores',
      text: 'Stores'
    },
    USERS: {
      path: '/system/admin/users',
      text: 'Users'
    },
    PAYMENTS: {
      path: '/system/admin/monthly-bill',
      text: 'Payments'
    }
  },
  LOGS: {
    path: '/system/logs',
    text: 'Logs'
  }
}

export const NAVBAR_OTHER_OPTIONS_URLs = {
  CUSTOMERS: 'http://swagger.ordyx.com.s3-website-us-east-1.amazonaws.com/swagger.html',
  ONLINE_ORDERS: 'http://swagger.ordyx.com.s3-website-us-east-1.amazonaws.com/swaggerOlo.html',
  MI_POINT: 'http://swagger.ordyx.com.s3-website-us-east-1.amazonaws.com/swaggerMipoint.html'
}
