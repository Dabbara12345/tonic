import { ExtraStoreToolsViewModal, STORE_MODULES, StoreModuleViewModel, EXTRA_STORE_TOOLS } from "src/app/model/v3/store.model";
import { COMMON_URLS, V2_ROUTES } from "./url.constants";
import { DropdownMenuViewModal, DropdownViewModal, NavbarUserMenu } from "src/app/model/v3/ui.model";
import { EXTERNAL_URL_NAMES } from "src/app/model/v3/ui.model";
import { KEBAB_MENU_ACTIONS, KebabMenuOptions } from "src/app/modules/configuration-v3/configuration/menu/menu-configuration/menu-configuration.model";

export const MAX_DATA_POINTS_SALES_BY_HOUR = 24;

export const SALES_BREAKDOWN_CHART_SEGMENT_LIMIT = 8;

export const WEEK_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export enum WEEK_DESCRIPTION {
  SUNDAY_TO_SATURDAY = 'Sunday to Saturday',
  EVERYDAY = 'Everyday'
}

export const storeModuleList: Array<StoreModuleViewModel> = [
  {
    id: STORE_MODULES.MODULE_NEW_BACK_OFFICE,
    text: 'New BOH',
    icon: 'auto_awesome',
    moduleName: STORE_MODULES.MODULE_NEW_BACK_OFFICE,
    path: V2_ROUTES.DASHBOARD.path,
    isEnabled: false,
    deadLink: true,
  },
  {
    id: STORE_MODULES.MODULE_TIME_ATTENDANCE,
    text: 'Attendance',
    icon: 'punch_clock',
    moduleName: STORE_MODULES.MODULE_TIME_ATTENDANCE,
    path: V2_ROUTES.TIME.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_CUSTOMER_ACCOUNTS,
    text: 'Customers',
    icon: 'people',
    moduleName: STORE_MODULES.MODULE_CUSTOMER_ACCOUNTS,
    path: V2_ROUTES.CUSTOMER.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_INVENTORY,
    text: 'Inventory',
    icon: 'inventory',
    moduleName: STORE_MODULES.MODULE_INVENTORY,
    path: V2_ROUTES.INVENTORY.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_ONLINE_ORDERING,
    text: 'Self Order',
    icon: 'shopping_cart',
    moduleName: STORE_MODULES.MODULE_ONLINE_ORDERING,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_ENTERPRISE,
    text: 'Enterprise',
    icon: 'business',
    moduleName: STORE_MODULES.MODULE_ENTERPRISE,
    path: '/system/enterprise',
    isEnabled: false,
  }
];

export const extraStoreToolsList : ExtraStoreToolsViewModal[] = [
  {
    id: EXTRA_STORE_TOOLS.MARKETPLACE,
    text: 'Marketplace',
    icon: '/assets/img/v3/icons/store-front-white.svg',
    path: '',
  },
  {
    id: EXTRA_STORE_TOOLS.INTEGRATIONS,
    text: 'Integrations',
    icon: '/assets/img/v3/icons/stack.svg',
    path: '',
  },
  {
    id: EXTRA_STORE_TOOLS.URLS,
    text: 'URLs',
    icon: '/assets/img/v3/icons/link.svg',
    path: '',
  },
  {
    id: EXTRA_STORE_TOOLS.QUICKBOOKS,
    text: 'Quickbooks',
    icon: '/assets/img/v3/icons/quick-books.svg',
    path: V2_ROUTES.QUICKBOOKS.path,
  },
  {
    id: STORE_MODULES.MODULE_MAIL_CHIMP,
    text: 'Mail Chimp',
    icon: '/assets/img/v3/icons/mailchimp-logo.png',
    path: '',
  }
];

export enum MORE_TOOLS_ENUM {
  DEALER_PORTAL = 'dealer_portal',
  SUGGESTIONS = 'suggestions',
  SHOP = 'shop',
  PHONE_BOOK = 'phone_book',
  SUPPORT_LIBRARY = 'support_library',
  THEMES = 'themes',
  ADMIN = 'admin',
  STORE = 'store',
  ENTERPRISES = 'enterprises',
  COMMUNITIES = 'communities',
  DOCUMENTS = 'documents',
  SUPPORT = 'support',
  SYSTEM = 'system',
  LOG_HISTORY = 'log_history',
  BILLING = 'billing',
  FEES = 'fees',
  PAYMENTS = 'payments'
}

export const MORE_TOOLS_DROP_DOWN_MENU_LIST: DropdownMenuViewModal[] = [
  {
    id: MORE_TOOLS_ENUM.DEALER_PORTAL,
    label: 'Dealer Portal',
    path: COMMON_URLS.DEALER_PORTAL,
    icon: '/assets/img/v3/icons/store-front-white.svg',
  },
  {
    id: MORE_TOOLS_ENUM.SUGGESTIONS,
    label: 'Suggestions',
    path: '',
    icon: '/assets/img/v3/icons/chat-white.svg',
  },
  {
    id: MORE_TOOLS_ENUM.SHOP,
    label: 'Shop',
    path: COMMON_URLS.SHOP,
    icon: '/assets/img/v3/icons/shopping-cart-white.svg',
  },
  {
    id: MORE_TOOLS_ENUM.PHONE_BOOK,
    label: 'Phone Book',
    path: '',
    icon: '/assets/img/v3/icons/address-book.svg',
  },
  {
    id: MORE_TOOLS_ENUM.SUPPORT_LIBRARY,
    label: 'Support Library',
    path: '',
    icon: '/assets/img/v3/icons/bookmark-white.svg',
  },
  {
    id: MORE_TOOLS_ENUM.THEMES,
    label: 'Themes',
    path: '',
    icon: '/assets/img/v3/icons/color-pallet.svg',
    disable: true,
  },
  {
    id: MORE_TOOLS_ENUM.ADMIN,
    label: 'Admin',
    path: '',
    icon: '/assets/img/v3/icons/user-shield-white.svg',
    toggleIcon: 'keyboard_arrow_right',
    submenu: [
      {
        id: MORE_TOOLS_ENUM.STORE,
        label: 'Store',
        path: V2_ROUTES.ADMIN.STORES.path,
        icon: '/assets/img/v3/icons/store-front-white.svg',
      },
      {
        id: MORE_TOOLS_ENUM.ENTERPRISES,
        label: 'Enterprises',
        path: '',
        icon: '/assets/img/v3/icons/building-white.svg',
      },
      {
        id: MORE_TOOLS_ENUM.COMMUNITIES,
        label: 'Communities',
        path: '',
        icon: '/assets/img/v3/icons/communities-white.svg',
      },
      {
        id: MORE_TOOLS_ENUM.DOCUMENTS,
        label: 'Documents',
        path: '',
        icon: '/assets/img/v3/icons/folder-open-white.svg',
      },
      {
        id: MORE_TOOLS_ENUM.SUPPORT,
        label: 'Support',
        path: V2_ROUTES.ADMIN.USERS.path,
        icon: '/assets/img/v3/icons/headset-white.svg',
      },
      {
        id: MORE_TOOLS_ENUM.SYSTEM,
        label: 'System',
        path: '',
        icon: '/assets/img/v3/icons/gear-white.svg',
      },
      {
        id: MORE_TOOLS_ENUM.LOG_HISTORY,
        label: 'Log History',
        path: V2_ROUTES.LOGS.path,
        icon: '/assets/img/v3/icons/clock-anti-clockwise-white.svg',
      },
    ],
  },
  {
    id: MORE_TOOLS_ENUM.BILLING,
    label: 'Billing',
    path: '',
    icon: '/assets/img/v3/icons/dollar-rounded-white.svg',
    toggleIcon: 'keyboard_arrow_right',
    submenu: [
      {
        id: MORE_TOOLS_ENUM.FEES,
        label: 'Fees',
        path: '',
        icon: '/assets/img/v3/icons/dollar-rounded-white.svg',
      },
      {
        id: MORE_TOOLS_ENUM.PAYMENTS,
        label: 'Payments',
        path: V2_ROUTES.ADMIN.PAYMENTS.path,
        icon: '/assets/img/v3/icons/credit-card-white.svg',
      },
    ],
  }
];

export const MORE_TOOLS_DROP_DOWN: DropdownViewModal = {
  menu: MORE_TOOLS_DROP_DOWN_MENU_LIST,
  listContainerClass: 'bg-primary v3-font font-smaller font-weight-medium mw200 py-0 dark-theme arrange-main-dropdown translate-x-33 top-20',
  listItemClasses: 'd-flex d-flex justify-content-between align-items-center v3-font font-smaller font-weight-medium px15 py12 font-color-light',
  submenuContainerClass: 'dropdown-menu-right'
}

export enum STORE_PERMISSIONS {
  MODIFY_STORE = 'MODIFY_STORE'
}

export const externalURLsNameList =
[ EXTERNAL_URL_NAMES.CUSTOMERS,  EXTERNAL_URL_NAMES.ONLINE_ORDERS, EXTERNAL_URL_NAMES.MI_POINT];

export const settingsDropdownMenu: DropdownMenuViewModal[] = [
  { id: NavbarUserMenu.SETTINGS, label: NavbarUserMenu.SETTINGS, icon: '/assets/img/v3/icons/settings-icon.svg', disable: false },
  { id: NavbarUserMenu.STORE, label: NavbarUserMenu.STORE, icon: '/assets/img/v3/icons/store-icon.svg', disable: false },
  { id: NavbarUserMenu.OLO_SCHEDULES, label: NavbarUserMenu.OLO_SCHEDULES, icon: '/assets/img/v3/icons/clock-icon.svg', disable: false },
  { id: NavbarUserMenu.BILLING, label: NavbarUserMenu.BILLING, icon: '/assets/img/v3/icons/dollar-circle-icon.svg', disable: true},
  { id: NavbarUserMenu.LOGOUT, label: NavbarUserMenu.LOGOUT, icon: '/assets/img/v3/icons/signout-icon.svg', disable: false }
];

export const laborCostByHourFilterOptions: {minCost: number, maxCost: number}[] = [
  {minCost: 0, maxCost: 200},
  {minCost: 201, maxCost: 1000},
  {minCost: 1001, maxCost: 10000},
  {minCost: 10000, maxCost: undefined}
];

export const ConfigurationTabsetMenu = [
  { name: 'Menu Configuration', path: 'menu-configuration'},
  { name: 'Choices', path: ''},
  { name: 'Modifiers', path: 'modifiers'},
  { name: 'Sales Groups & Parent Groups', path: ''},
  { name: 'Items', path: ''},
  { name: 'Combo Groups', path: ''},
  { name: 'Rules', path: ''},
];

export class Constants {
  public static get KebabMenuOptions(): KebabMenuOptions[] {
   return [
      { action: KEBAB_MENU_ACTIONS.CLOSE, icon: "/assets/img/v3/icons/close-white-with-background.svg", hoverIcon:"/assets/img/v3/icons/close-white-with-filled-background.svg", label: 'close' },
      { action: KEBAB_MENU_ACTIONS.SCHEDULER, icon: "/assets/img/v3/icons/alarm-white.svg",  hoverIcon:"/assets/img/v3/icons/alarm-red.svg", label: 'schedule' },
      { action: KEBAB_MENU_ACTIONS.FAVORITE, icon: "/assets/img/v3/icons/heart-white.svg", hoverIcon:"/assets/img/v3/icons/heart-outline.svg", label: 'favorite' },
      { action: KEBAB_MENU_ACTIONS.DELETE, icon: "/assets/img/v3/icons/trash-white.svg",  hoverIcon:"/assets/img/v3/icons/trash-red.svg" ,label: 'delete' }
    ];
  }
}
