import { MatDialogConfig } from "@angular/material/dialog";

export namespace ModalConstants {
    export class Modal {
        public static get AddCategoryModalConfigs(): MatDialogConfig {
            return {
                height: '680px',
                width: '1200px',
                disableClose: true,
                panelClass: 'add-category-dialog-container',
                backdropClass: 'add-category-backdrop'
            }
        }

        public static get MenuPrintModalConfigs(): MatDialogConfig {
            return {
                height: '0%',
                width: '0%',
                disableClose: true,
            }
        }
    }
}
