import { Input } from '@angular/core';
import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MatSort  } from '@angular/material/sort';
import { MatDialog  } from '@angular/material/dialog';
import { MatPaginator  } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import { SessionService } from 'src/app/service/session.service';
import { Ingredient } from 'src/app/model/inventory/ingredient.model';

@Component({
  selector: 'app-ingredients-preview',
  templateUrl: './ingredients-preview.component.html',
  styleUrls: ['./ingredients-preview.component.scss'],
})
export class IngredientsPreviewComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @Input() ingredients: Array<Ingredient>;

  public dataSource:    MatTableDataSource<Ingredient>  = new MatTableDataSource<Ingredient>();

  public listColumns:   string[]                        = ['name', 'available', 'tracking',
                                                           'monitored', 'reconciledOn'];

  constructor(public dialog: MatDialog,
              public sessionService: SessionService) {
  }

  public ngOnInit(): void {
    this.updateDataSource();
  }

  private updateDataSource(): void {

    let data: Array<Ingredient> = new Array<Ingredient>();
    data = this.ingredients;

    this.dataSource = new MatTableDataSource(data);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public checkMonitored(ingredient?: Ingredient): boolean {
    let toReturn: boolean = true;

    if ((ingredient && ingredient?.monitored === false) || !ingredient?.monitored) {
      toReturn = false;
    } else {
      for (const item of this.ingredients) {
        if (item?.monitored === false) {
          return false;
        }
      }
    }
    return toReturn;
  }

  public checkTracked(ingredient?: Ingredient): boolean {
    let toReturn: boolean = true;

    if ((ingredient && ingredient?.tracked === false) || !ingredient?.tracked) {
      toReturn = false;
    } else {
      for (const item of this.ingredients) {
        if (item?.tracked === false) {
          return false;
        }
      }
    }
    return toReturn;
  }

  private getUnitString(type: number, unit: number): string {
    return Ingredient.getUnitString(type, unit);
  }

  public getValue(ingredient: Ingredient,
                  itemValue: string,
                  itemUnit: string): string {

    let toReturn: string = '';

    let unit: string = this.getUnitString(ingredient.measureType,
                                          ingredient[itemUnit] ?
                                          ingredient[itemUnit] : 0);

    if (unit !== 'Single') {
      toReturn = this.formatAmt(ingredient[itemValue]) + ' ' + unit;
    } else {
      toReturn = ingredient[itemValue] + ' ' + unit;
    }

    return toReturn;
  }

  public formatDate(date: Date): string {
    return new DatePipe('en-US').transform(date, 'MMM d, yyyy h:mm a');
  }

  private formatAmt(num: number): string {
    return (num).toLocaleString('en-GB', {minimumFractionDigits: 2, maximumFractionDigits: 2});
  }

}
