import { Inject } from '@angular/core';
import { OnInit } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { OnDestroy } from '@angular/core';
import { Component } from '@angular/core';
import { ViewChild } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatExpansionPanel } from '@angular/material/expansion';
import { MatTableDataSource } from '@angular/material/table';
import { StepperSelectionEvent } from '@angular/cdk/stepper';

import * as XLSX from 'xlsx';
import Swal from 'sweetalert2';

import { Item } from 'src/app/model/menu/item.model';
import { User } from 'src/app/model/access/user.model';
import { Role } from 'src/app/model/access/role.model';
import { Alert } from 'src/app/model/communication/alert.model';
import { Recipe } from 'src/app/model/menu/recipe.model';
import { Section } from 'src/app/model/menu/section.model';
import { Category } from 'src/app/model/menu/category.model';
import { Security } from 'src/app/model/access/security.model';
import { NameValue } from 'src/app/model/utils/nameValue.model';
import { Permission } from 'src/app/model/access/permission.model';
import { SalesGroup } from 'src/app/model/menu/salesGroup.model';
import { FileService } from 'src/app/service/utils/file.service';
import { RoleService } from 'src/app/service/access/role.service';
import { UserService } from 'src/app/service/access/user.service';
import { AlertService } from 'src/app/service/utils/alert.service';
import { RecipeService } from 'src/app/service/menu/recipe.service';
import { SessionService } from 'src/app/service/session.service';
import { CategoryService } from 'src/app/service/menu/category.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent implements OnInit, OnDestroy {

  @ViewChild(MatSort, { static: false })
  set sort(value: MatSort) {
    if (this.dataSource) {
      this.dataSource.sort = value;
    }
  }

  public isUploading: boolean = false;
  public dragValid: boolean;
  public replace: boolean = false;

  public modalTitle: string;
  public accordions: Array<{name: string, value: string, columns: Array<string>}>;
  public required: Array<string>;
  public displayedColumns: Array<string> = ['destination', 'arrow', 'source'];
  public dataSource: MatTableDataSource<string> = new MatTableDataSource();
  public columnMap: Map<string, string> = new Map<string, string>(); // columns -> jsonColumns
  public maxJsonColWidth: number = 0;
  public jsonObjects: Array<any> = new Array<any>();
  public file: File;

  public recipes: Array<Recipe>;

  private jsonArray: Array<any> = Array<any>();
  private jsonColumns: Array<string> = Array<string>();
  private jsonColumnMap: Map<string, string> = new Map<string, string>(); // jsonColumns -> columns
  private columns: Array<string>;

  @ViewChild(MatStepper) private stepper: MatStepper;

  constructor(private fileService: FileService,
              private sessionService: SessionService,
              private roleService: RoleService,
              private userService: UserService,
              private alertService: AlertService,
              private recipeService: RecipeService,
              private categoryService: CategoryService,
              public dialogRef: MatDialogRef<UploadComponent>,
              @Inject(MAT_DIALOG_DATA) public mode: string) {

    if (window.FileList && window.File) {
      document.addEventListener('dragover', this.dragOver);
      document.addEventListener('dragleave', this.dragLeave);
      document.addEventListener('drop', this.dragDrop);
    }

    if (mode === 'user') {
      this.modalTitle = 'UPLOAD STAFF';
      this.columns = ['First Name', 'Last Name', 'Email', 'Description', 'Change Password', 'Locale', 'Alerts', 'Securities', 'Settings', 'Employee Number', 'Last Login',
                      'Track1', 'Max Comp', 'Cell Number', 'Phone Number', 'Hourly Weight', 'Tip Weight'];
      this.required = ['First Name', 'Last Name'];
      this.accordions = [{name: 'Address', value: null, columns: ['Address', 'City', 'Postal Code']}];
    } else if (mode === 'menu') {
      this.modalTitle = 'UPLOAD MENUS';
      this.columns = ['Menu', 'Item', 'Price', 'Section', 'Type', 'BarCode', 'Sides'];
      this.required = ['Menu', 'Item', 'Price', 'Type'];
      this.accordions = [];

      this.dataSource.sortingDataAccessor = (item, property): string => {
        const column: string = item + '';

        if (property === 'destination') {
          return column;
        } else {
          return this.columnMap.get(column);
        }
      };
    }

    this.dataSource.data = this.columns;
  }

  public ngOnInit(): void {
    this.loadRecipes();
    this.dataSource.sort = this.sort;
  }

  public ngOnDestroy(): void {
    document.removeEventListener('dragover', this.dragOver);
    document.removeEventListener('dragleave', this.dragLeave);
    document.removeEventListener('drop', this.dragDrop);
  }

  public onCancel(): void {
    this.dialogRef
        .close({cancelled: true});
  }

  public onStepChanged(event: StepperSelectionEvent): void {
    this.jsonObjects.length = 0;

    if (event.selectedIndex === 2) {
      if (this.mode === 'menu') {
        this.jsonObjects.push(this.createMenus());
      } else if (this.mode === 'user') {
        const users: User[] = this.createUsers();

        this.jsonObjects.push(users);
        this.addRoles(users);
      }
    }
  }

  public onReplaceToggle(): void {
    this.replace = !this.replace;
  }

  public onUpload(): void {

    if (this.mode === 'user') {
      this.userUpload();
    } else {
      this.menuUpload();
    }
  }

  public userUpload(): void {

    let prompt: string;

    if (this.replace) {
      prompt = `Are you sure you want to replace the existing staff?`;
    } else {
      prompt = `Are you sure you want to add the new staff?`
    }

    Swal.fire({title: prompt,
               text: `Keep in mind that this action cannot be undone or cancelled`,
               icon: 'warning',
               confirmButtonText: 'Yes',
               cancelButtonText: 'No',
               reverseButtons: true,
               showCloseButton: true,
               showCancelButton: true})
        .then((willdelete): void => {

          if (willdelete.isConfirmed) {
            this.doUserUpload(this.replace);
          }
        });
  }

  public menuUpload(): void {

    let prompt: string;

    if(this.replace){
      prompt = `Are you sure you want to replace the entire menu?`;
    } else {
      prompt = `Are you sure you want to add the new categories?`
    }

    Swal.fire({title: prompt,
               text: `Keep in mind that this action cannot be undone or cancelled`,
               icon: 'warning',
               confirmButtonText: 'Yes',
               cancelButtonText: 'No',
               reverseButtons: true,
               showCloseButton: true,
               showCancelButton: true})
        .then((willdelete): void => {

      if (willdelete.isConfirmed) {
        this.doMenuUpload(this.replace);
      }
    });
  }

  public isTextType(type: string): boolean {
    return type.startsWith('text') || type === 'application/json';
  }

  public isMappingComplete(): boolean {
    return this.columns.every(column => this.columnMap.has(column) || !this.required.includes(column));
  }

  public isAccordionMapped(accordion: { name: string; value: string; columns: string[]; }): boolean {
    return ( accordion.value ||
             accordion.columns.every( accordionColumn => this.columnMap.get(accordionColumn) !== null) ) ? true : false;
  }

  public getUnsortedColumns(): Array<string> {
    const values: string[] = Array.from(this.columnMap.values());

    return this.jsonColumns
               .filter(jsonColumn => !values.includes(jsonColumn));
  }

  public getAccordionColumns(accordion: { name: string; value: string; columns: string[]; }): Array<string> {
    const indeterminate: boolean = this.isAccordionIndeterminate(accordion);
    const jsonColumns: string[] = this.getJsonColumns(indeterminate ? null : accordion.name);

    if (indeterminate) {
      jsonColumns.push('...');
    }

    return jsonColumns;
  }

  public getAccordionValue(accordion: { name: string;
                                        value: string;
                                        columns: string[]; }): string {
    return (accordion.value) ? accordion.value : (this.isAccordionIndeterminate(accordion)) ? '...' : null;
  }

  public setAccordion(accordion: { name: string;
                                   value: string;
                                   columns: string[]; },
                      value: string,
                      panel: MatExpansionPanel): void {
    for (const column of accordion.columns) {
      this.columnMapChange(column, null);
    }

    accordion.value = value;

    if (value) {
      panel.expanded = false;
    }
  }

  public getJsonColumns(column: string): Array<string> {
    return this.jsonColumns
               .filter(jsonColumn => {
                  const col: string = this.jsonColumnMap.get(jsonColumn);

                  return col == null || col === column;
                });
  }

  public automap(): void {

    for (const column of this.columns) {
      let match = this.jsonColumns
                      .find(c => c.trim().toLowerCase() === column.toLowerCase());

      if(!match){
        for(const s of this.synonyms(column)){
          match = this.jsonColumns
                      .find(c => c.trim().toLowerCase() === s.toLowerCase());
  
          if(match){
            break;
          }
        }
      }

      if (match) {
        this.set(column,
                 match);
      }
    }

    for (const accordion of this.accordions) {
      for (const column of accordion.columns) {
        let match = this.jsonColumns
                        .find(c => c.toLowerCase() === column.toLowerCase());

        if(!match){
          for(const s of this.synonyms(column)){
            match = this.jsonColumns
                        .find(c => c.toLowerCase() === s.toLowerCase());
    
            if(match){
              break;
            }
          }
        }

        if (match) {
          this.set(column,
                   match);
        }
      }
    }
  }

  public clearAll(): void {
    this.columnMap.clear();
    this.jsonColumnMap.clear();
  }

  public columnMapChange(column: string, jsonColumn: string): void {
    const prevJsonColumn: string = this.columnMap.get(column);
    const prevColumn: string = this.jsonColumnMap.get(prevJsonColumn);

    if (prevColumn) {
      this.delete(prevColumn);
    }

    if (prevJsonColumn) {
      this.delete(column);
    }

    this.set(column, jsonColumn);
  }

  public onFile(file: File): void {

    this.jsonArray = null;
    this.jsonColumns = new Array();
    this.columnMap.clear();
    this.jsonColumnMap.clear();
    this.maxJsonColWidth = 0;

    if (file) {
      if (file.type && (this.isTextType(file.type) || file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
        this.file = file;

        if (this.stepper.selectedIndex === 0) {
          this.stepper.selected.completed = true;
        }

        this.stepper.selectedIndex = 1;

        if (this.isTextType(file.type)) {

          file.text()
              .then(text => {

                text.trim();

                if (file.type === 'text/csv' || (file.type !== 'application/json' && !text.startsWith('{') && !text.startsWith('['))) {
                  const obj: any[] = this.fileService.csvToJSON(text);

                  if (obj) {
                    this.jsonArray = obj;
                  }
                }

                if (!this.jsonArray &&
                    (file.type === 'application/json' ||
                     (file.type !== 'text/csv' &&
                      (text.startsWith('{') ||
                       text.startsWith('['))))) {
                  const obj: any = JSON.parse(text);

                  if (obj) {
                    if (Array.isArray(obj)) {
                      this.jsonArray = obj;
                    } else {
                      this.jsonArray = [obj];
                    }
                  }
                }

                this.parseJSON();
              });
        } else {
          file.arrayBuffer().then(arr => {
            const workbook: XLSX.WorkBook = XLSX.read(new Uint8Array(arr), {type: 'array'});

            if (workbook.SheetNames && workbook.SheetNames.length > 0) {
              this.jsonArray = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);

              this.parseJSON();
            }
          });
        }
      } else {
        this.alertService
            .error('Invalid File Format, File must be of type .csv, .json, or .xlsx');
      }
    } else {
      this.file = file;
      this.stepper.steps.first.completed = false;
      this.stepper.selectedIndex = 0;
    }
  }

  private doUserUpload(replace: boolean): void {

    this.isUploading = true;
    this.userService
        .bulkCreate(this.jsonObjects[0],
                     replace)
        .subscribe({

          next: (): void => {

            this.alertService
                .success('Upload started, you will receive an email when it is completed. You may also refresh this page to see the progress',
                         15000);
            this.dialogRef
                .close({reload: true});

            this.isUploading = false;
          }, error: err => {

            this.isUploading = false;
            this.alertService
                .error(err);
          }
        });
  }

  private doMenuUpload(replace: boolean): void {

    this.isUploading = true;

    this.categoryService
        .importMany(this.createMenus(),
                    replace)
        .subscribe({
          next: (): void => {

            this.alertService
                .success('Upload started, you will receive an email when it is completed. You may also refresh this page to see the progress',
                          15000);
            this.dialogRef
                .close({reload: false});

            this.isUploading = false;
          },
          error: err => {
            this.isUploading = false;
            this.alertService
                .error(err);
          }
        });
  }

  private dragOver: (event: DragEvent) => void = (event: DragEvent): void => {
    event.stopPropagation();
    event.preventDefault();

    if (event.dataTransfer.items && event.dataTransfer.items.length > 0) {
      const item: DataTransferItem = event.dataTransfer.items[0];

      if (item.kind === 'file' && (this.isTextType(item.type) || item.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
        event.dataTransfer.dropEffect = 'copy';
        this.dragValid = true;
      } else {
        event.dataTransfer.dropEffect = 'none';
      }
    }
  }

  private dragLeave: (event: DragEvent) => void = (event: DragEvent): void => {
    if (event.screenX === 0 && event.screenY === 0) { // Outside window
      this.dragValid = false;
    }
  }

  private dragDrop: (event: DragEvent) => void = (event: DragEvent): void => {
    event.stopPropagation();
    event.preventDefault();

    const files: FileList = event.dataTransfer.files;

    this.onFile(files[0]);

    this.dragValid = false;
  }

  private parseJSON(): void {

    if (this.jsonArray) {

      for (const row of this.jsonArray) {
        const rowColumns: Array<string> = Object.keys(row);

        for (const column of rowColumns) {
          if (!this.jsonColumns
                   .includes(column)) {
            this.jsonColumns.push(column);
            this.maxJsonColWidth = Math.max(this.maxJsonColWidth, column.length);
          }
        }
      }

      this.automap();
    }
  }

  private isAccordionIndeterminate(accordion: { name: string; value: string; columns: string[]; }): boolean {
    return accordion.columns.some(accordionColumn => this.columnMap.get(accordionColumn) != null);
  }

  private set(column: string, jsonColumn: string): void {
    if (jsonColumn) {
      this.columnMap
          .set(column, jsonColumn);
      this.jsonColumnMap
          .set(jsonColumn, column);
    } else {
      this.delete(column);
    }
  }

  private delete(column: string): void {
    const prev: string = this.columnMap.get(column);

    this.columnMap.delete(column);

    if (prev) {
      this.jsonColumnMap.delete(prev);
    }
  }

  private createMenus(): Array<Category> {

    let unknownItem = 0;
    const menus: Category[] = new Array<Category>();

    for (const json of this.jsonArray) {

      const sectionName: any = json[this.columnMap.get('Section')];
      const barCode: any = json[this.columnMap.get('BarCode')];
      let itemName: any = json[this.columnMap.get('Item')];
      let typeName: any = json[this.columnMap.get('Type')];
      let menuName: any = json[this.columnMap.get('Menu')];

      if(menuName === undefined ||
        menuName.length === 0){
          menuName = 'Unknown';
      }

      if(typeName === undefined ||
        typeName.length === 0){
          typeName = 'Unknown';
      }

      if(itemName === undefined ||
        itemName.length === 0){
          itemName = 'Unknown-' + ++unknownItem;
      }

      let menu: Category = menus.find(menu => menu.name.toLowerCase() === menuName.toLowerCase());

      if (!menu) {
        menu = new Category();
        menu.name = menuName;
        menu.sections = new Array();

        menus.push(menu);
      }

      let section: Section = menu.sections
                                 .find(section => section.name?.toLowerCase() === sectionName?.toLowerCase());

      if (!section) {
        section = new Section();
        section.name = sectionName;
        section.items = new Array();

        menu.sections
            .push(section);
      }

      let item: Item = section.items.find(item => item.name === itemName);

      if (!item) {
        const recipe: Recipe = new Recipe();
        const salesGroup: SalesGroup = new SalesGroup();
        const price = json[this.columnMap.get('Price')];
        const sides = json[this.columnMap.get('Sides')];

        salesGroup.name = typeName

        item = new Item();
        item.name = itemName;
        item.price = price ? Number(price) * 100 : 0;
        item.sideCount = sides > 0 ? Number(sides) : 0;
        item.recipe = recipe;

        recipe.name = item.name;
        recipe.barCode = barCode;
        recipe.salesGroup = salesGroup;

        section.items
               .push(item);
      }
    }

    menus.sort((a, b): number => a.name?.localeCompare(b.name));

    for (const menu of menus) {
      menu.sections.sort((a, b): number => a.name.localeCompare(b.name));
    }

    return menus;
  }

  private createUsers(): Array<User> {
    const users: User[] = new Array<User>();

    for (let i: number = 0; i < this.jsonArray.length; i++) {

      const json: any = this.jsonArray[i];
      const firstName: any = json[this.columnMap.get('First Name')];
      const lastName: any = json[this.columnMap.get('Last Name')];
      const email: any = json[this.columnMap.get('Email')];
      const description: any = json[this.columnMap.get('Description')];
      const changePassword: any = json[this.columnMap.get('Change Password')];
      const locale: any = json[this.columnMap.get('Locale')];
      const alerts: string = json[this.columnMap.get('Alerts')];
      const securities: string = json[this.columnMap.get('Securities')];
      const settings: string = json[this.columnMap.get('Settings')];
      const employeeNumber: any = json[this.columnMap.get('Employee Number')];
      const lastLogin: any = json[this.columnMap.get('Last Login')];
      const track1: any = json[this.columnMap.get('Track1')];
      const maxComp: any = json[this.columnMap.get('Max Comp')];
      const cellNumber: any = json[this.columnMap.get('Cell Number')];
      const phoneNumber: any = json[this.columnMap.get('Phone Number')];
      const hourlyWeight: any = json[this.columnMap.get('Hourly Weight')];
      const tipWeight: any = json[this.columnMap.get('Tip Weight')];

      let address;
      let city;
      let postalCode;

      for (const accordion of this.accordions) {
        if (accordion.name === 'Address') {
          if (accordion.value) {
            address = json[accordion.value];
          } else {
            address = json[this.columnMap.get('Address')];
            city = json[this.columnMap.get('City')];
            postalCode = json[this.columnMap.get('Postal Code')];
          }
        }
      }

      let user: User = users.find(user => user.firstName === firstName && user.lastName === lastName);

      if (!user) {
        user = new User();
        user.firstName = firstName;
        user.lastName = lastName;
        user.email = email;
        user.description = description;
        user.changePassword = changePassword;
        user.locale = locale;
        user.alerts = new Array();
        user.settings = new Array();
        user.employeeNumber = employeeNumber;
        user.lastLogin = new Date(lastLogin);
        user.track1 = track1;
        user.maxComp = maxComp;
        user.cellNumber = cellNumber;
        user.phoneNumber = phoneNumber;
        user.address = address;
        user.city = city;
        user.postalCode = postalCode;
        user.hourlyWages = hourlyWeight;
        user.tipWeight = tipWeight;
        user.securities = new Array();
        user.storeId = this.sessionService.getStore().id;

        users.push(user);
      }

      if (alerts && alerts.trim().length > 0) {
        let startProperty: string = null;
        let alert: Alert = null;

        for (let property of alerts.split('",')) {
          property = property.split('\'').join('').split('"').join('');

          const keyValue: string[] = property.split(',');

          if (!startProperty) {
            startProperty = keyValue[0];
          }

          if (keyValue[0] === startProperty) {
            if (alert) {
              user.alerts.push(alert);
            }

            alert = new Alert();
          }

          if (keyValue[0] === 'settings') {

          } else {
            const numValue: number = Number(keyValue[1]);

            alert[keyValue[0]] = isNaN(numValue) ? keyValue[1] : numValue;
          }
        }

        if (alert) {
          user.alerts.push(alert);
        }
      }

      if (securities &&
          securities.trim().length > 0) {

        user.securities = [];
        const securitiesStrings = securities.split('""')
                                            .filter(entry => entry.trim());

        securitiesStrings.forEach(securityString => {

          let parts = securityString.split('","')
                                    .map(s => s.replace(/^"|"$/g, ''));

          let security = new Security();
          let currentRole = null;

          parts.forEach(part => {

            const [key, value] = part.split(',');

            if (key === 'storeId') {

              if (security.storeId) {

                if (currentRole) {

                  security.roles
                          .push(currentRole);

                }

                user.securities
                    .push(security);

              }

              security = new Security();
              security.roles = Array<Role>();
              security.permissions = Array<Permission>();
              security.storeId = parseInt(value, 10);
              currentRole = null;

            } else if (key === 'id' &&
                       !currentRole) {

              security.id = parseInt(value, 10);

            } else if (key === 'name' &&
                       !currentRole) {

              security.name = value;

            } else if (key === 'roles') {

              if (currentRole) {

                security.roles
                        .push(currentRole);

              }

              currentRole = new Role();
              const roleId = part.split('"id,')[1];
              currentRole.id = parseInt(roleId, 10);

            } else if (currentRole &&
                       key === 'id') {

              security.roles
                      .push(currentRole);

              currentRole = new Role();
              currentRole.id = parseInt(value, 10);

            } else if (currentRole &&
                       key === 'name') {

              currentRole.name = value;

            }

          });

          let index: number = securities.lastIndexOf('"permissions,');
          let accessPermissions: string = securities.substring(index + '"permissions,'.length);

          for (let property of accessPermissions.split('",')) {

            property = property.replace('\'', '')
                               .replace('"', '');

            const keyValue: string[] = property.split(',');

            if (!security?.permissions) {

              security.permissions = new Array<Permission>();

            }

            security.permissions
                    .push(new Permission(keyValue[0], keyValue[1]));

          }

          if (currentRole) {

            security.roles
                    .push(currentRole);

          }

          if (security.storeId) {

            user.securities
                .push(security);

          }

        });

      }

      if (settings && settings.trim().length > 0) {
        for (let property of settings.split(',"')) {
          property = property.split('\'').join('').split('"').join('');

          const keyValue: string[] = property.split(',');

          if (keyValue.length == 2) {
            const setting: NameValue = new NameValue();

            setting.name = keyValue[0];
            setting.value = keyValue[1];

            user.settings.push(setting);
          }
        }
      }
    }

    users.sort((a, b): number => a.firstName.localeCompare(b.firstName));

    return users;
  }

  private addRoles(users: Array<User>): void {
    this.roleService
        .list()
        .subscribe({
      next: (data): void => {

        const roles: Role[] = new Array<Role>();

        for (const d of data) {
          roles.push(new Role().load(d));
        }

        for (const user of users) {
          if (user.securities) {
            for (const access of user.securities) {
              if (access.roles) {
                for (const role of access.roles) {
                  if (roles.every(r => r.id != role.id) && roles.every(r => r.name != role.name)) {
                    roles.push(new Role().load(role));
                  }
                }
              }
            }
          }
        }

        roles.sort((a, b): number=> a.name?.localeCompare(b.name));
        this.jsonObjects.push(roles);
      },
      error: err => {
        this.alertService.error(err);
      }
    });
  }

  private loadRecipes(): void {

    this.recipeService
        .list()
        .subscribe({
      next: (data): void => {

        this.recipes = new Array<Recipe>();

        data.forEach(d => {
          this.recipes
              .push(new Recipe().load(d));
        });

      },
      error: err => {
        this.alertService.error(err);
      }
    });
  }

  private synonyms(name: string): Array<string>{
    let synonyms = new Array();

    switch(name){

      case 'Menu':
        synonyms = ['Category'];
        break;

      case 'Section':
        synonyms = ['SubSection', 'Sub'];
        break;

      case 'Item':
        synonyms = ['Items', 'Menu Item', 'MenuItem', 'Menu Items'];
        break;

      case 'Type':
          synonyms = ['Group', 'SalesGroup', 'Sales Group', 'Revenue Center', 'Center'];
          break;

      case 'Price':
          synonyms = ['Cost', '$', 'Amount'];
          break;

      case 'BarCode':
          synonyms = ['UPC', 'Shortcut'];
          break;
    }

    return synonyms;
  }
}
