import { Input } from '@angular/core';
import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MatSort  } from '@angular/material/sort';
import { MatDialog  } from '@angular/material/dialog';
import { MatPaginator  } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import { SessionService } from 'src/app/service/session.service';
import { Customer } from 'src/app/model/customer/customer.model';
import { TimeService } from 'src/app/service/utils/time.service';

@Component({
  selector: 'app-customers-preview',
  templateUrl: './customers-preview.component.html',
  styleUrls: ['./customers-preview.component.scss'],
})
export class CustomersPreviewComponent implements OnInit {

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  @Input() customers: Array<Customer>;
  @Input() uploadedColumns: string[];

  public dataSource: MatTableDataSource<Customer> = new MatTableDataSource<Customer>();

  constructor(public dialog: MatDialog,
              public timeService: TimeService,
              public sessionService: SessionService) {
  }

  public ngOnInit(): void {
    this.updateDataSource();
  }

  private updateDataSource(): void {

    let data: Array<Customer> = new Array<Customer>();
    data = this.customers;

    this.dataSource = new MatTableDataSource(data);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public formatColumnName(columnName: string): string {

    const words = columnName.replace(/([A-Z])/g, ' $1')
                            .trim();
    return words.charAt(0)
                .toUpperCase() +
           words.slice(1)
                .toLowerCase();

  }

}
