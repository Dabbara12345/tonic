import { TestBed } from "@angular/core/testing";
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture } from "@angular/core/testing";

import { CustomersUploadComponent } from 'src/app/common/components/upload/customers-upload/customers-upload.component';

describe('CustomersUploadComponent', () => {
  let component: CustomersUploadComponent;
  let fixture: ComponentFixture<CustomersUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomersUploadComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomersUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('method1', () => {
    it('should ...', () => {
      expect(component).toBeTruthy();
    });
  });
});
