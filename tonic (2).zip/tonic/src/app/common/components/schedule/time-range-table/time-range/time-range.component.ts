import { AfterViewInit } from '@angular/core';
import { Component } from '@angular/core';
import { ElementRef } from '@angular/core';
import { Input } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { QueryList } from '@angular/core';
import { TemplateRef } from '@angular/core';
import { ViewChild } from '@angular/core';
import { ViewChildren } from '@angular/core';

import { PopoverDirective } from 'ngx-bootstrap/popover';

import { Time } from 'src/app/model/config/time.model';
import { Range} from 'src/app/model/config/range.model';
import { SessionService } from 'src/app/service/session.service';

@Component({
  selector: 'app-time-range',
  templateUrl: './time-range.component.html',
  styleUrls: ['./time-range.component.scss']
})

export class TimeRangeComponent implements AfterViewInit, OnDestroy {

  @ViewChild('element') elementRef: ElementRef;
  @ViewChildren(PopoverDirective) popoverDirs: QueryList<PopoverDirective>;

  @Input() ranges: Array<Range<Time>> = new Array();

  private originPercent: number;
  private newRange: Range<Time>;
  private stretchRange: Range<Time>;
  private selectedRange: Range<Time>;

  /**
   * Identifier used to attribute a touch event to a particular slider.
   * Will be undefined if one of the following conditions is true:
   * - The user isn't dragging using a touch device.
   * - The browser doesn't support `Touch.identifier`.
   * - Dragging hasn't started yet.
   */
  private touchId: number | undefined;

  /** Keeps track of the last pointer event that was captured by the slider. */
  private lastPointerEvent: MouseEvent | TouchEvent;

  public isDrag: boolean = false;
  private isSliding: boolean = false;

  private intervalNum: number;

  constructor(public sessionService: SessionService) {
    this.intervalNum = sessionService.isMobile() ? 24 : 48;
  }

  public ngAfterViewInit(): void {

    const element: any = this.elementRef.nativeElement;

    element.addEventListener('mousedown', this.pointerDown);
    element.addEventListener('touchstart', this.pointerDown);
  }

  public ngOnDestroy(): void {
    const element: any = this.elementRef.nativeElement;

    element.removeEventListener('mousedown', this.pointerDown);
    element.removeEventListener('touchstart', this.pointerDown);

    this.lastPointerEvent = undefined;
    this.removeGlobalEvents();
  }

  private roundToInterval(percent: number): number {

    if (percent <= 0) {
      percent = 0;
    } else if (percent >= 100) {
      percent = 100;
    } else {
      const intervalSize: number = 100 / this.intervalNum; //One tick every 30 minutes or 60 minutes on mobile

      percent = Math.round(percent / intervalSize) * intervalSize;
    }

    return percent;
  }

  private positionToPercent(position: number): number {
    return Math.min(100, Math.max(0, (position / this.elementRef.nativeElement.clientWidth) * 100));
  }

  private getTimeRangeFromPercent(percent: number): Range<Time> {
    let timeRange: Range<Time>;

    for (const range of this.ranges) {
      if (percent >= range.start.percent && percent <= range.end.percent) {
        timeRange = range;
        break;
      }
    }

    return timeRange;
  }

  private getPopover(target): PopoverDirective {
    let match: PopoverDirective;

    const index: number = parseInt(target.id.substring(target.id.indexOf('-') + 1));

    if (index <= this.ranges.length) {
      const range: Range<Time> = this.ranges[index];

      if (this.selectedRange === range) {
        for (const popoverDir of this.popoverDirs) {
          const popover: TemplateRef<any> = popoverDir.popover as TemplateRef<any>;

          if (popover.elementRef
                     .nativeElement
                     .parentElement === target) {
            match = popoverDir;
          }
        }
      }
    }

    return match;
  }

  private isTouchEvent(event: MouseEvent | TouchEvent): event is TouchEvent {
    return event.type[0] === 't';
  }

  private pointerDown = (event: TouchEvent | MouseEvent): void => {

    if (!this.isSliding && (this.isTouchEvent(event) || event.button === 0)) {
      const target: any = event.target as any;

      this.touchId = this.isTouchEvent(event) ? this.getTouchId(event, target) : undefined;

      const pointerPosition: number = this.getPointerPosition(event, this.touchId);

      this.isSliding = true;

      this.addGlobalEvents(this.isTouchEvent(event));

      if (pointerPosition) {
        if (event.cancelable) {
          event.preventDefault();
        }

        let pointerDownPercent: number = this.positionToPercent(pointerPosition);

        if (target === this.elementRef.nativeElement) {
          if (!this.getTimeRangeFromPercent(pointerDownPercent)) {
            pointerDownPercent = this.roundToInterval(pointerDownPercent);

            this.newRange = new Range<Time>(new Time(pointerDownPercent), new Time(pointerDownPercent));
            this.lastPointerEvent = event;
            this.originPercent = pointerDownPercent;

            this.ranges.push(this.newRange);
          }
        } else if (target.id) {
          if (target.id.startsWith('rangeCenter')) {
            this.selectedRange = this.getTimeRangeFromPercent(pointerDownPercent);

            if (this.selectedRange) {
              pointerDownPercent = this.roundToInterval(pointerDownPercent);

              this.originPercent = pointerDownPercent - this.selectedRange.start.percent;
            }
          } else if (target.id === 'leftStretchBorder' || target.id === 'rightStretchBorder') {
            this.stretchRange = this.getTimeRangeFromPercent(pointerDownPercent);

            if (this.stretchRange) {
              this.selectedRange = this.stretchRange;

              if (target.id === 'leftStretchBorder') {
                this.originPercent = this.stretchRange.end.percent;
              } else if (target.id === 'rightStretchBorder') {
                this.originPercent = this.stretchRange.start.percent;
              }
            }

          }
        }
      }
    }
  }

  private pointerUp = (event: TouchEvent | MouseEvent): void => {
    event.preventDefault();

    this.removeGlobalEvents();
    this.isSliding = false;
    this.touchId = undefined;

    if (this.newRange) {
      const start: Time = this.newRange.start;
      const end: Time = this.newRange.end;

      if (start.percent === end.percent) {
        const percent: number = start.percent;
        const defaultSize: number = 100 / 12; //2 hours
        let min: number = 0;
        let max: number = 100;

        for (const range of this.ranges) {
          if (range !== this.newRange) {
            if (range.start.percent >= percent) {
              if (range.start.percent < max) {
                max = range.start.percent;
              }
            } else if (range.end.percent <= percent) {
              if (range.end.percent > min) {
                min = range.end.percent;
              }
            }
          }
        }

        if (max - min < defaultSize) {
          start.percent = min;
          end.percent = max;
        } else if (percent + defaultSize > max) {
          start.percent = max - defaultSize;
          end.percent = max;
        } else {
          start.percent = percent;
          end.percent = percent + defaultSize;
        }
      }

      this.newRange = undefined;
    }

    if (this.selectedRange && !this.isDrag && (this.isTouchEvent(event) || event.button === 0)) {
      let target: any = event.target as any;

      this.touchId = this.isTouchEvent(event) ? this.getTouchId(event, target) : undefined;

      const pointerPosition: number = this.getPointerPosition(event, this.touchId);

      if (pointerPosition && target.id) {
        if (target.id.endsWith('StretchBorder')) {
          target = target.parentElement;
        }

        if (target.id.startsWith('rangeCenter')) {
          this.getPopover(target)?.toggle();
        }
      }
    }

    this.isDrag = false;
    this.originPercent = undefined;
    this.stretchRange = undefined;
    this.selectedRange = undefined;

    document.documentElement.style.cursor = 'auto';
  }

  private pointerMove = (event: TouchEvent | MouseEvent): void => {

    if (this.isSliding) {
      const pointerPosition: number = this.getPointerPosition(event, this.touchId);

      if (pointerPosition) {
        event.preventDefault();

        this.lastPointerEvent = event;

        if (this.newRange) {
          this.resize(this.newRange, pointerPosition);
        } else if (this.stretchRange) {
          this.resize(this.stretchRange, pointerPosition);
        } else if (this.selectedRange) {
          this.move(this.selectedRange, pointerPosition);
        }
      }
    }

    for (const popoverDir of this.popoverDirs) {
      if (popoverDir.isOpen) {
        popoverDir.hide();
      }
    }

    this.isDrag = true;
  }

  private move(timeRange: Range<Time>, pointerPosition: number): void {
    let percent: number = this.roundToInterval(this.positionToPercent(pointerPosition));
    const start: number = timeRange.start.percent;
    const end: number = timeRange.end.percent;
    const width: number = end - start;
    let min: number = 0;
    let max: number = 100;
    let newStart: number = percent - this.originPercent;

    for (const range of this.ranges) {
      if (range !== timeRange) {
        if (range.start.percent >= end) {
          if (range.start.percent < max) {
            max = range.start.percent;
          }
        } else
        if (range.end.percent <= start) {
          if (range.end.percent > min) {
            min = range.end.percent;
          }
        }
      }
    }

    if (newStart < min) {
      newStart = min;
    } else if (newStart + width > max) {
      newStart = max - width;
    }

    timeRange.start.percent = newStart;
    timeRange.end.percent = newStart + width;

    document.documentElement.style.cursor = 'move';
  }

  private resize(timeRange: Range<Time>, pointerPosition: number): void {
    let percent: number = this.roundToInterval(this.positionToPercent(pointerPosition));
    const start: number = timeRange.start.percent;
    const end: number = timeRange.end.percent;
    const origin: number = this.originPercent;

    if (percent != origin) { //Don't extend past other ranges
      for (const range of this.ranges) {
        if (range !== timeRange) {
          if (percent < origin) {
            if (origin >= range.end.percent && percent < range.end.percent) {
              percent = range.end.percent;
            }
          } else if (percent > origin) {
            if (origin <= range.start.percent && percent > range.start.percent) {
              percent = range.start.percent;
            }
          }
        }
      }

      if (percent < origin) {
        timeRange.start.percent = percent;

        if (start === origin) {
          timeRange.end.percent = start;
        }
      } else if (percent > origin) {
        timeRange.end.percent = percent;

        if (end === origin) {
          timeRange.start.percent = end;
        }
      }

      document.documentElement.style.cursor = 'col-resize';
    }
  }

  private getPointerPosition(event: MouseEvent | TouchEvent, id: number | undefined): number {
    let point: number;

    if (this.isTouchEvent(event)) {
      // The `identifier` could be undefined if the browser doesn't support `TouchEvent.identifier`.
      // If that's the case, attribute the first touch to all active sliders. This should still cover
      // the most common case while only breaking multi-touch.
      let touch: Touch;

      if (typeof id === 'number') {
        touch = this.findMatchingTouch(event.touches, id) || this.findMatchingTouch(event.changedTouches, id);
      } else {
        // `touches` will be empty for start/end events so we have to fall back to `changedTouches`.
        touch = event.touches[0] || event.changedTouches[0];
      }

      point = touch.clientX;

    } else {
      point = event.clientX;
    }

    return point - this.elementRef.nativeElement.getBoundingClientRect().x;
  }

  private addGlobalEvents(isTouch: boolean): void {
    document.addEventListener(isTouch ? 'touchmove' : 'mousemove', this.pointerMove);
    document.addEventListener(isTouch ? 'touchend' : 'mouseup', this.pointerUp);

    if (isTouch) {
      document.addEventListener('touchcancel', this.pointerUp);
    }

    if (typeof window !== 'undefined' && window) {
      window.addEventListener('blur', this.windowBlur);
    }
  }

  /** Removes any global event listeners that we may have added. */
  private removeGlobalEvents(): void {
    document.removeEventListener('mousemove', this.pointerMove);
    document.removeEventListener('mouseup', this.pointerUp);
    document.removeEventListener('touchmove', this.pointerMove);
    document.removeEventListener('touchend', this.pointerUp);
    document.removeEventListener('touchcancel', this.pointerUp);

    if (typeof window !== 'undefined' && window) {
      window.removeEventListener('blur', this.windowBlur);
    }
  }

  /** Finds a `Touch` with a specific ID in a `TouchList`. */
  private findMatchingTouch(touches: TouchList, id: number): Touch | undefined {
    for (let i: number = 0; i < touches.length; i++) {
      if (touches[i].identifier === id) {
        return touches[i];
      }
    }

    return undefined;
  }

  private getTouchId(event: TouchEvent, element: HTMLElement): number | undefined {
    for (let i: number = 0; i < event.touches.length; i++) {
      const target: HTMLElement = event.touches[i].target as HTMLElement;

      if (element === target || element.contains(target)) {
        return event.touches[i].identifier;
      }
    }

    return undefined;
  }

  /** Called when the window has lost focus. */
  private windowBlur = (): void => {
    // If the window is blurred while dragging we need to stop dragging because the
    // browser won't dispatch the `mouseup` and `touchend` events anymore.
    if (this.lastPointerEvent) {
      this.pointerUp(this.lastPointerEvent);
    }
  };

  public startChange(event: any, range: Range<Time>): void {
    const time: Time = new Time(event.target.value);

    if (time.percent < range.end.percent) {
      this.setStart(time, range);
    } else if (time.percent > range.end.percent) {
      range.start.percent = range.end.percent;

      this.setEnd(time, range);
    }
  }

  public endChange(event: any, range: Range<Time>): void {
    const time: Time = new Time(event.target.value);

    if (time.percent === 0) { //If setting to 12:00 AM
      time.percent = 100;
    }

    if (time.percent > range.start.percent) {
      this.setEnd(time, range);
    } else if (time.percent < range.start.percent) {
      range.end.percent = range.start.percent;

      this.setStart(time, range);
    }
  }

  private setStart(time: Time, range: Range<Time>): void {
    let min: number = 0;

    for (const r of this.ranges) {
      if (r !== range && r.end.percent < range.start.percent && r.end.percent > min) {
        min = r.end.percent;
      }
    }

    range.start.percent = Math.max(min, time.percent);
  }

  private setEnd(time: Time, range: Range<Time>): void {
    let max: number = 100;

    for (const r of this.ranges) {
      if (r !== range && r.start.percent > range.end.percent && r.start.percent < max) {
        max = r.start.percent;
      }
    }

    range.end.percent = Math.min(max, time.percent);
  }

  public deleteRange(range: Range<Time>): void {
    this.ranges.splice(this.ranges.indexOf(range), 1);
  }
}
