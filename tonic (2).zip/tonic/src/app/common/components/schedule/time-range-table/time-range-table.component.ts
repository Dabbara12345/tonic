import { Input } from '@angular/core';
import { OnInit } from '@angular/core';
import { Component } from '@angular/core';

import { Time } from 'src/app/model/config/time.model';
import { Range} from 'src/app/model/config/range.model';
import { SessionService } from 'src/app/service/session.service';

@Component({
  selector: 'app-time-range-table',
  templateUrl: './time-range-table.component.html',
  styleUrls: ['./time-range-table.component.scss']
})
export class TimeRangeTableComponent implements OnInit {

  @Input() weeklySchedule: Map<number, Array<Range<Time>>>;

  public days: string[] = new Array<string>();

  constructor(private sessionService: SessionService) {}

  public ngOnInit(): void {
    if (this.sessionService
            .isMobile()) {
      this.days.push('S');
      this.days.push('M');
      this.days.push('T');
      this.days.push('W');
      this.days.push('T');
      this.days.push('F');
      this.days.push('S');
    } else {
      this.days.push('Sunday');
      this.days.push('Monday');
      this.days.push('Tuesday');
      this.days.push('Wednesday');
      this.days.push('Thursday');
      this.days.push('Friday');
      this.days.push('Saturday');
    }

    for (let i: number = 0; i < this.days.length; i++) {
      if (!this.weeklySchedule.has(i)) {
        this.weeklySchedule.set(i, new Array());
      }
    }
  }
}
