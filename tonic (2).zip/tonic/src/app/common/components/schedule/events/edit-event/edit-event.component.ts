import { Component } from '@angular/core';
import { Inject } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { ValidatorFn } from '@angular/forms';
import { Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

import * as moment from 'moment';
import { Moment } from 'moment-timezone';

import { Time } from 'src/app/model/config/time.model';
import { Range } from 'src/app/model/config/range.model';
import { Anchor } from 'src/app/model/config/anchor.enum';
import { EventInfo } from 'src/app/model/config/event-info.model';
import { Frequency } from 'src/app/model/config/frequency.enum';
import { AlertService } from 'src/app/service/utils/alert.service';

@Component({
  selector: 'app-edit-event',
  templateUrl: './edit-event.component.html',
  styleUrls: ['./edit-event.component.scss']
})
export class EditEventComponent {

  public form: FormGroup;

  public isNew: boolean = true;
  public oneDay: boolean = true;
  public allDay: boolean = true;
  public data: EventInfo = new EventInfo();
  public name: FormControl;
  public date: FormControl;
  public startDate: FormControl;
  public endDate: FormControl;
  public fromTime: FormControl;
  public toTime: FormControl;
  public holidays: string[] = ['New Year\'s Eve/Day', 'Valentine\'s Day', 'St. Patrick\'s Day', 'Mother\'s Day', 'Memorial Day', 'Father\'s Day', 'Labor Day', 'Halloween',
              'Veteran\'s Day', 'Thanksgiving', 'Christmas Eve', 'Christmas'];
  public anchors: Anchor[] = Object.values(Anchor);
  public frequencies: Frequency[] = Object.values(Frequency);
  public frequencyOptions: string[] = ['Does not repeat', 'Monthly', 'Annually'];

  constructor(public dialogRef: MatDialogRef<EditEventComponent>,
              private fb: FormBuilder,
              private alertService: AlertService,
             @Inject(MAT_DIALOG_DATA) data: EventInfo) {
    if (data) {
      this.data.load(data);
      this.isNew = false;

      this.setCheckboxes();
    } else {
      this.data.name = 'Event';
      this.data.dateRange = new Range<Date>(new Date(), new Date());
      this.data.timeRange = new Range<Time>(new Time(0, 0), new Time(24, 0));
      this.data.frequency = null;
      this.data.anchor = Anchor.Day;
    }

    this.name = new FormControl(this.data.name, [this.emptyValidator]);
    this.date = new FormControl(this.data.dateRange.start, [Validators.required]);
    this.startDate = new FormControl(this.data.dateRange.start, [this.startDateValidator]);
    this.endDate = new FormControl(this.data.dateRange.end, [this.endDateValidator]);
    this.fromTime = new FormControl(this.data.timeRange.start.get24HourString(), [this.fromTimeValidator()]);
    this.toTime = new FormControl(this.data.timeRange.end.get24HourString(), [this.toTimeValidator()]);

    this.form = this.fb.group({
      'name': this.name,
      'date': this.date,
      'startDate': this.startDate,
      'endDate': this.endDate,
      'fromTime': this.fromTime,
      'toTime': this.toTime
    });

    if (this.allDay) {
      this.data.timeRange = new Range<Time>(new Time(0, 0), new Time(24, 0)); //Default value of FormControl changes 24:00 to 12:00 AM
    }
  }

  private startDateValidator(control: FormControl): any {
    return (!control.value) ? {'start': true} : null;
  }

  private endDateValidator(control: FormControl): any {
    return (!control.value) ? {'end': true} : null;
  }

  private emptyValidator(control: FormControl): any {
    const valid: boolean = control.value ? control.value.trim().length > 0 : false;

    return (valid) ? null : {'empty': true};
  }

  private fromTimeValidator(): ValidatorFn {
    return (control: FormControl): {[key: string]: boolean} | null => {
      const timeRange: Range<Time> = this.data.timeRange;
      let error: any = null;

      timeRange.start = (control.value && control.value.length > 0) ? new Time(control.value) : null;

      if (!timeRange.start) {
        error = {'from': true};
      } else if (timeRange.end && timeRange.start.percent > timeRange.end.percent) {
        error = {'invalid': true};
      }

      return error;
    };
  }

  private toTimeValidator(): ValidatorFn {
    return (control: FormControl): {[key: string]: boolean} | null => {
      const timeRange: Range<Time> = this.data.timeRange;
      let error: any = null;

      timeRange.end = (control.value && control.value.length > 0) ? new Time(control.value) : null;

      if (!timeRange.end) {
        error = {'to': true};
      } else if (timeRange.end && timeRange.start.percent > timeRange.end.percent) {
        error = {'invalid': true};
      }

      return error;
    };
  }

  public fromChanged(): void {
    this.toTime.updateValueAndValidity();
  }

  public toChanged(): void {
    this.fromTime.updateValueAndValidity();
  }

  private setCheckboxes(): void {
    this.oneDay = moment(this.data.dateRange.start).isSame(moment(this.data.dateRange.end), 'day');
    this.allDay = this.data.timeRange.end.percent - this.data.timeRange.start.percent == 100
  }

  public getAnchors(): Array<string> {
    const anchors: string[] = new Array<string>();
    const tempEvent: EventInfo = new EventInfo().load(this.data);

    for (const anchor of this.anchors) {
      tempEvent.anchor = anchor;
      anchors.push(tempEvent.getAnchorString())
    }

    return anchors;
  }

  public getMatchingHoliday(): string {
    return this.holidays.find((holiday): boolean => this.data.equals(this.getPreset(holiday)));
  }

  public selectPreset(preset: string): void {
    this.data.load(this.getPreset(preset));

    this.setCheckboxes();
    (this.form as any).submitted = true;
  }

  private getPreset(preset: string): EventInfo {
    const data: EventInfo = new EventInfo();

    data.name = preset;
    data.timeRange = new Range<Time>(new Time(0, 0), new Time(24, 0));
    data.frequency = Frequency.Yearly;
    data.anchor = Anchor.Day;

    switch(preset) {
      case 'New Year\'s Eve/Day':
        this.setDateRange(data, 11, 31, 1);
        break;
      case 'Valentine\'s Day':
        this.setDateRange(data, 1, 14);
        break;
      case 'St. Patrick\'s Day':
        this.setDateRange(data, 2, 17);
        break;
      case 'Mother\'s Day':
        this.setWeekdayRange(data, 4, 2, 0);
        break;
      case 'Memorial Day':
        this.setWeekdayRange(data, 4, -1, 1);
        break;
      case 'Father\'s Day':
        this.setWeekdayRange(data, 5, 3, 0);
        break;
      case 'Labor Day':
        this.setWeekdayRange(data, 8, 1, 1);
        break;
      case 'Labor Day Weekend':
        this.setWeekdayRange(data, 8, 1, 1, -2);
        break;
      case 'Halloween':
        this.setDateRange(data, 9, 31);
        break;
      case 'Veteran\'s Day':
        this.setDateRange(data, 10, 11);
        break;
      case 'Thanksgiving':
        this.setWeekdayRange(data, 10, 4, 4);
        break;
      case 'Christmas Eve':
        this.setDateRange(data, 11, 24);
        break;
      case 'Christmas':
        this.setDateRange(data, 11, 25);
        break;
    }

    return data;
  }

  private setWeekdayRange(data: EventInfo, month: number, week: number, weekday: number, addlDays?: number): void {

    const start: Moment = moment().month(month);

    if (week < 0) {
      let day: number = start.endOf('month').day();

      data.anchor = Anchor.End;

      start.day(day < weekday ? weekday - 7 : weekday)
           .add((week + 1) * 7, 'day')

      if (start.isBefore(moment())) {
        day = start.add(1, 'year')
                   .month(month)
                   .endOf('month')
                   .day();

        start.day(day < weekday ? weekday - 7 : weekday)
             .add((week + 1) * 7, 'day');
      }
    } else {
      let day: number = start.startOf('month')
                     .day();

      data.anchor = Anchor.Start;

      start.day(weekday < day ? weekday + 7 : weekday)
           .add((week - 1) * 7, 'day');

      if (start.isBefore(moment())) {
        day = start.add(1, 'year')
                   .month(month)
                   .startOf('month')
                   .day();

        start.day(weekday < day ? weekday + 7 : weekday)
             .add((week - 1) * 7, 'day');
      }
    }

    data.dateRange = new Range<Date>(start.toDate(), start.add(addlDays).toDate());
  }

  private setDateRange(data: EventInfo, month: number, date: number, addlDays?: number): void {
    const start: Moment = moment().month(month)
                          .date(date);

    data.dateRange = new Range<Date>(start.toDate(), moment(start).add(addlDays, 'day').toDate());
  }

  public dateChanged(date: Date): void {
    this.data.dateRange.start = date;
    this.data.dateRange.end = date;
  }

  public oneDayChanged(checked: boolean): void {
    if (checked) {
      if (this.data.dateRange.start) {
        this.data.dateRange.end = this.data.dateRange.start;
      } else if (this.data.dateRange.end) {
        this.data.dateRange.start = this.data.dateRange.end;
      } else {
        this.data.dateRange = new Range<Date>(new Date(), new Date());
      }
    }

    this.oneDay = checked;
  }

  public allDayChanged(checked: boolean): void {
    if (checked) {
      this.data.timeRange = new Range<Time>(new Time(0, 0), new Time(24, 0));
    } else {
      this.data.timeRange = new Range<Time>(new Time(0, 0), new Time(23, 59));
    }

    this.allDay = checked;
  }

  public save(): void {
    if (this.data.name && this.data.name.length > 0) {
      if (this.data.dateRange.start || this.data.dateRange.end) {
        if (this.data.dateRange.start) {
          if (this.data.dateRange.end) {
            if (moment(this.data.dateRange.start).isSameOrBefore(moment(this.data.dateRange.end, 'day'))) {
              if (this.data.timeRange.start || this.data.timeRange.end) {
                if (this.data.timeRange.start) {
                  if (this.data.timeRange.end) {
                    if (this.data.timeRange.start.percent <= this.data.timeRange.end.percent) {
                      this.dialogRef.close({data: this.data});
                    } else {

                      this.alertService.error('Unable to Save, Start of time range is after end of time range');
                    }
                  } else {

                    this.alertService.error('Unable to Save, nd of time range is not defined');
                  }
                } else {

                  this.alertService.error('Unable to Save, tart of time range is not defined');
                }
              } else {

                this.alertService.error('Unable to Save, ime range is not defined');
              }
            } else {

              this.alertService.error('Unable to Save, Start of date range is after end of date range');
            }
          } else {

            this.alertService.error('Unable to Save, nd of date range is not defined');
          }
        } else {

          this.alertService.error('Unable to Save, tart of date range is not defined');
        }
      } else {

        this.alertService.error('Unable to Save, ate range is not defined');
      }
    } else {

      this.alertService.error('Unable to Save, ame cannot be empty');
    }
  }

  public delete(): void {
    this.dialogRef.close({data: this.data,
                          delete: true});
  }

}
