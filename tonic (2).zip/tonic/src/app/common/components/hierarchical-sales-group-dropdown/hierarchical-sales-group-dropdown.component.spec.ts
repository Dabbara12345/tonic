import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HierarchicalSalesGroupDropdownComponent } from './hierarchical-sales-group-dropdown.component';

describe('HierarchicalSalesGroupDropdownComponent', () => {
  let component: HierarchicalSalesGroupDropdownComponent;
  let fixture: ComponentFixture<HierarchicalSalesGroupDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HierarchicalSalesGroupDropdownComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HierarchicalSalesGroupDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
