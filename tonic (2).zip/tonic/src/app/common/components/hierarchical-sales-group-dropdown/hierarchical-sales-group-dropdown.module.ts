import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressBarModule } from '@angular/material/progress-bar';

import { SharedModule } from '../../shared.module';
import { HierarchicalSalesGroupDropdownComponent } from './hierarchical-sales-group-dropdown.component';

@NgModule({
  imports: [
    FormsModule,
    SharedModule,
    CommonModule,
    MatIconModule,
    MatSelectModule,
    MatProgressBarModule
  ],
  declarations: [
    HierarchicalSalesGroupDropdownComponent
  ],
  exports: [
    HierarchicalSalesGroupDropdownComponent
  ]
})
export class HierarchicalSalesGroupDropdownModule { }
