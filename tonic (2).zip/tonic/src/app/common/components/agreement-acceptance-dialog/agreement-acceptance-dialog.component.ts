import { Inject } from '@angular/core';
import { ViewChild } from '@angular/core';
import { Component } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AfterContentInit } from '@angular/core';

import { Agreement } from 'src/app/model/communication/agreement.model';
import { AlertService } from 'src/app/service/utils/alert.service';
import { SessionService } from 'src/app/service/session.service';
import { AgreementService } from 'src/app/service/communication/agreement.service';
import { StorageService } from 'src/app/service/storage.service';

@Component({
  selector: 'app-agreement-acceptance-dialog',
  templateUrl: './agreement-acceptance-dialog.component.html',
  styleUrls: ['./agreement-acceptance-dialog.component.scss']
})
export class AgreementAcceptanceDialogComponent implements AfterContentInit {

  @ViewChild('stepper') stepper: MatStepper;

  public agreements: Array<Agreement> = new Array<Agreement>();

  public loadingAgreements: boolean = true;
  public saving: boolean = false;
  public loaded: number = 0;

  constructor(private alertService: AlertService,
              private sessionService: SessionService,
              private storageService: StorageService,
              private agreementService: AgreementService,
              private dialogRef: MatDialogRef<AgreementAcceptanceDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: {agreements: Array<Agreement>}) { }


  ngAfterContentInit(): void {
    this.loadAgreements(this.data.agreements);
  }

  public onAccept(agreement: Agreement,
                  index: number): void {
    this.saving = true;

    this.agreementService
        .accept(agreement.id,
                this.sessionService
                    .getUser()
                    .id)
        .subscribe({
          next: (): void => {

            this.dialogRef
                .close();

            if (this.agreements.length > 1 &&
                index !== this.agreements.length-1) {
              this.stepper.next();
            }

            if (this.agreements
                    .length === 0) {
              this.storageService
                  .removeAgreements();
            }

            this.saving = false;
          },
          error: err => {
            this.alertService
                .error('ERROR:' + err.error);
            this.saving = false;
          }});
  }

  private getAgreement(id: number,
                       index: number): void {

    this.agreementService
        .get(id)
        .subscribe({
          next: (agreement: Agreement): void => {

            if(this.agreementService
                   .load(agreement,
                         document.getElementById('currentDoc' + (index >= 0 ? index : '')) as HTMLIFrameElement)){
              this.agreements
                  .push(agreement);
            }

            this.updateLoadingStatus();
          },
          error: err => {
            this.loaded = this.data.agreements.length;
            this.agreements = [];
            this.updateLoadingStatus();
            this.alertService
                .error('ERROR:' + err.error);
          }});
  }

  private loadAgreements(agreements: Array<Agreement>): void {

    agreements?.forEach((agreement,
                         index): void => {
      this.getAgreement(agreement.id,
                        index);
    });
  }

  private updateLoadingStatus(): void {
    this.loaded++;

    if (this.loaded >= this.data.agreements.length) {

      this.loadingAgreements = false;

      if(this.agreements
             .length === 0){
        this.dialogRef
            .close();
      }
    }
  }
}
