import { Component } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Input } from '@angular/core';
import { Output } from '@angular/core';
import { ViewChild } from '@angular/core';
import { MatSelect } from '@angular/material/select';

import { DropdownElement } from 'src/app/model/help/dropdown-element.model';

@Component({
  selector: 'app-input-dropdown',
  templateUrl: './input-dropdown.component.html',
  styleUrls: ['./input-dropdown.component.scss']
})
export class InputDropdownComponent {

  @ViewChild('matSelection', {static: false}) matSelection: MatSelect;

  @Input() name: string;
  @Input() selection: string;
  @Input() collection: Array<string>;

  @Output() selected: EventEmitter<DropdownElement> = new EventEmitter<DropdownElement>();

  constructor() {}

  public onSelected(event: string, isNew: boolean): void {
    let selection: DropdownElement = new DropdownElement();
    selection.element = event;
    selection.isNew = isNew;
    this.selected.emit(selection);
    this.matSelection.close();
  }

}
