import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './main.component';
import { AuthResolver } from 'src/app/service/v3/auth.resolver';
import { StoreDetailsResolver } from 'src/app/service/v3/store-details.resolver';

const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    resolve: {
      auth: AuthResolver,
      storeDetails: StoreDetailsResolver
    },
    children: [
      { path: 'dashboard', loadChildren: () => import('../modules/dashboard-v3/dashboard-v3.module').then(m => m.DashboardV3Module) },
      { path: 'reports', loadChildren: () => import('../modules/reports-v3/reports-v3.module').then(m => m.ReportsV3Module) },
      { path: 'configuration', loadChildren: () => import('../modules/configuration-v3/configuration-v3.module').then(m => m.ConfigurationV3Module), data: { breadcrumb: 'Configuration' } },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MainRoutingModule { }
