import { createAction } from '@ngrx/store';

import { STORE_MODULES } from 'src/app/model/v3/store.model';

export const RetrieveEnterpriseConfig = createAction(
    '[StoreDetails] Retrieve Enterprise Config'
);

export const RetrieveEnterpriseConfigSuccessful = createAction(
    '[StoreDetails] Retrieve Enterprise Config Successful'
);

export const RetrieveEnterpriseConfigFailed = createAction(
    '[StoreDetails] Retrieve Enterprise Config Failed'
);

export const StoreEnterpriseConfig = createAction(
    '[StoreDetails] Store Enterprise Config',
    (enabled: boolean) => ({enabled})
);

export const ToggleStoreModule = createAction(
    '[StoreDetails] Toggle Store Module',
    (moduleName: STORE_MODULES, enable: boolean) => ({moduleName, enable})
);

export const ToggleStoreModuleSuccessful = createAction(
    '[StoreDetails] Toggle Store Module Successful',
    (moduleName: STORE_MODULES, enabled: boolean) => ({moduleName, enabled})
);

export const ToggleStoreModuleFailed = createAction(
    '[StoreDetails] Toggle Store Module Failed',
    (moduleName: STORE_MODULES, enabled: boolean) => ({moduleName, enabled})
);

export const EnableStoreModule = createAction(
    '[StoreDetails] Enable Store Module',
    (moduleName: STORE_MODULES) => ({moduleName})
);

export const DisableStoreModule = createAction(
    '[StoreDetails] Disable Store Module',
    (moduleName: STORE_MODULES) => ({moduleName})
);

export const EnableOnlineOrderingModule = createAction(
    '[StoreDetails] Enable Online Ordering Module'
);

export const DisableOnlineOrderingModule = createAction(
    '[StoreDetails] Disable Online Ordering Module'
);
