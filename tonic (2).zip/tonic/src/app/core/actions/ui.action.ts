// Actions related to UI activities like Toasts, Loaders
