import { Component } from '@angular/core';

@Component({
  selector: 'app-background-wrapper',
  templateUrl: './background-wrapper.component.html',
  styleUrls: ['./background-wrapper.component.scss']
})
export class BackgroundWrapperComponent {

  constructor() { }

}
