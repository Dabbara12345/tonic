import { Component, EventEmitter, Output } from '@angular/core';

import { V2_ROUTES } from 'src/app/common/constants/url.constants';

@Component({
  selector: 'app-configuration-submenu',
  templateUrl: './configuration-submenu.component.html',
  styleUrls: ['./configuration-submenu.component.scss']
})
export class ConfigurationSubmenuComponent {
  @Output() onSubMenuItemClicked: EventEmitter<{ path: string; text: string; }> = new EventEmitter<{ path: string; text: string; }>();
  routesV2 = V2_ROUTES;
}
