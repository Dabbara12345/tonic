import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { V2_ROUTES } from 'src/app/common/constants/url.constants';

@Component({
  selector: 'app-activity-submenu',
  templateUrl: './activity-submenu.component.html',
  styleUrls: ['./activity-submenu.component.scss']
})
export class ActivitySubmenuComponent implements OnInit {

  @Output() onactivitySubMenuItemClicked: EventEmitter<{ path: string; text: string; }> = new EventEmitter<{ path: string; text: string; }>();
  routesV2 = V2_ROUTES;

  constructor() { }

  ngOnInit(): void {
  }

}
