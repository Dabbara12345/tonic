import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitySubmenuComponent } from './activity-submenu.component';

describe('ActivitySubmenuComponent', () => {
  let component: ActivitySubmenuComponent;
  let fixture: ComponentFixture<ActivitySubmenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActivitySubmenuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitySubmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
