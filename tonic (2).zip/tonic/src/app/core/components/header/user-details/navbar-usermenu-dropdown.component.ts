import { Component, Input, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';

import { Store as NgRxStore} from '@ngrx/store';
import { MatDialog } from '@angular/material/dialog';
import swal from 'sweetalert2';
import { takeWhile } from 'rxjs';
import { BsDropdownDirective } from 'ngx-bootstrap/dropdown';

import { getInitials } from 'src/app/shared-v3/utils';
import { SettingsComponent } from 'src/app/route/nav-bar/nav-options/settings/settings.component';
import { CurrentStoreComponent } from 'src/app/route/nav-bar/nav-options/current-store/current-store.component';
import { OloSchedulesComponent } from 'src/app/route/nav-bar/nav-options/olo-schedules/olo-schedules.component';
import { SessionService } from 'src/app/service/session.service';
import { selectSelectedStore } from 'src/app/modules/auth/selectors/auth.selector';
import { Store } from 'src/app/model/store.model';
import { Logout } from 'src/app/modules/auth/actions/auth.action';
import { selectUserProfileMenuDropdownMenu } from 'src/app/core/selectors/store-details.selector';
import { DropdownMenuViewModal } from 'src/app/model/v3/ui.model';
import { NavbarUserMenu } from 'src/app/model/v3/ui.model';

@Component({
  selector: 'app-navbar-usermenu-dropdown',
  templateUrl: './navbar-usermenu-dropdown.component.html',
  styleUrls: ['./navbar-usermenu-dropdown.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class NavbarUserMenuDropdownComponent implements OnInit, OnDestroy {
  @Input() public userDisplayName = '';
  @Input() public userRolesArray: string[] = [];
  private _isAlive = true;
  private selectedStoreDetails: Store;
  @ViewChild('dropdown', { static: true }) userMenuDropdown: BsDropdownDirective; 
  public settingsDropdownMenu$ = this._ngRxStore.select(selectUserProfileMenuDropdownMenu).pipe(takeWhile(() => this._isAlive));

  get userRolesString(): string {
    return this.userRolesArray?.join(', ');
  }

  get userDisplayRole(): string {
    return this.userRolesArray?.length > 1 ? this.userRolesArray[0] + '...' : this.userRolesArray?.[0] || '';
  }

  get getInitials(): string {
    return getInitials(this.userDisplayName);
  }

  constructor(
    private _dialogService: MatDialog,
    private _sessionService: SessionService,
    private _ngRxStore: NgRxStore
  ) { }
  
  ngOnInit(): void {
    this._ngRxStore.select(selectSelectedStore).pipe(takeWhile(() => this._isAlive)).subscribe((selectedStore: Store) => {
      this.selectedStoreDetails = selectedStore;
    })
  }

  onMenuSelected(selectedMenu: DropdownMenuViewModal, clickEvent: Event): void {
    const dialogConfigData = {
      [NavbarUserMenu.SETTINGS]: { component: SettingsComponent, config: { width: '800px', maxHeight: '700px', disableClose: true }},
      [NavbarUserMenu.STORE]: { component: CurrentStoreComponent, config: { width: '800px', maxHeight: '700px', disableClose: true }},
      [NavbarUserMenu.OLO_SCHEDULES]: { component: OloSchedulesComponent, config: { width: '800px', maxHeight: '700px', disableClose: true, data: { store: this.selectedStoreDetails }}},
      [NavbarUserMenu.LOGOUT]: null // Handle logout separately
    };

    if (selectedMenu.label === NavbarUserMenu.LOGOUT) {
      this.handleLogout();
    } else {
      const dialogConfig = dialogConfigData[selectedMenu.label];
      if (dialogConfig && !selectedMenu.disable) {
        this._dialogService.open(dialogConfig.component, dialogConfig.config);
      }
      else{
        clickEvent.stopPropagation();
      }
    }
  }

  handleLogout(): void {
    swal.fire({
      title: 'Ready to Log out?',
      icon: 'warning',
      confirmButtonText: 'Yes',
      confirmButtonColor: 'rgb(63, 81, 181)',
      cancelButtonText: 'No',
      cancelButtonColor: 'rgb(244, 67, 54)',
      showCancelButton: true,
      showCloseButton: true
    }).then((response): void => {
      if (response.isConfirmed) {
        console.log(new Date() + ' Explicit logout');
        this._ngRxStore.dispatch(Logout());
      }
    });
  }

  ngOnDestroy(): void {
    this._isAlive = false;
  }
}
