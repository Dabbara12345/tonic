import { Component, EventEmitter, OnDestroy, Output } from '@angular/core';
import { ComponentType } from '@angular/cdk/portal';

import { Store as NgRxStore} from '@ngrx/store';
import { takeWhile } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';

import { NAVBAR_OTHER_OPTIONS_URLs, V2_ROUTES } from 'src/app/common/constants/url.constants';
import { STORE_MODULES, EXTRA_STORE_TOOLS } from 'src/app/model/v3/store.model';
import { AuthState } from 'src/app/modules/auth/reducers';
import { AlertService } from 'src/app/service/utils/alert.service';
import { StoreModuleViewModel } from 'src/app/model/v3/store.model';
import { environment } from 'src/environments/environment';
import { SessionService } from 'src/app/service/session.service';
import { selectActiveModules, selectDisabledModules, selectExtraStoreToolList } from 'src/app/core/selectors/store-details.selector';
import { ToggleStoreModule } from 'src/app/core/actions/store-details.action';
import { IntegrationsComponent } from 'src/app/route/integrations/integrations.component';
import { MailChimpComponent } from 'src/app/route/apps/mail-chimp/mail-chimp.component';
import { OloConfigurationsComponent } from 'src/app/route/apps/olo/olo-configurations.component';
import { isSupportUser } from 'src/app/modules/auth/selectors/auth.selector';
import { EXTERNAL_URL_NAMES as NAVBAR_OTHER_OPTIONS_URLs_MENU } from 'src/app/model/v3/ui.model';
import { externalURLsNameList } from 'src/app/common/constants/common.constants';
import { trackByFn } from 'src/app/shared-v3/utils';

@Component({
  selector: 'app-apps-submenu',
  templateUrl: './apps-submenu.component.html',
  styleUrls: ['./apps-submenu.component.scss'],
})
export class AppsSubmenuComponent implements OnDestroy{
  private _isAlive = true;

  public storeModules = STORE_MODULES;

  public activeModules$ = this._ngrxStore.select(selectActiveModules).pipe(takeWhile(() => this._isAlive));
  public disabledModules$ = this._ngrxStore.select(selectDisabledModules).pipe(takeWhile(() => this._isAlive));
  public extraStoreToolList$ = this._ngrxStore.select(selectExtraStoreToolList).pipe(takeWhile(() => this._isAlive));
  public isSupportUser$ = this._ngrxStore.select(isSupportUser).pipe(takeWhile(() => this._isAlive));

  public integrationIcon = '/assets/img/v3/icons/stack.svg';
  public urlIcon = '/assets/img/v3/icons/link.svg';
  public quickBooksIcon = '/assets/img/v3/icons/quick-books.svg';
  public urlsMenuList = externalURLsNameList;

  @Output() subMenuItemClicked = new EventEmitter<{ path: string; text: string; }>();
  @Output() closeSubmenuEvent = new EventEmitter();

  trackByFn = trackByFn;

  constructor(private _alertService: AlertService, private _ngrxStore: NgRxStore<AuthState>, private _sessionService: SessionService, private _dialog: MatDialog) {}


  onToggleStoreModule = ($event: {module: StoreModuleViewModel, enabled: boolean}): void => {
    const {module, enabled} = $event;
    this._ngrxStore.dispatch(ToggleStoreModule(module.moduleName, enabled));
  }

  onModulesClicked = (module: string, isEnabled: boolean):void => {
    if(!isEnabled){
      this._alertService.warning('Click on radio button to enable.');
      return;
    }
    switch (module) {
      case STORE_MODULES.MODULE_NEW_BACK_OFFICE:
        this.subMenuItemClicked.emit(V2_ROUTES.DASHBOARD);
        break;
        case STORE_MODULES.MODULE_TIME_ATTENDANCE:
        this.subMenuItemClicked.emit(V2_ROUTES.TIME);
        break;
        case STORE_MODULES.MODULE_CUSTOMER_ACCOUNTS:
        this.subMenuItemClicked.emit(V2_ROUTES.CUSTOMER);
        break;
        case STORE_MODULES.MODULE_INVENTORY:
        this.subMenuItemClicked.emit(V2_ROUTES.INVENTORY);
        break;
        case STORE_MODULES.MODULE_ONLINE_ORDERING:
          this.openModal(OloConfigurationsComponent);
        break;

      default:
        break;
    }
  }

  onExtraStoreToolListItemClicked = (menu: string): void => {
      let isUrlsMenu = true;
      switch (menu) {
        case EXTRA_STORE_TOOLS.MARKETPLACE:
          const marketplaceUrl = environment.appUrl + '?token=' + this._sessionService.getToken();
          window.open(marketplaceUrl, '_blank');
          break;
        case EXTRA_STORE_TOOLS.INTEGRATIONS:
          this.openModal(IntegrationsComponent, '1000px');
          break;
        case EXTRA_STORE_TOOLS.URLS:
          isUrlsMenu = false;
        break;
        case EXTRA_STORE_TOOLS.QUICKBOOKS:
          this.subMenuItemClicked.emit(V2_ROUTES.QUICKBOOKS);
          break;
        case STORE_MODULES.MODULE_MAIL_CHIMP:
          this.openModal(MailChimpComponent);
          break;
        default:
          break;
      }
      if(isUrlsMenu){
      /**
       * This event is triggered when any menu other than 'URLs' is clicked.
       * It prevents the top menu section from closing when the 'URLs' menu is clicked,
       * instead displaying a dropdown with other redirection options.
       */
        this.closeSubmenuEvent.emit();
      }
  }

  openModal = (component: ComponentType<any>, width = '600px'): void => {
    this._dialog.open(component, {
      width,
      disableClose: false,
      data: ''
    });
  }

  onClickUrls(urlMenu: NAVBAR_OTHER_OPTIONS_URLs_MENU): void {
    switch(urlMenu){
      case NAVBAR_OTHER_OPTIONS_URLs_MENU.CUSTOMERS:
        window.open(NAVBAR_OTHER_OPTIONS_URLs.CUSTOMERS, '_blank');
      break;
      case NAVBAR_OTHER_OPTIONS_URLs_MENU.ONLINE_ORDERS:
        window.open(NAVBAR_OTHER_OPTIONS_URLs.ONLINE_ORDERS, '_blank');
      break;
      case NAVBAR_OTHER_OPTIONS_URLs_MENU.MI_POINT:
        window.open(NAVBAR_OTHER_OPTIONS_URLs.MI_POINT, '_blank');
      break;
    }
  }

  ngOnDestroy(): void {
    this._isAlive = false;
  }
}
