import { Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';

import Swal from 'sweetalert2';

import { StoreModuleViewModel } from 'src/app/model/v3/store.model';
import { STORE_MODULES } from 'src/app/model/v3/store.model';

@Component({
  selector: 'app-toggle-store-module',
  templateUrl: './toggle-store-module.component.html',
  styleUrls: ['./toggle-store-module.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ToggleStoreModuleComponent {
  @Input() module: StoreModuleViewModel;
  @Input() isSupportUser = false;
  @Output() toggleModuleEvent = new EventEmitter<{module: StoreModuleViewModel, enabled: boolean}>();
  @Output() subMenuItemClickEvent = new EventEmitter<string>();

  constructor() { }

  onToggleModuleCheckbox = ($event: Event): void => {
    if(!this.isSupportUser) {
      return;
    }
    // once enabled, enterprise module cannot be disabled from UI. So we bypass the confirmation dialog and let the effect take care of the rest
    if(this.module.moduleName === STORE_MODULES.MODULE_ENTERPRISE && this.module.isEnabled) {
      return this.toggleModuleEvent.emit({module: this.module, enabled: !this.module.isEnabled});
    }
    $event.preventDefault();
    Swal.fire({
      title: `Confirmation`,
      text: `Are you sure you want to ${!this.module.isEnabled ? 'enable' : 'disable'} ${this.module.text}?`,
      icon: 'warning',
      confirmButtonColor: '#40BBEC',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      showCancelButton: true,
      reverseButtons: true,
      showCloseButton: true,
      didOpen: this.handleDefaultClickBehavior,
    }).then((userInput) => {
      if(userInput.isConfirmed){
        this.toggleModuleEvent.emit({module: this.module, enabled: !this.module.isEnabled});
      }
    });
  }

  handleDefaultClickBehavior = (): void => {
    const buttons = [Swal.getConfirmButton(), Swal.getCancelButton(), Swal.getCloseButton()];

    buttons.forEach(button => {
      if (button) {
        button.addEventListener('click', (event: Event) => event.stopPropagation());
      }
    });
  }

  onModuleLinkClick = (module: StoreModuleViewModel): void => {
    if (module.deadLink) {
      return;
    }
    this.subMenuItemClickEvent.emit(module.moduleName);
  };

}
