import { Component, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { Store as NgRxStore } from '@ngrx/store';
import { combineLatest, map, take, takeWhile } from 'rxjs';
import { ComponentType } from '@angular/cdk/portal';
import { MatDialog } from '@angular/material/dialog';
import { BsDropdownDirective } from 'ngx-bootstrap/dropdown';

import { DASHBOARD_ROUTES, V2_ROUTES } from 'src/app/common/constants/url.constants';
import { HeaderEnum } from 'src/app/model/v3/ui.model';
import { selectUser, selectUserEmailId, selectUserRoles } from 'src/app/modules/auth/selectors/auth.selector';
import { StorageService } from 'src/app/service/storage.service';
import { MORE_TOOLS_ENUM } from 'src/app/common/constants/common.constants';
import { DropdownMenuViewModal } from 'src/app/model/v3/ui.model';
import { SuggestionsComponent } from '../footer/suggestions/suggestions.component';
import { PhonebookComponent } from 'src/app/route/nav-bar/nav-options/phonebook/phonebook.component';
import { LibraryComponent } from 'src/app/route/admin/library/library.component';
import { EnterprisesComponent } from 'src/app/route/admin/enterprises/enterprises.component';
import { CommunitiesComponent } from 'src/app/route/admin/communities/communities.component';
import { DocumentsComponent } from 'src/app/route/nav-bar/nav-options/documents/documents.component';
import { SystemSettingsComponent } from 'src/app/route/admin/system-settings/system-settings.component';
import { FeesComponent } from 'src/app/route/admin/fees/fees.component';
import { selectMoreToolsOptions } from 'src/app/core/selectors/store-details.selector';
import { NavbarUserMenuDropdownComponent } from './user-details/navbar-usermenu-dropdown.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnDestroy {
  private _isAlive = true;
  public logo = '/assets/img/logo/tonic_white_blue.svg';
  public notificationIcon = '/assets/img/v3/icons/bell.svg';
  public notificationValue = '8';
  public dashboardRoutes = DASHBOARD_ROUTES;
  public routesV2 = V2_ROUTES;
  public subMenu = '';
  public headerEnum = HeaderEnum;
  private _loggedInUser$ = this._ngRxStore.select(selectUser).pipe(takeWhile(() => this._isAlive));
  private _userRoles$ = this._ngRxStore.select(selectUserRoles).pipe(takeWhile(() => this._isAlive));
  public userDetails$ = combineLatest([this._loggedInUser$, this._userRoles$]).pipe(
    map(([user, roles]) => ({ user, roles }))
  );
  userEmail$ = this._ngRxStore.select(selectUserEmailId).pipe(takeWhile(() => this._isAlive));
  @ViewChild(NavbarUserMenuDropdownComponent, { static: false }) navbarUserMenuDropdownComponent: NavbarUserMenuDropdownComponent;
  @ViewChild('dropdown', { static: true }) moreToolsDropdown: BsDropdownDirective;

  public moreToolsDropdown$ = this._ngRxStore.select(selectMoreToolsOptions).pipe(takeWhile(() => this._isAlive)); // Data will be used for displaying 'More Tools' dropdown.

  constructor(private _ngRxStore: NgRxStore, private _router: Router, private storageService: StorageService, private _dialog: MatDialog){}

  onSubMenuClick = (subMenu: string):void => {
    if(subMenu === this.subMenu){
      this.subMenu = '';
      return;
    }
    // Manually closing both userMenu dropdown and moretools dropdown since we have used event.stopPropagation while clicking Configurations and Apps from the header.
    if(subMenu === this.headerEnum.CONFIGURATION || this.headerEnum.APPS) {
      this.navbarUserMenuDropdownComponent?.userMenuDropdown?.hide();
      this.moreToolsDropdown?.hide();
    }
    this.subMenu = subMenu;
  }

  // Temporary method to handle router navigation to old Beta application - VRIZ-367
  onHeaderItemsClick(routeData: { path: string; text: string; }): void {
    // Logic in the existing Beta application to set nav-option in local storage which allows the router navigation to old Beta application's pages.
    // Ref- saveSelectedNode() & setDefaultNode() in route.component.ts.
    this.storageService.addSetting('nav-option', routeData.text);
    this._router.navigateByUrl(routeData.path);
    this.onSubMenuClick(this.subMenu); // Calling again the same method with the existing subMenu data which will close the dropdown as per the logic of the method.
  }

  onMoreItemClick = (event: DropdownMenuViewModal) => {
    switch (event.id) {
      case MORE_TOOLS_ENUM.DEALER_PORTAL:
      case MORE_TOOLS_ENUM.SHOP:
        window.open(event.path, '_blank');
        break;
      case MORE_TOOLS_ENUM.SUGGESTIONS:
        this.onSuggestionsClick();
        break;
      case MORE_TOOLS_ENUM.PHONE_BOOK:
        this.openModal(PhonebookComponent);
        break;
      case MORE_TOOLS_ENUM.SUPPORT_LIBRARY:
        this.openModal(LibraryComponent);
        break;
      case MORE_TOOLS_ENUM.THEMES:
        // Handle Themes click. Currently Themes option is disabled.
        break;
      case MORE_TOOLS_ENUM.STORE:
      case MORE_TOOLS_ENUM.SUPPORT:
      case MORE_TOOLS_ENUM.LOG_HISTORY:
        this._router.navigateByUrl(event.path);
        break;
      case MORE_TOOLS_ENUM.ENTERPRISES:
        this.openModal(EnterprisesComponent);
        break;
      case MORE_TOOLS_ENUM.COMMUNITIES:
        this.openModal(CommunitiesComponent);
        break;
      case MORE_TOOLS_ENUM.DOCUMENTS:
        this.openModal(DocumentsComponent);
        break;
      case MORE_TOOLS_ENUM.SYSTEM:
        this.openModal(SystemSettingsComponent);
        break;
      case MORE_TOOLS_ENUM.FEES:
        this.openModal(FeesComponent);
        break;
      case MORE_TOOLS_ENUM.PAYMENTS:
        this._router.navigateByUrl(event.path);
        break;
      default:
        break;
    }
  }

  openModal = (component: ComponentType<any>, width='800px'): void => {
    this._dialog.open(component, {
      width: width,
      disableClose: false,
      data: ''
    });
  }

  onSuggestionsClick(): void {
    let userEmail = '';
    this.userEmail$.pipe(take(1)).subscribe(email => {
      userEmail = email;
    })
    const suggestionsDialogRef = this._dialog.open(SuggestionsComponent, {
      disableClose: false,
      data: {
        email: userEmail
      }
    });
    suggestionsDialogRef.componentInstance.dismiss.subscribe(() => {
      suggestionsDialogRef.close();
    });
  }

  ngOnDestroy(): void {
      this._isAlive = false;
  }
}
