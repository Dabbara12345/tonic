import { Component } from '@angular/core';
import { takeWhile } from 'rxjs';
import { Store } from '@ngrx/store';
import * as _ from 'lodash';

import { IBreadCrumb } from 'src/app/model/v3/ui.model';
import { selectCurrentRouteInfo } from 'src/app/core/selectors/router.selector';
import { buildBreadcrumbs } from 'src/app/core/mappers/breadcrumbs.mapper';
import { DASHBOARD_ROUTES as v3Routes } from 'src/app/common/constants/url.constants';

@Component({
  selector: 'app-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss']
})
/* Note: To build required breadcrumbs add routerData in the relevant routing.ts file as shown below -
* data: { breadcrumb: '' } 
* Replace '' with the relevant breadcrumb data. 
* For example consider if we need to build breadcrumb like Home -> Reports, Add data: { breadcrumb: 'Reports' } in the reports routing module.
* If we have any intermediate breadcrumbs like Configuration in Home -> Configuration -> Menu Configuration, We need to add it in the relavant routing.ts ( main-routing.ts ) as data: { breadcrumb: 'Configuration' }.
* Also note only First home route node and leaf node ( last routing data ) will be having the urls to navigate. All other intermediate urls will empty string as per the implementation.
*/
export class BreadcrumbsComponent {
  breadcrumbs: IBreadCrumb[] = [{ label: 'Home', url: v3Routes.HOME }];
  private _isAlive = true;

  constructor(private _store: Store) {
    this._store.select(selectCurrentRouteInfo).pipe(
      takeWhile(() => this._isAlive)
    ).subscribe(({ url, root }) => {
      this.breadcrumbs = buildBreadcrumbs(root, url);
    });
  }

  ngOnDestroy(): void {
    this._isAlive = false;
  }
}
