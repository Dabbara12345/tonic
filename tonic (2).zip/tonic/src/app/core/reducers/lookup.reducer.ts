import { Action, createReducer } from "@ngrx/store"

export interface LookupState {

}

export const initialState: LookupState = {

}

const reducer = createReducer(
    initialState
);

export function LookupReducer(state: LookupState, action: Action) {
    return reducer(state, action);
}