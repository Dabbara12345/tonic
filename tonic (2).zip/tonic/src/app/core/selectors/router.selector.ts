import { createSelector, createFeatureSelector } from '@ngrx/store';
import { ActivatedRouteSnapshot, Data } from '@angular/router';
import * as fromRouter from '@ngrx/router-store';

import { CurrentRouteInfo } from 'src/app/model/v3/ui.model';

export const selectRouterState = createFeatureSelector<fromRouter.RouterReducerState>('router');

export const {
    selectCurrentRoute,   // select the current route
    selectQueryParams,    // select the current route query params
    selectQueryParam,     // factory function to select a query param
    selectRouteParams,    // select the current route params
    selectRouteParam,     // factory function to select a route param
    selectRouteData,      // select the current route data
    selectUrl,            // select the current url
} = fromRouter.getSelectors(selectRouterState);

export const selectRouterStateRoot = createSelector(
  selectRouterState,
  ({state}: fromRouter.RouterReducerState): ActivatedRouteSnapshot => (state.root)
);

export const selectCurrentRouteInfo = createSelector(
    selectUrl,
    selectRouteData,
    selectRouterStateRoot,
    (url: string, routeData: Data, root: ActivatedRouteSnapshot): CurrentRouteInfo => ({ url, routeData, root })
);
