import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as _ from 'lodash';

import { StoreDetailsState } from 'src/app/core/reducers/store-details.reducer';
import { ExtraStoreToolsViewModal, StoreConfig, StoreModuleViewModel } from 'src/app/model/v3/store.model';
import { isManager, isRoot, isSupportUser, selectSelectedStore, selectStores, selectUser } from 'src/app/modules/auth/selectors/auth.selector';
import { MORE_TOOLS_DROP_DOWN, MORE_TOOLS_ENUM, extraStoreToolsList, storeModuleList, STORE_PERMISSIONS, settingsDropdownMenu } from 'src/app/common/constants/common.constants';
import { STORE_MODULES } from 'src/app/model/v3/store.model';
import { Store } from 'src/app/model/store.model';
import { NameValue } from 'src/app/model/utils/nameValue.model';
import { DropdownMenuViewModal, DropdownViewModal, NavbarUserMenu } from 'src/app/model/v3/ui.model';
import { User } from 'src/app/model/access/user.model';
import { environment } from 'src/environments/environment';

export const selectStoreDetailsState = createFeatureSelector<StoreDetailsState>('storeDetails');

export const selectStoreConfigState = createSelector(
    selectStoreDetailsState,
    (state: StoreDetailsState): StoreConfig => state ? state.config : null
);

export const selectIsEnterpriseEnabled = createSelector(
    selectStoreConfigState,
    (state: StoreConfig): boolean => state ? state.enterpriseEnabled : false
);

export const selectIsModuleEnabled = (moduleName: STORE_MODULES) =>
    createSelector(
        selectSelectedStore,
        selectIsEnterpriseEnabled,
        (selectedStore: Store, enterpriseEnabled: boolean): boolean => moduleName === STORE_MODULES.MODULE_ENTERPRISE
            ? enterpriseEnabled
            : selectedStore.hasEnabled(moduleName)
    );

export const selectSelectedStoreSettings = createSelector(
  selectSelectedStore,
  (selectedStore: Store): NameValue[] => selectedStore ? selectedStore.settings : undefined
);

export const selectModules = createSelector(
  selectIsEnterpriseEnabled,
  selectSelectedStore,
  isSupportUser,
  isManager,
  (enterpriseEnabled: boolean, store: Store, isSupportUser: boolean, isManager: boolean): StoreModuleViewModel[] => {
    const isOloAvailable = store?.hasSetting(STORE_MODULES.TOKEN_OLO);
    const tempModules = _.map(storeModuleList, (module: StoreModuleViewModel) => {

      const isEnabled = module.moduleName === STORE_MODULES.MODULE_ENTERPRISE ? enterpriseEnabled : store.hasEnabled(module.moduleName);

      let includeModuleInTheMenu = false;

      switch (module.id) {
        case STORE_MODULES.MODULE_NEW_BACK_OFFICE:
          includeModuleInTheMenu = isSupportUser;
          break;
        case STORE_MODULES.MODULE_TIME_ATTENDANCE:
        case STORE_MODULES.MODULE_CUSTOMER_ACCOUNTS:
        case STORE_MODULES.MODULE_INVENTORY:
          includeModuleInTheMenu = isEnabled || isManager;
          break;
        case STORE_MODULES.MODULE_ENTERPRISE:
          includeModuleInTheMenu = enterpriseEnabled;
        break;
        case STORE_MODULES.MODULE_ONLINE_ORDERING:
          includeModuleInTheMenu = isOloAvailable || isManager;
        break;
        default:
          includeModuleInTheMenu = false;
          break;
      }

      return {
        ...module,
        isEnabled,
        includeModuleInTheMenu // This is used only for filtering
      };
    });

    // Filtering and removing `includeModuleInTheMenu` key.
    return _.chain(tempModules).filter(module => module.includeModuleInTheMenu).map(({ includeModuleInTheMenu, ...module }) => module).value();
  }
);

export const selectActiveModules = createSelector(
  selectModules,
  (modules: StoreModuleViewModel[]): StoreModuleViewModel[] => modules.filter(module => module.isEnabled)
);

export const selectDisabledModules = createSelector(
  selectModules,
  (modules: StoreModuleViewModel[]): StoreModuleViewModel[] => modules.filter(module => !module.isEnabled)
);

export const selectExtraStoreToolList = createSelector(
  selectSelectedStore,
  (store: Store): ExtraStoreToolsViewModal[] => {
    const isMailChipEnabled = store?.hasEnabled(STORE_MODULES.MODULE_MAIL_CHIMP);

    const tempOptions = _.map(extraStoreToolsList, (option: ExtraStoreToolsViewModal) => {
      let includeModuleInTheMenu = true;

      switch (option.id) {
        case STORE_MODULES.MODULE_MAIL_CHIMP:
          includeModuleInTheMenu = isMailChipEnabled
          break;
        default:
          break;
      }

      return {
        ...option,
        includeModuleInTheMenu // This is used only for filtering
      }
    })

    // Filtering and removing `includeModuleInTheMenu` key.
    return _.chain(tempOptions).filter(option => option.includeModuleInTheMenu).map(({includeModuleInTheMenu, ...option}) => option).value();
  }
);

const filterMainTools = (isSupportUser: boolean, isRoot: boolean) => (tool: DropdownMenuViewModal): boolean => {
  switch (tool.id) {
    case MORE_TOOLS_ENUM.DEALER_PORTAL:
    case MORE_TOOLS_ENUM.SUPPORT_LIBRARY:
    case MORE_TOOLS_ENUM.ADMIN:
      return isSupportUser;
    case MORE_TOOLS_ENUM.BILLING:
      return isRoot;
    default:
      return true;
  }
};

const filterAdminTools = (isRoot: boolean, isManager: boolean) => (tool: DropdownMenuViewModal): boolean => {
  switch (tool.id) {
    case MORE_TOOLS_ENUM.SUPPORT:
      return isRoot || isManager;
    case MORE_TOOLS_ENUM.SYSTEM:
      return isRoot;
    default:
      return true;
  }
}

const filterAdminToolsWithValidStores = (stores: Store[], isSupportUser: boolean) => (tool: DropdownMenuViewModal): boolean => {
  switch (tool.id) {
    case MORE_TOOLS_ENUM.STORE:
      return stores?.length > 0;
    case MORE_TOOLS_ENUM.ENTERPRISES:
    case MORE_TOOLS_ENUM.COMMUNITIES:
    case MORE_TOOLS_ENUM.DOCUMENTS:
      return isSupportUser && stores && stores?.length > 0;
    default:
      return true;
  }
}

const filterBillingTools = (isRoot: boolean) => (tool: DropdownMenuViewModal): boolean => {
  switch (tool.id) {
    case MORE_TOOLS_ENUM.FEES:
    case MORE_TOOLS_ENUM.PAYMENTS:
      return isRoot;
    default:
      return true;
  }
}

export const selectMoreToolsOptions = createSelector(
  isManager,
  isSupportUser,
  isRoot,
  selectStores,
  (isManager: boolean, isSupportUser: boolean, isRoot: boolean, stores: Store[]): DropdownViewModal => {

    const moreToolsMenuFilteredBasedOnPermission = _.map(
      _.filter(MORE_TOOLS_DROP_DOWN.menu, filterMainTools(isSupportUser, isRoot)),
      (tool) => {
        if(tool.id === MORE_TOOLS_ENUM.ADMIN){
         tool.submenu = _.filter(tool.submenu, filterAdminTools(isRoot, isManager));
        }

        if(tool.id === MORE_TOOLS_ENUM.ADMIN && stores){
          tool.submenu = _.filter(tool.submenu, filterAdminToolsWithValidStores(stores, isSupportUser));
        }

        if(tool.id === MORE_TOOLS_ENUM.BILLING){
          tool.submenu = _.filter(tool.submenu, filterBillingTools(isRoot));
        }
        return tool;
      }
    );
    return _.assign({}, MORE_TOOLS_DROP_DOWN, { menu: moreToolsMenuFilteredBasedOnPermission });
    }
  );


export const selectUserProfileMenuDropdownMenu = createSelector(
  selectUser,
  selectSelectedStore,
  (user: User, selectedStore: Store): DropdownMenuViewModal[] => {
    const isModifySettingsAllowed =  user.hasPermissionIn( STORE_PERMISSIONS.MODIFY_STORE, selectedStore);
    return _.map(settingsDropdownMenu, (settings) => {
      // Validating whether user has permissions for menus
      if(settings.id === NavbarUserMenu.SETTINGS){
        return { ...settings, disable: !isModifySettingsAllowed };
      }
      return settings;
    })
  }
);

export const selectStoreLogo = createSelector(
  selectSelectedStore,
  ({logoPath = ''}): string => _.isEmpty(logoPath) ? '' : environment.logoUrl + logoPath
);
