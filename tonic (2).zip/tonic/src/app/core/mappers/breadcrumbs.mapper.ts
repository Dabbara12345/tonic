import { ActivatedRouteSnapshot } from "@angular/router";
import * as _ from 'lodash';

import { IBreadCrumb } from "src/app/model/v3/ui.model";
import { DASHBOARD_ROUTES as v3Routes } from 'src/app/common/constants/url.constants';

export const buildBreadcrumbs = (currentRoute: ActivatedRouteSnapshot, url: string) => {
    const breadcrumbs: IBreadCrumb[] = [{ label: 'Home', url: v3Routes.HOME }]; // First breadcrumb data.

    // Traverse through nested routes until there are no more child routes
    while (currentRoute?.firstChild) {
        
        if(!_.isEmpty(currentRoute.data)) {
            const label = currentRoute.data?.breadcrumb;
            const newBreadCrumbData = { label , url: '' }; // Breadcrumb data for intermediate routes. Example - Home -> Configuration -> Menu Configuration ( Configuration as per the implementation )
            if (!_.some(breadcrumbs, {label})) {
                breadcrumbs.push(newBreadCrumbData);
            }
        }
      currentRoute = currentRoute.firstChild;
    
    }
    // Finally, add the breadcrumb for the current route (leaf node)
    const label = currentRoute?.data?.breadcrumb; 
    const lastBreadCrumb = { label , url } // Note - There should be routeData available in the respective routing.ts else label will be undefined & that will be omitted from breadcrumbs array. 
    if (label && !_.some(breadcrumbs, {label})) {
    breadcrumbs.push(lastBreadCrumb);
    }
    return breadcrumbs;
}