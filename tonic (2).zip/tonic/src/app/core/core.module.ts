import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FooterModule } from './components/footer/footer.module';
import { HeaderModule } from './components/header/header.module';
import { BreadcrumbsModule } from './components/breadcrumbs/breadcrumbs.module';
import { StoreDetailsResolver } from 'src/app/service/v3/store-details.resolver';
import { SharedV3Module } from 'src/app/shared-v3/shared-v3.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HeaderModule,
    FooterModule,
    SharedV3Module
  ],
  providers: [StoreDetailsResolver],
  exports: [
    HeaderModule,
    FooterModule,
    BreadcrumbsModule
  ]
})
export class CoreModule { }
