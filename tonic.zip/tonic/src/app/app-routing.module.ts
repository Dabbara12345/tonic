import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './route/auth/login/login.component';
import { CanLoadRouteGuard } from './service/access/can-Load-route-guard';
import { SevenShiftsAuthComponent } from './route/apps/time/seven-shifts/seven-shifts-auth.component';

const routes: Routes = [
  { path: 'app/v3', loadChildren: () => import('./main/main.module').then(m => m.MainModule), canLoad: [CanLoadRouteGuard] }, // New UI V3 feature modules.
  { path: 'login', component: LoginComponent },
  { path: 'oauth', loadChildren: () => import('./route/auth/oauth/oauth.module').then(m => m.OauthModule) },
  { path: 'system', loadChildren: () => import('./route/route.module').then(m => m.RouteModule), canLoad: [CanLoadRouteGuard] },
  { path: '7shifts', component: SevenShiftsAuthComponent },

  // Not Found
  { path: '**', redirectTo: 'system/dashboard' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    onSameUrlNavigation: 'reload'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
