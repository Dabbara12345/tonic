export class CustomerBalanceDue {

  public name: string;
  public orderName: string;
  public recAmount: number;
  public created: Date;
  public amount: number;
  public due: number;

  public load(data: any): CustomerBalanceDue {
    Object.assign(this, data);

    return this;
  }
}
