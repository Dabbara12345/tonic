import { Deposit } from './deposit.model';
import { NameValue } from '../utils/nameValue.model';
import { CustomerComp } from './customer-comp.model';

export class Customer {

  public id?: number;
  public remoteId?: string;

  public name?: string;
  public firstName?: string;
  public lastName?: string;
  public email?: string;
  public description?: string;
  public middleInitial?: string;
  public password?: string;

  public message?: string;

  public faxNumber?: string;
  public cellNumber?: string;
  public phoneNumber?: string;

  public address?: string;
  public city?: string;
  public state?: string;
  public postalCode?: string;

  public latitude?: string;
  public longitude?: string;

  public facebookUsername?: string;
  public facebookUid?: number;

  public balance?: number;
  public orderCount?: number;
  public dateLastOrder?: number;

  public cardNumber?: string;
  public track1?: number;
  public track2?: number;
  public track3?: number;

  public loyaltyPoints?: number;
  public lifetimeLoyaltyPoints?: number;
  public allowance?: boolean;

  public lastOrdered?: Date;
  public lastLoyalty?: Date;

  public dateOfBirth?: Date;
  public disabled?: Date;
  public lastLogin?: Date;
  public created?: Date;
  public updated?: Date;

  public settings?: Array<NameValue>;
  public deposits?: Array<Deposit>;
  public comps?: Array<CustomerComp>;

  public load(data: any): Customer {

    Object.assign(this, data);

    this.settings = new Array();

    data?.settings
        ?.forEach((nV: NameValue): void => {

      this.settings
          .push(new NameValue().load(nV));
    });

    this.deposits = new Array();

    data?.deposits
        ?.forEach((d: Deposit): void => {

      this.deposits
          .push(new Deposit().load(d));
    });

    this.comps = new Array();

    data?.comps
        ?.forEach((cC: CustomerComp): void => {

      this.comps
          .push(new CustomerComp().load(cC));
    });

    if(data?.created) {
      this.created = new Date(data.created);
    }

    if(data?.disabled) {
      this.disabled = new Date(data.disabled);
    }

    if(data?.lastOrdered) {
      this.lastOrdered = new Date(data.lastOrdered);
    }

    if(data?.lastLoyalty) {
      this.lastLoyalty = new Date(data.lastLoyalty);
    }

    if(data?.dateOfBirth) {
      this.dateOfBirth = new Date(data.dateOfBirth);
    }

    return this;
  }

  public getName?(): string {

    let name: string = '';

    if(this.name?.length > 0) {

      name = this.name;
    } else {

      if (this.firstName) {
        name = this.firstName;
      }

      if (this.lastName) {
        name += ' ' + this.lastName;
      }
    }

    return name.trim();
  }

  public getAddress?(): string {

    let street: string = (this.address ? this.address : '') + ' ';
    let city: string = (this.city ? this.city : '');
    let state: string = (this.state ? ', ' +this.state : '') + ' ';
    let postalCode: string = this.postalCode ? this.postalCode : '';

    return street + city +  state + postalCode;
  }
}
