import { BillReconciled } from "./bill-reconciled.model";

export class Deposit {

  public id: number;
  public name: string;
  public description: string;
  public paymentType: number;
  public account: string;
  public reference: string;
  public approval: string;
  public totalAmount: number;
  public created: Date;
  public updated: Date;

  public reconciledBills: Array<BillReconciled>;

  public load(data: any): this {

    Object.assign(this, data);

    this.reconciledBills = new Array<BillReconciled>();

    data?.reconciledBills
        ?.forEach((bR: BillReconciled): void => {

      this.reconciledBills
          .push(new BillReconciled().load(bR));
    });

    return this;
  }

  public balance(): number {

    let balance: number = 0;

    this.reconciledBills
        .forEach(b => balance += b.amount);

    return this.totalAmount - balance;
  }
}
