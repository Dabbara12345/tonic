
import { User } from '../access/user.model';
import { Allowance } from '../analytics/customer/allowance.model';
import { Terminal } from '../equipment/terminal.model';
import { Customer } from './customer.model';

export class CustomerActivity {

  public customerId: number;
  public name: string;
  public description: string;
  public customer: Customer;
  public terminal: Terminal;
  public user: User;
  public forcedBy: User;
  public oldPoints: number;
  public newPoints: number;
  public allowance: Allowance;
  public created?: Date;

  public load(data: any): this {

    Object.assign(this, data);

    if(data?.created){
      this.created = new Date(data.created);
    }

    return this;
  }

  public static typeLabel(key: number): string {

    let label: string = 'Unknown';

    switch (key) {
      case 1:
        return 'Earned';
      case 2:
        return 'Redeemed';
      case 3:
        return 'Expired';
      case 4:
        return 'Activation';
      case 6:
        return 'Birthday';
      case 7:
        return 'Membership Anniversary';
      case 8:
        return 'Points';
      case 9:
        return 'Allowance';
      case 10:
        return 'Transfer From';
      case 11:
        return 'Transfer To';
    }

    return label;
  }
}
