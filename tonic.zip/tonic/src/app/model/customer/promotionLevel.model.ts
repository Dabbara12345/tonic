export class PromotionLevel {

    public seqNo!: number;
    public points!: number;
    public name!: string;

    public load(data: any): PromotionLevel {
      Object.assign(this, data);

      return this;
    }
}
