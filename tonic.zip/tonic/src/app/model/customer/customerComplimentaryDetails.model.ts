export class CustomerComplimentaryDetails {

  public date: Date;
  public seats: number;
  public item: string;
  public server: string;
  public authorize: string;
  public name: string;
  public reason: string;
  public qty: number;
  public total: number;
  public amount: number;

  public load(data: any): this {
    Object.assign(this, data);

    if(data?.date) {
      this.date = new Date(data.date);
    }

    return this;
  }
}
