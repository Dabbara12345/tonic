export class LoyaltyActivity {

  public id: number;
  public customer: string;
  public date: Date;
  public source: string;
  public description: string;
  public action: string;
  public points: number;
  public balance: number;

  public load(data: any): LoyaltyActivity {
    Object.assign(this, data);

    if(data?.date) {
      this.date = new Date(data.date);
    }

    return this;
  }
}
