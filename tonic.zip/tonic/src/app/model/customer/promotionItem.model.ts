export class PromotionItem {

    public id!: number;
    public seqNo!: number;
    public name!: string;
    public quantity!: number;

    public load(data: any): PromotionItem {
      Object.assign(this, data);

      return this;
    }
}
