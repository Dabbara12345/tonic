import { Customer } from "./customer.model";

export class StoreCustomer extends Customer {

  public remoteId?: string;
  public cardNumber?: string;

  public message?: string;
  public drivingDirections?: string;

  public compPercentage?: number;
  public gratuityAmount?: number;
  public tipAmount?: number;
  public totalAmount?: number;
  public totalTax?: number;
  public totalCompAmount?: number;
  public totalDiscountAmount?: number;

  public allowance?: boolean;
  public subscribe?: boolean;
  public unsubscribe?: boolean;

  public paymentTerms?: number;
  public loyaltyPoints?: number;
  public lifetimeLoyaltyPoints?: number;

  public lastLoyalty?: Date;
  public lastOrdered?: Date;
  public created?: Date;
  public updated?: Date;

  public load(data: any): StoreCustomer {

    Object.assign(this, data);

    return this;
  }
}
