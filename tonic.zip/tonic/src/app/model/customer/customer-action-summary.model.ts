import { CustomerAction } from "./customer-action.model";

export class CustomerActionSummary {

  public action: CustomerAction;
  public deposit: number;

  public load(data: any): CustomerActionSummary {

    Object.assign(data, this);

    this.action = new CustomerAction().load(data.action);

    return this;
  }
}
