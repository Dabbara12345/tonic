import { Store } from 'src/app/model/store.model';
import { User } from 'src/app/model/access/user.model';
import { Promotion } from 'src/app/model/customer/promotion.model';

export class PromotionEnrolled {

  public pointEarned: number;
  public fulfilled: number;
  public pointsLevelRedeemed: number;
  public contactId: number;
  public storeId: number;

  public created: Date;
  public updated: Date;

  public promotion: Promotion;
  public customer: User;
  public store: Store;

  public load(data: any): PromotionEnrolled {
    Object.assign(this, data);

    if (data?.created) {
      this.created = new Date(this.created);
    }

    if (data?.updated) {
      this.updated = new Date(this.updated);
    }

    if (data?.promotion) {
      this.promotion = new Promotion().load(this.promotion);
    }

    if (data?.customer) {
      this.customer = new User().load(this.customer);
    }

    if (data?.store) {
      this.store = new Store().load(this.store);
    }

    return this;

  }

}
