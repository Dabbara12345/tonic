import { Store } from '../store.model';

export class Community {

  public id?: number;

  public name?: string;
  public count: number;
  public description?: string;

  public disabled?: Date;
  public created?: Date;
  public updated?: Date;

  public stores?: Array<Store>;

  public load(data: any): Community {

    Object.assign(this, data);

    this.stores = new Array();

    data.stores
        ?.forEach((s: Store): void => {

        this.stores
            .push(new Store().load(s));
    });

    return this;
  }
}
