import { Deposit } from "./deposit.model";

export class DepositList {

  public available: number;

  public storeName: string;
  public voidedBy:  string;
  public deposit:   Deposit

  public load(data: any): this {

    Object.assign(this, data);

    if (data.deposit) {
      this.deposit = new Deposit().load(data.deposit);
    }

    return this;
  }
}
