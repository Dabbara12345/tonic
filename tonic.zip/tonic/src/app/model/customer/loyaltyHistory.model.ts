import { Store } from "src/app/model/store.model";
import { Batch } from "src/app/model/activity/batch.model";

export class LoyaltyHistory {

  public loyaltyHistoryId: number;
  public batchNumber: number;
  public opened: string;
  public closed: string;
  public customerVisits: number;
  public loyaltyPointsEarned: number;
  public loyaltyPointsRedeemed: number;
  public loyaltyRedemptionAmount: number;
  public customerGrossSalesAmount: number;
  public customerNetSalesAmount: number;
  public storeId?: number;

  public batch: Batch;
  public created?: Date;
  public updated?: Date;
  public store?: Store;

  public load(data: any): LoyaltyHistory {
    Object.assign(this, data);

    if(data?.batch) {
      this.batch = new Batch().load(data.batch);
    }

    if(data?.created) {
      this.created = new Date(data.created);
    }

    if(data?.updated) {
      this.updated = new Date(data.updated);
    }

    if(data?.store) {
      this.store = new Store().load(data.store);
    }

    return this;

  }

}
