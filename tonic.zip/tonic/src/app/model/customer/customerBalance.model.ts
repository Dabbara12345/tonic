export class CustomerBalance {

  public id: number;
  public customer: string;
  public since: Date;
  public balance: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
