import { PromotionItem } from "./promotionItem.model";
import { PromotionLevel } from "./promotionLevel.model";

export class Promotion {

    public id?: number;
    public name?: string;
    public points?: number;
    public enterprise?: boolean;
    public repeatable?: boolean;
    public autoEnroll?: boolean;
    public trackingOnly?: boolean;

    public start?: Date;
    public end?: Date;

    public items?: Array<PromotionItem>;
    public levels?: Array<PromotionLevel>;

    public load(data: any): Promotion {

      Object.assign(this, data);

      this.items = new Array();

      data.items
          ?.forEach((pI: PromotionItem): void => {

        this.items
            .push(new PromotionItem().load(pI));
      });

      this.levels = new Array();

      data.levels
          ?.forEach((pL: PromotionLevel): void => {

        this.levels
            .push(new PromotionLevel().load(pL));
      });

      return this;
    }

    public contains(level: PromotionLevel): boolean {

      const index: number = this.levels
                                ?.findIndex(i => i.name === level.name && i.points === level.points);

      return index !== -1;
    }
  }
