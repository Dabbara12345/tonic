export class CustomerSummary {

  public name: string;
  public totalOrders: number;
  public loyaltyPoints: number;
  public lifetimeLoyaltyPointer: number;
  public lastVisit: Date;
  public customerSince: Date;
  public totalSpent: number;

  public load(data: any): CustomerSummary {
    Object.assign(this, data);

    if(data?.lastVisit) {
      this.lastVisit = new Date(data.lastVisit);
    }

    if(data?.customerSince) {
      this.customerSince = new Date(data.customerSince);
    }

    return this;
  }
}
