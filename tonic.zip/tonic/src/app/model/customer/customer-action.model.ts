import { Customer } from "src/app/model/customer/customer.model";
import { Allowance } from "src/app/model/analytics/customer/allowance.model";

export class CustomerAction {

  public id?: number;
  public remoteId?: string;
  public storeId?: number;
  public customerId?: number;

  public name?: string;
  public description?: string;

  public refId?: number;
  public refName?: string;
  public type?: number;

  public oldPoints?: number;
  public newPoints?: number;
  public created?: Date;
  public allowance: Allowance;
  public customer: Customer;

  public load(data: any): CustomerAction {

    Object.assign(this, data);

    if(data?.created) {
        this.created = new Date(data.created);
    }

    if(data?.allowance) {
      this.allowance = new Allowance().load(data.allowance);
    }

    if(data?.customer) {
      this.customer = new Customer().load(data.customer);
    }

    return this;

  }

}
