export class CustomerActivities {

  public customerId: number;
  public date: Date;
  public name: string;
  public source: string;
  public amount: number;
  public voided: boolean;
  public voidedBy: string;
  public server: string;
  public orderId: number;
  public orderName: string;
  public orderType: number;
  public listType: string;

  public load(data: any): CustomerActivities {
    Object.assign(this, data);

    if(data?.date) {
      this.date = new Date(data.date);
    }

    return this;
  }
}
