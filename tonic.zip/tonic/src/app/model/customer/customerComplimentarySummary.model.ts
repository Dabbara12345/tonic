export class CustomerComplimentarySummary {

  public customerId: number;
  public name: string;
  public reason: string;
  public qty: number;
  public percent: number;
  public amount: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }

}
