
export class Loyalty {

  public storeId?: number;
  public priceMultiplier?: number;                         // 100 = 1/$, etc..
  public priceRoundingMethod?: number;                     // (1-3)
  public pointsPerVisit?: number;
  public visitMinimumPurchase?: number;
  public activationPoints?: number;
  public dobPoints?: number;
  public accountAnniversaryPoints?: number;
  public partialLoyaltyOnComp?: boolean;                   // If true, loyalty will be calculate on remaining amount of item after comp is applied.
  public partialLoyaltyRoundingMethod?: number;            // (1-3)
  public loyaltyOnDiscountedOrders?: boolean;              // If true, loyalty will be calculate on the discount amount using the priceMultiplier and subtracted from the total.

  public redemptionPriceMultiplier?: number;               // 100 = 1/$, etc...
  public redemptionPriceRoundingMethod?: number;
  public expiresAfter?: number;                            // Expires after x days. -1 means no expiration.
  public pointsThreshold?: number;                         // Message will pop up when threshold is reached. -1 means no threshold.
  public allowance?: number;                               // Amount (Number)
  public allowanceUseItOrLoseIt?: boolean;
  public allowanceMode?: AllowanceMode;                           // Allow...
  public allowanceModeOffset?: number;

  public load(data: any): Loyalty {
    Object.assign(this, data);

    return this;
  }

}

export class RoundingMethod {

  public static LOYALTY_PRICE_ROUNDING_METHOD_FLOOR: number = 1;
  public static LOYALTY_PRICE_ROUNDING_METHOD_ROUND: number = 2;
  public static LOYALTY_PRICE_ROUNDING_METHOD_CEIL: number  = 3;
}

export class AllowanceMode {

  public static ALLOWANCE_MODE_DAILY: number     = 0;
  public static ALLOWANCE_MODE_WEEKLY: number    = 1;
  public static ALLOWANCE_MODE_MONTHLY: number   = 2;
  public static ALLOWANCE_MODE_YEARLY: number    = 3;
  public static ALLOWANCE_MODE_BI_WEEKLY: number = 4;
}
