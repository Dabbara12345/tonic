import { SalesGroup } from "../../menu/salesGroup.model";
import { DailyGroupSales } from "./dailyGroupSales.model";

export class SalesByGroupByDay {

  public salesGroups: Array<SalesGroup>;
  public dailySales: Array<DailyGroupSales>;
  public groupTotals: Map<number, number>; //<SalesGroupId, Total>

  public load(data: any): SalesByGroupByDay {

    Object.assign(this, data);

    this.salesGroups = new Array();

    data?.salesGroups
        ?.forEach((s: SalesGroup): void => {

          this.salesGroups
              .push(new SalesGroup().load(s));
        });

    this.dailySales = new Array();

    data?.dailySales
        ?.forEach((dG: DailyGroupSales): void => {

          this.dailySales
              .push(new DailyGroupSales().load(dG));
        });

    this.groupTotals = new Map();

    data?.groupTotals
        ?.forEach((t: any): void => {

          this.groupTotals
              .set(t.key,
                   t.value);
        });

    return this;
  }
}
