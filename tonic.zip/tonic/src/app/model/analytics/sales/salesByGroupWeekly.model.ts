import { SalesGroup } from "../../menu/salesGroup.model";
import { NameValue } from "../../utils/nameValue.model";
import { DataComparison } from "../data-comparison";
import { WeeklyGroupSales } from "./weeklyGroupSales.model";

export class SalesByGroupWeekly {

  public salesGroups: Array<SalesGroup>;
  public weeklySales: Array<WeeklyGroupSales>;
  public groupTotals: Map<number, number>; //<SalesGroupId, Total>

  public load(data: any): SalesByGroupWeekly {

    Object.assign(this, data);

    this.salesGroups = new Array();

    data?.salesGroups
        ?.forEach((sG: SalesGroup): void => {
      
          this.salesGroups
              .push(new SalesGroup().load(sG));
        });

    this.weeklySales = new Array();

    data?.weeklySales
        ?.forEach((wGS: WeeklyGroupSales): void => {
      
          this.weeklySales
              .push(new WeeklyGroupSales().load(wGS));
        });

    this.groupTotals = new Map();

    data?.groupTotals
        ?.forEach((t: any): void => {

          this.groupTotals
              .set(t.key,
                   t.value);
        });

    return this;
  }


  public compare(previous: SalesByGroupWeekly): Array<DataComparison> {

    const comparison: DataComparison[] = new Array<DataComparison>();

    this.weeklySales
        .forEach(c =>{

          const d = new DataComparison();
          const p: WeeklyGroupSales = previous.weeklySales
                                              .find(w => w.week === c.week && w.year === (c.year - 1));

          d.id = c.month.toString();
          d.current = new NameValue().load({name: c.year,
                                          value: c.total});
          d.previous = new NameValue().load({name: c.year - 1,
                                          value: p ? p.total : 0});
          comparison.push(d);
        });

    return comparison;
  }
}
