export class SalesByServerOtherPayments {

  public orderId: number;
  public orderType: number;
  public otherUserName: string;
  public paymentType: number;
  public tip: number;
  public gratuity: number;
  public gratuityAndTip: number;
  public total: number;
  public change: number;


  public load(data: any): SalesByServerOtherPayments {

    Object.assign(this, data);

    return this;

  }

}
