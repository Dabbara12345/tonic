export class DailyGroupSales {

  public day: string;
  public dateStr: string;
  public date: Date;
  public total: number;

  public groupSales: Map<number, number>; //<SalesGroupId, Total>

  public load(data: any): DailyGroupSales {
    Object.assign(this, data);

    return this;
  }
}
