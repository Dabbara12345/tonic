import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';
import { Shift } from '../time/shift.model';

export class SalesByShiftReport extends AnalyticSalesReport {

  public value: Array<Shift>;

  public uri(): string {
    return super.uri() + '/salesByShiftTotal';
  }
}
