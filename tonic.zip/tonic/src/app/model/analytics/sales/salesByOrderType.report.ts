import { HttpParams } from '@angular/common/http';
import { SalesByOrderType } from './salesByOrderType.model';
import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';

export class SalesByOrderTypeReport extends AnalyticSalesReport {

  public value: Array<SalesByOrderType>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('salesByOrderType', true);

    return params;
  }
}
