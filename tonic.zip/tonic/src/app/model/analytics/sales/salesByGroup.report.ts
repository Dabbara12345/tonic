import { HttpParams } from '@angular/common/http';
import { SalesByGroup } from './salesByGroup.model';
import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';

export class SalesByGroupReport extends AnalyticSalesReport {

  public value: Array<SalesByGroup>;

  public params(): HttpParams {

      let params: HttpParams = new HttpParams();

      params = params.append('salesByGroup', true);
      params = params.append('salesByGroupTax', true);
      params = params.append('salesByGroupGratuity', true);

      return params;

  }

}
