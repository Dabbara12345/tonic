import { HttpParams } from '@angular/common/http';
import { GroupMatrix } from './groupMatrix.model';
import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';

export class SalesByGroupMatrixReport extends AnalyticSalesReport {

  public value: Array<GroupMatrix>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('groupMatrix', true);

    return params;
  }
}
