export class GroupMatrix {

  public groupNames: Map<string, number>;
  public groups: Map<string, Map<string, number>>;

  public load(data: any): GroupMatrix {
    Object.assign(this, data);

    //Convert objects to Map
    if (data?.groupNames) {
      this.groupNames = new Map(Object.entries(data.groupNames));
    }

    if (data?.groups) {

      this.groups = new Map(Object.entries(data.groups)
                                .map(entry => {
                                  return [entry[0], new Map(Object.entries(entry[1]))];
                                }));
    }

    return this;
  }
}
