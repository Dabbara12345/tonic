import { SalesByServerOtherPayments } from "src/app/model/analytics/sales/salesByServerOtherPayments.model";

export class SalesByServer {

  public name: string;
  public type: any;
  public cardType: number;
  public count: number;
  public amount: number;
  public surcharge: number;
  public gratuity: number;
  public tip: number;
  public gratuityTip: number;
  public cashBack: number;
  public total: number;
  public byOthers: Array<SalesByServerOtherPayments>;
  public forOthers: Array<SalesByServerOtherPayments>;

  public load(data: any): SalesByServer {

    Object.assign(this, data);

    this.byOthers = new Array<SalesByServerOtherPayments>();

    data?.byOthers
        ?.forEach((item: SalesByServerOtherPayments): void => {
            this.byOthers
                .push(new SalesByServerOtherPayments().load(item));
          });

    this.forOthers = new Array<SalesByServerOtherPayments>();

    data?.forOthers
        ?.forEach((item: SalesByServerOtherPayments): void => {
            this.forOthers
                .push(new SalesByServerOtherPayments().load(item));
          });

    return this;

  }

}
