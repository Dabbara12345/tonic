import { HttpParams } from '@angular/common/http';
import { HourlySales } from './hourlySales.model';
import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';
import { DataComparison } from '../data-comparison';
import { NameValue } from '../../utils/nameValue.model';

export class HourlySalesReport extends AnalyticSalesReport {

  public value: Array<HourlySales>;
  public compareItem?: string;
  public compareLabel?: string;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('salesByHour', true);

    return params;
  }

  public compare(previous: any): Array<DataComparison> {

    const comparison: DataComparison[] = new Array<DataComparison>();

    this.value
        .forEach(c =>{

          const d = new DataComparison();
          const p: any = previous.find(w => w.hour === c.hour);

          d.id = c.hour.toString() + ':00';

          d.current = new NameValue().load({ name: new Date(this.criteria.fromDate).getFullYear(),
                                             value: c[this.compareItem] });

          d.previous = new NameValue().load({ name: new Date(this.criteria.fromDate).getFullYear() - 1,
                                              value: p ?
                                                      p[this.compareItem] : 0 });
          comparison.push(d);
        });

    return comparison;
  }
}
