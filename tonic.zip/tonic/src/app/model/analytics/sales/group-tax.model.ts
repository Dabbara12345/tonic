export class GroupTax {

  public name: string;

  public tax: number;
  public exemptTax: number;
  public percentage: number;
  public gratuityTaxAmount: number;

  public load(data: any): GroupTax {

    Object.assign(this, data);

    return this;

  }

}
