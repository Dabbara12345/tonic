import { HttpParams } from '@angular/common/http';
import { SalesHistory } from './salesHistory.model';
import { AnalyticBatchReport } from '../reportPaths/analyticBatchReport';

export class SalesHistoryByShiftReport extends AnalyticBatchReport {

  public value: Array<SalesHistory>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('salesHistoryByShift', true);

    return params;
}
}
