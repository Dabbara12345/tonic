import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';
import { SalesByGroupWeekly } from './salesByGroupWeekly.model';

export class SalesByGroupWeeklyReport extends AnalyticSalesReport {

  public value: Array<SalesByGroupWeekly>;

  public uri(): string {
    return super.uri() + '/salesByGroupByWeek';
  }
}
