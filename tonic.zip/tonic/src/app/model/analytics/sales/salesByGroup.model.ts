import { GroupTax } from "src/app/model/analytics/sales/group-tax.model";

export class SalesByGroup {

  public groupName: string;
  public name: string;
  public xprice: number;
  public items: number;
  public subTotal: number;
  public comp: number;
  public disc: number;
  public net: number;
  public taxes: Array<GroupTax>;
  public gross: number;
  public storeId: number;

  public load(data: any): SalesByGroup {

    Object.assign(this,
                    data);

    this.taxes = new Array<GroupTax>();

    data?.taxes
        ?.forEach((t: GroupTax): void => {

          this.taxes
              .push(new GroupTax().load(t));
      });

    return this;
  }
}
