import { HttpParams } from '@angular/common/http';
import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';
import { SalesByServer } from './salesByServer.model';

export class SalesByServerReport extends AnalyticSalesReport {

  public value: Array<SalesByServer>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('salesByServer', true);
    params = params.append('salesByServerForOtherPayments', true);

    return params;
  }
}
