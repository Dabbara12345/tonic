import { AnalyticReport } from '../reportPaths/analyticReport';

export class SalesSummaryReport extends AnalyticReport {

  public value: Array<any>;

}
