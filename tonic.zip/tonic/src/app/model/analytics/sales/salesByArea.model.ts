export class SalesByArea {

  public areaName: string;
  public groupName?: string;
  public name: string;
  public subTotal: number;
  public compTotal: number;
  public discTotal: number;
  public net: number;
  public tax: number;
  public gross: number;
  public gratuity: number;
  public tip: number;

  public load(data: any): SalesByArea {

    Object.assign(this, data);

    return this;
  }
}
