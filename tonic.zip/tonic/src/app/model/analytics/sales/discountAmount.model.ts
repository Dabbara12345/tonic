export class DiscountAmount {

  public credit: number;
  public creditOnline: number;
  public debit: number;

  public load(data: any): DiscountAmount {

    Object.assign(this, data);

    return this;
  }
}
