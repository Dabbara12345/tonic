import { NameValue } from '../../utils/nameValue.model';
import { DataComparison } from '../data-comparison';
import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';
import { SalesByDate } from './sales-by-date.model';
export class SalesByWeekReport extends AnalyticSalesReport {

  public value: Array<SalesByDate>;
  public compareItem?: string;
  public compareLabel?: string;

  public uri(): string {
    return super.uri() + '/salesTotal/byWeek';
  }

  public compare(previous: any): Array<DataComparison> {

    const monthNames: string[] = [ "January", "February", "March", "April", "May", "June",
                                   "July", "August", "September", "October", "November", "December" ];

    const comparison = new Array<DataComparison>();

    this.value.sort((a, b): number => a.date.toString()
                                            .localeCompare(b.date.toString()));
    this.value
        .forEach(c => {

          const d = new DataComparison();
          const p: any = previous.find(w => (new Date(w.date).getMonth() === new Date(c.date).getMonth()) &&
                                            (new Date(w.date).getFullYear() === (new Date(c.date).getFullYear() - 1)) &&
                                            w.weekNum === c.weekNum);

          d.id = c.weekNum.toString();

          let currValue: number = 0;
          let prevValue: number = 0;

          if (this.compareItem === 'net') {
            currValue = c['gross'] - c['tax'];
            prevValue = p ? p['gross'] - p['tax'] : 0;
          } else {
            currValue = c[this.compareItem];
            prevValue = p ? p[this.compareItem] : 0;
          }

          if (prevValue === Infinity) {
            prevValue = 0;
          }

          d.current = new NameValue().load({ name: monthNames[new Date(c.date).getMonth()] +
                                                   ' ' + new Date(c.date).getFullYear(),
                                             value: currValue});

          d.previous = new NameValue().load({ name: new Date(c.date).getFullYear() - 1,
                                              value: prevValue ? prevValue : 0});

          comparison.push(d);
        });

    return comparison;
  }
}
