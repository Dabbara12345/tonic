export class SalesByDate {

  public date: Date;
  public dayName: string;
  public weekNum: number;
  public quantity: number;
  public guests: number;
  public dineInGross: number;
  public dineInGuests: number;
  public gross: number;
  public tax: number;
  public avgOrder: number;
  public avgGuest: number;
  public max: number;
  public year: number;

  public load(data: any): SalesByDate {

    Object.assign(this, data);

    if(data?.date){
      this.date = new Date(data.date);
    }

    return this;
  }

}
