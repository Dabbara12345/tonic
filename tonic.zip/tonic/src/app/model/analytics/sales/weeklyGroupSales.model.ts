export class WeeklyGroupSales {

  public year: number;
  public month: number;
  public week: number;
  public total: number;

  public groupSales: Map<number, number>; //<SalesGroupId, Total>

  public load(data: any): WeeklyGroupSales {
    Object.assign(this, data);

    return this;
  }
}
