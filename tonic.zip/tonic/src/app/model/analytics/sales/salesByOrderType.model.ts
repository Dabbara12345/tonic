import { HttpParams } from '@angular/common/http';
import { OrderTax } from '../../activity/orderTax.model';
import { OrderReport } from '../reportPaths/orderReport';

export class SalesByOrderType extends OrderReport {

  public type: any;
  public subTotal: number;
  public comp: number;
  public net: number;
  public gross: number;

  public taxes: Array<OrderTax>;

  public load(data: any): this {

    Object.assign(this, data);

    this.taxes = new Array();

    data?.taxes
        ?.forEach((oT: OrderTax): void => {
          this.taxes
              .push(new OrderTax().load(oT));
        });

    return this;
  }

  public params(): HttpParams {

      let params: HttpParams = new HttpParams();
      let label: string = this.reportId[0].toLowerCase() + this.reportId.substring(1);

      params = params.append(label, true);

      return params;
  }
}
