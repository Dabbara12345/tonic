import { AnalyticReport } from "src/app/model/analytics/reportPaths/analyticReport";

export class DailySummaryReport extends AnalyticReport {

  public value: Array<any>;

}
