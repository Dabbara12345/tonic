import { AdminReport } from "../admin-report.model";

export abstract class ChoiceReport extends AdminReport {

  public uri(): string {
    return 'activity/choice';
  }
}
