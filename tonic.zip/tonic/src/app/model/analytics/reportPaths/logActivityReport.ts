import { AdminReport } from "../admin-report.model";

export abstract class LogActivityReport extends AdminReport {

  public uri(): string {
    return 'log/activity';
  }
}
