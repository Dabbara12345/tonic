import { AdminReport } from "../admin-report.model";

export abstract class SidesReport extends AdminReport {

  public uri(): string {
    return 'activity/sides';
  }
}
