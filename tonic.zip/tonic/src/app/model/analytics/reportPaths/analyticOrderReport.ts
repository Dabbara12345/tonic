import { AdminReport } from "../admin-report.model";

export abstract class AnalyticOrderReport extends AdminReport {

  public uri(): string {
    return 'analytic/order';
  }
}
