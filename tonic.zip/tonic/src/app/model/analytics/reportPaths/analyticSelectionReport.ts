import { AdminReport } from "src/app/model/analytics/admin-report.model";

export abstract class AnalyticSelectionReport extends AdminReport {

  public uri(): string {
    return 'analytic/selection';
  }
}
