import { AdminReport } from "../admin-report.model";
export abstract class AnalyticAuthRequestReport extends AdminReport {

  public uri(): string {
      return 'analytic/authRequest';
  }
}
