import { AdminReport } from "../admin-report.model";

export abstract class AnalyticInventoryReport extends AdminReport {

  public uri(): string {
    return 'analytic/inventory';
  }
}
