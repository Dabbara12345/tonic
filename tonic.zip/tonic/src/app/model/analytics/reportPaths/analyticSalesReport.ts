import { AdminReport } from "../admin-report.model";

export abstract class AnalyticSalesReport extends AdminReport {

  public uri(): string {
    return 'analytic/sales';
  }
}
