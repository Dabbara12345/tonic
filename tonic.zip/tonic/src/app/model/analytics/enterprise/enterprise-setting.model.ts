export class EnterpriseSetting {

  public name: string;
  public targets: Map<number, boolean> = new Map();
  public property: string;
  public propertyKey: number;
  public icon: string;

  constructor(name: string,
              property: string,
              icon?: string,
              propertyKey?: number) {

    this.name = name;
    this.property = property;
    this.propertyKey = propertyKey;
    this.icon = icon;

  }

  public setTargetValue(targetId: number,
                        value: boolean): void {

    this.targets
        .set(targetId,
             value);

  }

}
