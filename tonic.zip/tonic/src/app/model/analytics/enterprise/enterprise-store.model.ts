export class EnterpriseStore {

  public id: number;
  public name: string;

  public synchIngredients: boolean;
  public synchPreparations: boolean;
  public synchRecipes: boolean;
  public synchTaxes: boolean;
  public synchComps: boolean;
  public synchDiscounts: boolean;
  public synchPrinters: boolean;
  public synchKvds: boolean;

  public updateExisting: boolean;
  public cleanOrphans: boolean;
  public lockMenus: boolean;
  public leaveRecipesOnPrinter: boolean;
  public leavePrepPrices: boolean;

}
