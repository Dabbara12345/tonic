import { EnterpriseReport } from "../enterpriseReport.model";

export class EnterpriseCustomerPromotionEnrollmentSummary extends EnterpriseReport {

  public value: Array<any>;

  public uri(): string {
    return super.uri() + '/promotionEnrollmentSummary';
  }
}
