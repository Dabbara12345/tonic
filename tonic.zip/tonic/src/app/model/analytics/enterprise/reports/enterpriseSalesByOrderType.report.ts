import { EnterpriseReport } from "../enterpriseReport.model";

export class EnterpriseSalesByOrderType extends EnterpriseReport {

  public value: Array<any>;

  public uri(): string {
    return super.uri() + '/salesByOrderType';
  }
}
