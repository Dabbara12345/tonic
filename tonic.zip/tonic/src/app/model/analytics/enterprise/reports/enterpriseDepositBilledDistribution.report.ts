import { EnterpriseReport } from "../enterpriseReport.model";

export class EnterpriseDepositBilledDistribution extends EnterpriseReport {

  public value: Array<any>;

  public uri(): string {
    return super.uri() + '/deposit';
  }
}
