import { Criteria } from "../../criteria.model";
import { AdminReport } from "../../admin-report.model";
import { EnterpriseReport } from "../enterpriseReport.model";

export class EnterpriseSalesByGroup extends EnterpriseReport {

  public value: Array<any>;

  constructor() {
    super();
    this.criteria = new Criteria();
  }

  public load(data: AdminReport): this {
    Object.assign(this, data);

    this.value = data.value;

    return this;
  }

  public uri(): string {
    return super.uri() + '/salesByGroup';
  }
}
