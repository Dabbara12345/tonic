export class ItemsSold {

  public group: string;
  public name: string;
  public ruleName: string;
  public weekDay: string;
  public server: string;
  public area: string;
  public type: string;
  public table: string;

  public multiplier: number;
  public price: number;
  public quantity: number;
  public average: number;
  public amount: number;
  public orderType: number;
  public orderTypeLabel?: string;

  public date: Date;

  public load(data: any): ItemsSold {

    Object.assign(this, data);

    return this;
  }
}
