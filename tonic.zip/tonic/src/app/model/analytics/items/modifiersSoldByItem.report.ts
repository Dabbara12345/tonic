import { ChoiceReport } from 'src/app/model/analytics/reportPaths/choiceReport';
import { ChoicesCount } from 'src/app/model/analytics/items/choicesCount.model';

export class ModifiersSoldByItemReport extends ChoiceReport {
  public value: Array<ChoicesCount>;
}
