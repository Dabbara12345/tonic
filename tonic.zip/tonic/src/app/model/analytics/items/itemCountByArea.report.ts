import { HttpParams } from '@angular/common/http';

import { ItemsSold } from 'src/app/model/analytics/items/itemsSold.model';
import { AnalyticSelectionReport } from 'src/app/model/analytics/reportPaths/analyticSelectionReport';

export class ItemCountByAreaReport extends AnalyticSelectionReport {

  public value: Array<ItemsSold>;

  public params(): HttpParams {
    let params: HttpParams = new HttpParams();
    params = params.append('count', true);

    return params;
  }
}
