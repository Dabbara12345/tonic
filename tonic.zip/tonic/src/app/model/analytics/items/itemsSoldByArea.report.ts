import { AnalyticSelectionReport } from '../reportPaths/analyticSelectionReport';
import { ItemsSold } from './itemsSold.model';

export class ItemsSoldByAreaReport extends AnalyticSelectionReport {
  public value: Array<ItemsSold>;
}
