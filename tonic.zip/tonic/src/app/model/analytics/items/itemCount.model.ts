export class ItemCount {

  public type: string;
  public name: string;
  public group: string;

  public price: number;
  public quantity: number;

  public serverId?: number;
  public areaId?: number;

  public load(data: any): ItemCount {

    Object.assign(this, data);

    return this;
  }

}
