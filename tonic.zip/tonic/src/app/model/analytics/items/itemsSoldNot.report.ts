import { HttpParams } from '@angular/common/http';

import { AnalyticReport } from '../reportPaths/analyticReport';
import { NotSelling } from './notSelling.model';

export class ItemsSoldNotReport extends AnalyticReport {

  public value: Array<NotSelling>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('notSelling', true);

    return params;
  }
}
