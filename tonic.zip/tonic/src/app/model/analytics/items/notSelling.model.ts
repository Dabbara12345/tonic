export class NotSelling {

  public name: string;
  public type: string;

  public price: number;

  public created: Date;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
