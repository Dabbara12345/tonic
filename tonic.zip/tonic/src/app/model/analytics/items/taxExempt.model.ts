export class TaxExempt {

  public tax: string;
  public item: string;
  public type: string;
  public orderName: string;

  public qty: number;
  public comp: number;
  public total: number;
  public amount: number;
  public orderId: number;
  public percent: number;
  public multiplier: number;

  public orderDate: string;

}
