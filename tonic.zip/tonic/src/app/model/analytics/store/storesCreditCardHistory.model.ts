export class StoresCreditCardHistory {

  public name:      string;

  public id:        number;
  public type:      number;
  public count:     number;
  public subTotal:  number;
  public surcharge: number;
  public gratuity:  number;
  public tip:       number;
  public total:     number;

  public cardType?: string;

  public load(data: any): StoresCreditCardHistory {
    Object.assign(this, data);

    return this;
  }
}
