import { StoresCreditCardSales } from "./storesCreditCardSales.model";
import { AnalyticStoreReport } from "../reportPaths/analyticStoreReport";

export class StoresCreditCardSalesReport extends AnalyticStoreReport {

  public value: Array<StoresCreditCardSales>;

  public uri(): string {
    return super.uri() + '/creditCardSales';
  }
}
