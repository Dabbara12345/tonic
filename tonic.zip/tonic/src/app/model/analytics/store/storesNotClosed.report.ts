import { StoresNotClosed } from "./storesNotClosed.model";
import { AnalyticStoreReport } from "../reportPaths/analyticStoreReport";

export class StoresNotClosedReport extends AnalyticStoreReport {

  public value: Array<StoresNotClosed>;

  public uri(): string {
    return super.uri() + '/notClosed';
  }
}
