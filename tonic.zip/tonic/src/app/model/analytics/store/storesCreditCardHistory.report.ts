import { AnalyticStoreReport } from "../reportPaths/analyticStoreReport";
import { StoresCreditCardHistory } from "./storesCreditCardHistory.model";

export class StoresCreditCardHistoryReport extends AnalyticStoreReport {

  public value: Array<StoresCreditCardHistory>;

  public uri(): string {
    return super.uri() + '/creditCardHistory';
  }
}
