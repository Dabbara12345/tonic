import { HttpParams } from '@angular/common/http';

import { AnalyticReport } from 'src/app/model/analytics/reportPaths/analyticReport';

export class FutureOrdersSalesSummaryReport extends AnalyticReport {

  public value: Array<any>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('futureOrder', true);

    return params;

  }

}
