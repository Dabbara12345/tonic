import { User } from '../access/user.model';
import { Store } from '../store.model';

export class Header {

  public category: string;
  public type: string;
  public from: string;
  public to: string;
  public count: number;
  public ran: string;

  public store: Store;
  public user: User;

  public load(data: any): Header {

    Object.assign(this, data);

    if (data.user){
      this.user = new User().load(data.user);
    }

    if (data.store){
      this.store = new Store().load(data.store);
    }

    return this;
  }
}
