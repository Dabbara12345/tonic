import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { PurchaseOrdersAnalytic } from "./purchaseOrdersAnalytic.model";

export class PurchaseOrdersAnalyticReport extends AnalyticInventoryReport {

  public value: Array<PurchaseOrdersAnalytic>;

  public uri(): string {
    return super.uri() + '/purchaseOrders';
  }
}
