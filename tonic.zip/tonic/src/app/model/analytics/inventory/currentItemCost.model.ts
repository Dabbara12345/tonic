export class CurrentItemCost {

  public menuItem:        string;
  public salesGroup:      string;
  public percentage:      string;

  public itemPrice:       number;
  public recipeCost:      number;
  public margin:          number;
  public costPrice:       number;
  public suggestedPrice:  number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
