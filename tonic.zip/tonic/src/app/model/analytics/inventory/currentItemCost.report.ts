import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { CurrentItemCost } from "./currentItemCost.model";

export class CurrentItemCostReport extends AnalyticInventoryReport {

  public value: Array<CurrentItemCost>;

  public uri(): string {
    return super.uri() + '/currentItemCost';
  }
}
