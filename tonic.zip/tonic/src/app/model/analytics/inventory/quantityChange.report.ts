import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { QuantityChange } from "./quantityChange.model";

export class QuantityChangeReport extends AnalyticInventoryReport {

  public value: Array<QuantityChange>;

  public uri(): string {
    return super.uri() + '/quantityChange';
  }
}
