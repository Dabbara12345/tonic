export class IngredientDetails {

  public name: string;
  public cost: number;
  public type: number;

  public load(data: any): IngredientDetails {
    Object.assign(this, data);

    return this;
  }
}
