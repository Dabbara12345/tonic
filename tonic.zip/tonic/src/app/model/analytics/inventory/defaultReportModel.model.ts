import { AnalyticReport } from '../reportPaths/analyticReport';

//To be deleted when all the models are created
export class DefaultReportModel extends AnalyticReport {

  public value: any;
}
