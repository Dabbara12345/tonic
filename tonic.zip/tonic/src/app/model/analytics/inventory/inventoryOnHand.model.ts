export class InventoryOnHand {

  public ingredient:  string;
  public category:    string;
  public unit:        string;

  public cost:        number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
