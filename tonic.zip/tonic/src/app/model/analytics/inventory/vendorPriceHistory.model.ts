export class VendorPriceHistory {

  public vendor:        string;
  public purchaseOrder: string;
  public unitSize:      string;
  public ingredient:    string;

  public price:         number;
  public ordered:       number;
  public paid:          number;

  public date:            Date;

  public load(data: any): this {
    Object.assign(this, data);

    if (data?.date) {
      this.date = new Date(this.date);
    }

    return this;
  }
}
