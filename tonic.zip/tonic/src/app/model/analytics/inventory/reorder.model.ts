export class Reorder {

  public ingredient:  string;
  public vendor:      string;
  public par:         string;
  public onHand:      string;

  public avgCost:     number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
