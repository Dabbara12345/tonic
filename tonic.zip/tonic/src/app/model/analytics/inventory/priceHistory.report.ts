import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { VendorPriceHistory } from "./vendorPriceHistory.model";

export class PriceHistoryReport extends AnalyticInventoryReport {

  public value: Array<VendorPriceHistory>;

  public uri(): string {
    return super.uri() + '/priceHistory';
  }
}
