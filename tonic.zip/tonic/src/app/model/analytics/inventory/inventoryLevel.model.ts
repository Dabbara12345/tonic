export class InventoryLevel {

  public ingredient:      string;
  public onHand:          string;

  public totalCost:       number;
  public avgCost:         number;

  public date:            Date;

  public load(data: any): this {
    Object.assign(this, data);

    if (data?.date) {
      this.date = new Date(this.date);
    }

    return this;
  }
}
