import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { InventoryBelowPar } from "./inventoryBelowPar.model";

export class InventoryBelowParReport extends AnalyticInventoryReport {

  public value: Array<InventoryBelowPar>;

  public uri(): string {
    return super.uri() + '/inventoryBelowPar';
  }
}
