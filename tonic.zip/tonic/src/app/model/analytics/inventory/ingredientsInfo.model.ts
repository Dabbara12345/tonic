import { IngredientDetails } from './ingredientDetails.model';

export class IngredientsInfo {

  public categories: Array<IngredientDetails>;
  public total: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
