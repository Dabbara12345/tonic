export class InventoryBelowPar {

  public name:      string;
  public par:       string;
  public available: string;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
