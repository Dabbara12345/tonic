export class QuantityChange {

  public ingredient:      string;
  public reason:          string;
  public by:              string;
  public note:            string;
  public netChange:       string;

  public netChangeValue:  number;

  public date:            Date;

  public load(data: any): this {
    Object.assign(this, data);

    if (data?.date) {
      this.date = new Date(this.date);
    }

    return this;
  }
}
