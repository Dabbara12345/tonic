import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { InventoryAge } from "./inventoryAge.model";

export class AgeReport extends AnalyticInventoryReport {

  public value: Array<InventoryAge>;

  public uri(): string {
    return super.uri() + '/age';
  }
}
