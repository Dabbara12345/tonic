import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { InventoryLevel } from "./inventoryLevel.model";

export class InventoryLevelsReport extends AnalyticInventoryReport {

  public value: Array<InventoryLevel>;

  public uri(): string {
    return super.uri() + '/inventoryLevels';
  }
}
