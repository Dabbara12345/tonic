export class InTransit {

  public vendorName:  string;
  public ingredient:  string;
  public size:        string;

  public quantity:    number;
  public unitPrice:   number;
  public charge:      number;
  public yield:       number;

  public ordered:     Date;
  public promised:    Date;

  public load(data: any): this {
    Object.assign(this, data);

    if (data?.ordered) {
      this.ordered = new Date(this.ordered);
    }

    if (data?.promised) {
      this.promised = new Date(this.promised);
    }

    return this;
  }
}
