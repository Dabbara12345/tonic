import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { InventoryOnHand } from "./inventoryOnHand.model";

export class IngredientsOnHandReport extends AnalyticInventoryReport {

  public value:     Array<InventoryOnHand>;

  public uri(): string {
    return super.uri() + '/ingredientsOnHand';
  }
}
