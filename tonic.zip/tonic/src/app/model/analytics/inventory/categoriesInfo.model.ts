import { CategoryInfo } from './categoryInfo.model';

export class CategoriesInfo {

  public categories: Array<CategoryInfo>;
  public total: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
