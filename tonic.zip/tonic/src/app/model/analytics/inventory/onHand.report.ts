import { AnalyticInventoryReport } from "../reportPaths/analyticInventoryReport";
import { InventoryOnHand } from "./inventoryOnHand.model";

export class OnHandReport extends AnalyticInventoryReport {

  public value: Array<InventoryOnHand>;

  public uri(): string {
    return super.uri() + '/onHand';
  }
}
