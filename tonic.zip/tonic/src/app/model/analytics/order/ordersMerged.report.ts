import { AnalyticOrderReport } from "../reportPaths/analyticOrderReport";
import { OrdersMerged } from "./ordersMerged.model";

export class OrdersMergedReport extends AnalyticOrderReport {

  public value: Array<OrdersMerged>;

  public uri(): string {
    return super.uri() + '/merged';
  }
}
