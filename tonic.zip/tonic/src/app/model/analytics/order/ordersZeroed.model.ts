export class OrdersZeroed {

  public id: number;
  public name: string;
  public created: string;
  public humanizedDate?: string;
  public server: string;
  public itemCount: number;
  public compAmount: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
