import { AnalyticOrderReport } from 'src/app/model/analytics/reportPaths/analyticOrderReport';

export class OrdersZeroedReport extends AnalyticOrderReport {

  public uri(): string {
    return super.uri() + '/zeroed';
  }
}
