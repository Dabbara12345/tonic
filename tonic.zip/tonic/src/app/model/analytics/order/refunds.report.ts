import { HttpParams } from '@angular/common/http';
import { OrderReport } from '../reportPaths/orderReport';
import { Order } from '../../activity/order.model';

export class RefundsReport extends OrderReport {

  public value: Array<Order>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('withServer', true);

    params = params.append('withTerminal', true);

    params = params.append('withRefunds', true);

    params = params.append('withDiscounts', false);

    return params;
  }
}
