import { AdminReport } from "../admin-report.model";

export abstract class AttendanceReport extends AdminReport {

    uri(): string {
        return 'analytic/attendance';
    }

    conciseData(): any {}
}
