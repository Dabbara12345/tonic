import { Criteria } from "../../criteria.model";
import { AdminReport } from "../../admin-report.model";
import { AttendanceReport } from "../attendanceReport.model";
import { AttendanceDetails } from "src/app/model/vas/attendance-details.model";
import { TimeAttendanceReportService } from '../../../../service/vas/time/time-attendance-report.service';
import { AttendanceTotals } from '../../../vas/attendance-totals.model';
import { LaborCost } from "src/app/model/vas/labor-cost.model";

export class HourlyLaborCostReport extends AttendanceReport {
  public value: Array<LaborCost>;

  private timeAttendanceReportService: TimeAttendanceReportService

  constructor() {
    super();
    this.criteria = new Criteria();
  }

  public uri(): string {
    return super.uri() + '/hourly';
  }

  public load(data: AdminReport): this {
    Object.assign(this, data);

    this.value = data.value;

    return this;
  }

  public setTimeAttendanceService(timeAttendanceReportService?: TimeAttendanceReportService): void {
    this.timeAttendanceReportService = timeAttendanceReportService;
  }

  public conciseData(): Array<Array<AttendanceDetails>> {
    let data = new Array<Array<AttendanceDetails>>();

    // let mappedData = this.timeAttendanceReportService
    //                      .mapOutData(this.value);
    // mappedData.forEach(d => {
    //   data.push(d)
    // });

    return data;
  }

  public getTotalFor(id: number, property: string): number {
    let total = 0;
    // let mappedData = this.timeAttendanceReportService
    //                      .mapOutData(this.value);

    // mappedData.get(id).forEach(a => {
    //   if (a.userAttendance.payroll[property]) {
    //     total += a.userAttendance.payroll[property];
    //   }
    // });

    return total;
  }

}
