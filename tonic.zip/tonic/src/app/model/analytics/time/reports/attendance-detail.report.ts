import { HttpParams } from '@angular/common/http';

import { Shift } from 'src/app/model/vas/time/shift.model';
import { Criteria } from "src/app/model/analytics/criteria.model";
import { AdminReport } from "src/app/model/analytics/admin-report.model";
import { AttendanceDetails } from "src/app/model/vas/attendance-details.model";
import { AttendanceReport } from "src/app/model/analytics/time/attendanceReport.model";

export class AttendanceDetailReport extends AttendanceReport {
  value: [Array<AttendanceDetails>, Array<Shift>];

  constructor() {
    super();
    this.criteria = new Criteria();
  }

  public params(): HttpParams {
    let params: HttpParams = new HttpParams();
    params = params.append('attendanceDetail', true);
    params = params.append('attendanceShift', true);

    return params;
  }

  public load(data: AdminReport): this {
    Object.assign(this, data);

    this.value = data.value;

    return this;
  }

  public conciseData(): Map<number, Array<AttendanceDetails>> {
    let map = new Map<number, Array<AttendanceDetails>>();

    this.value[0]
        .forEach((attendance) => {
      let id = attendance.userAttendance
                         .userId;

      if (map.has(id)) {
        let cList = map.get(id);

        cList.push(attendance);

        map.set(id, cList);
      } else {
        let nList = new Array<AttendanceDetails>();

        nList.push(attendance);

        map.set(id, nList);
      }
    });

    return map;
  }
}
