import { AttendanceReport } from "../attendanceReport.model";
import { AttendanceDetails } from '../../../vas/attendance-details.model';
import { AdminReport } from "../../admin-report.model";
import { Criteria } from "../../criteria.model";

export class AttendanceSummaryReport extends AttendanceReport {
  value: Array<AttendanceDetails>;

  constructor() {
    super();
    this.criteria = new Criteria();
  }

  public load(data: AdminReport): this {
    Object.assign(this, data);

    this.value = data.value;

    return this;
  }

  public conciseData(): Map<number, Array<AttendanceDetails>> {
    let map = new Map<number, Array<AttendanceDetails>>();

    this.value
        .forEach((attendance) => {
      let id = attendance.userAttendance
                         .userId;

      if (map.has(id)) {
        let cList = map.get(id);

        cList.push(attendance);

        map.set(id, cList);
      } else {
        let nList = new Array<AttendanceDetails>();

        nList.push(attendance);

        map.set(id, nList);
      }
    });

    return map;
  }
}
