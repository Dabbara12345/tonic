import { Criteria } from "../../criteria.model";
import { AdminReport } from "../../admin-report.model";
import { AttendanceReport } from "../attendanceReport.model";
import { TimeAttendanceReportService } from '../../../../service/vas/time/time-attendance-report.service';
import { LaborCostDaily } from "src/app/model/vas/labor-cost-daily.model";
import { MealShift } from "src/app/model/vas/meal-shifts.model";
import { MealTime } from "src/app/model/vas/meal-time.model";
import { LaborCostShift } from "src/app/model/vas/labor-cost-shift.model";

export class LaborCostByShiftReport extends AttendanceReport {
  public value: Map<string, Map<string, LaborCostShift>>;

  private timeAttendanceReportService: TimeAttendanceReportService

  constructor() {
    super();
    this.criteria = new Criteria();
  }

  public uri(): string {
    return super.uri() + '/byShift';
  }

  public load(data: AdminReport): this {
    Object.assign(this, data);

    this.value = data.value;

    return this;
  }

  public getMappedOutData(): Array<MealTime> {
    let mealTimes = new Array<MealTime>();

    for (let property in this.value) {
      let mTime = new MealTime();

      mTime.group = property;
      mTime.shifts = new Array<MealShift>();

      for (let s in this.value[property]) {

        let mealShift = new MealShift();
        let laborCostShift = new LaborCostShift().load(this.value[property][s]);

        mealShift.name = 'wages';
        mealShift.shiftName = laborCostShift.shift.toLowerCase();
        mealShift.value = laborCostShift.wages ? laborCostShift.wages : 0;

        mTime.shifts.push(mealShift);

        mealShift = new MealShift();
        mealShift.name = 'netSales';
        mealShift.shiftName = laborCostShift.shift.toLowerCase();
        mealShift.value = laborCostShift.total ? laborCostShift.total : 0;

        mTime.shifts.push(mealShift);

        mealShift = new MealShift();
        mealShift.name = 'laborCost';
        mealShift.shiftName = laborCostShift.shift.toLowerCase();
        mealShift.value = this.calculateLaborCost(laborCostShift);

        mTime.shifts.push(mealShift);

      }

      mealTimes.push(mTime);
    }

    return mealTimes;
  }

  public setTimeAttendanceService(timeAttendanceReportService?: TimeAttendanceReportService): void {
    this.timeAttendanceReportService = timeAttendanceReportService;
  }

  private calculateLaborCost(laborCostShift: LaborCostShift): number {
    let cost = 0;
    let wages = laborCostShift.wages ? laborCostShift.wages : 0;
    let net = laborCostShift.total;

    if (wages) {
      cost = ((net > 0 ? Math.round(wages/net * 10000) : 0));
    }

    return cost;
  }

}
