import { Criteria } from "../../criteria.model";
import { AdminReport } from "../../admin-report.model";
import { AttendanceReport } from "../attendanceReport.model";
import { AttendanceDetails } from "src/app/model/vas/attendance-details.model";
import { TimeAttendanceReportService } from '../../../../service/vas/time/time-attendance-report.service';
import { AttendanceTotals } from '../../../vas/attendance-totals.model';

export class AttendanceByRoleReport extends AttendanceReport {
  public value: Array<AttendanceDetails>;

  private timeAttendanceReportService: TimeAttendanceReportService

  constructor() {
    super();
    this.criteria = new Criteria();
  }

  public load(data: AdminReport): this {
    Object.assign(this, data);

    this.value = data.value;

    return this;
  }

  public setTimeAttendanceService(timeAttendanceReportService?: TimeAttendanceReportService): void {
    this.timeAttendanceReportService = timeAttendanceReportService;
  }

  public conciseData(): Array<AttendanceTotals> {
    let data = new Array<AttendanceTotals>();

    let mappedData = this.timeAttendanceReportService
                         .mapOutDataByJobTitle(this.value);
    let subTotals = this.timeAttendanceReportService
                          .calculateJobTitleSubTotals(mappedData);
    //TODO FILTER BY JOB TITLE
    for (let total of subTotals) {
      data.push(total[1]);
    }

    return data;
  }

}
