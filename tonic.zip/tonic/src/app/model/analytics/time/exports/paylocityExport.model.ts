import { AttendanceDetails } from "../../../vas/attendance-details.model";
import { AttendanceReport } from "../attendanceReport.model";

export class PaylocityExport extends AttendanceReport {

  public value: Array<AttendanceDetails>;

}
