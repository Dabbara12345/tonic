import { Ingredient } from "src/app/model/inventory/ingredient.model";

export class IngredientCount extends Ingredient  {

  public count: number;

  public load(data): this {
    Object.assign(this, data);

    return this;
  }

}
