import { HttpParams } from '@angular/common/http';

import { DiscountPercentage } from 'src/app/model/analytics/payment/discountPercentage.model';
import { AnalyticSelectionReport } from 'src/app/model/analytics/reportPaths/analyticSelectionReport';

export class ComplimentaryReport extends AnalyticSelectionReport {

  public value: Array<DiscountPercentage>;

  public params(): HttpParams {
    let params: HttpParams = new HttpParams();
    params = params.append('discountDetail', true);

    return params;
  }

}
