export class SelectionSummary {
  public name: string;
  public quantity: number;
  public amount: number;
  public complimentaryPercentage: number;
}
