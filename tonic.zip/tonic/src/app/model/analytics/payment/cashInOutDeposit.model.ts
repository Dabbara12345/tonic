import { Store } from 'src/app/model/store.model';

export class CashInOutDeposit {

  public id!: number;
  public batchNumber!: number;
  public cashSubTotal!: number;
  public cashGratuity!: number;
  public cashGratuityInCashDrawer!: number;
  public cashTip!: number;
  public cashTipInCashDrawer!: number;
  public nonCashSubTotal!: number;
  public nonCashGratuity!: number;
  public nonCashTip!: number;
  public nonCashDiscountAmount!: number;
  public creditSubTotal!: number;
  public creditSurcharge!: number;
  public creditGratuity!: number;
  public creditTip!: number;
  public creditDiscountAmount!: number;
  public extCreditSubTotal!: number;
  public extCreditSurcharge!: number;
  public extCreditGratuity!: number;
  public extCreditTip!: number;
  public extCreditDiscountAmount!: number;
  public debitSubTotal!: number;
  public debitGratuity!: number;
  public debitTip!: number;
  public debitDiscountAmount!: number;
  public extDebitSubTotal!: number;
  public extDebitGratuity!: number;
  public extDebitTip!: number;
  public extDebitDiscountAmount!: number;
  public couponSubTotal!: number;
  public couponGratuity!: number;
  public couponTip!: number;
  public checkSubTotal!: number;
  public checkGratuity!: number;
  public checkTip!: number;
  public giftSubTotal!: number;
  public giftGratuity!: number;
  public giftTip!: number;
  public extGiftSubTotal!: number;
  public extGiftGratuity!: number;
  public extGiftTip!: number;
  public roomChargeSubTotal!: number;
  public roomChargeGratuity!: number;
  public roomChargeTip!: number;
  public onlineCreditSubTotal!: number;
  public onlineCreditGratuity!: number;
  public onlineCreditTip!: number;
  public onlineCreditDiscountAmount!: number;
  public onlineCreditSurcharge!: number;
  public playCardSubTotal!: number;
  public playCardGratuity!: number;
  public playCardTip!: number;
  public nosherSubTotal!: number;
  public nosherGratuity!: number;
  public nosherTip!: number;
  public otherSubTotal!: number;
  public otherGratuity!: number;
  public otherTip!: number;
  public gratuityTaxAmount!: number;
  public deliveryCharges!: number;
  public billSubTotal!: number;
  public billGratuity!: number;
  public billTip!: number;
  public interimDepositTotal!: number;
  public pettyCashTotal!: number;
  public userCashOutTotal!: number;
  public overageShortage!: number;

  public currencyCode!: string;

  public created!: Date;
  public updated!: Date;

  public storeId!: Store;

  public load(data: any): this {

    Object.assign(this, data);

    if (data?.storeId) {
      this.storeId = new Store().load(data.storeId);
    }

    return this;
  }
}
