import { Terminal } from 'src/app/model/equipment/terminal.model';
import { BreakDown } from 'src/app/model/equipment/breakDown.model';
import { Safe } from 'src/app/model/equipment/safe.model';
import { User } from '../../access/user.model';

export class SafeActivity {

  public id: number;
  public total: number;
  public safeId: number;
  public userId: number;
  public terminalId: number;

  public currencyCode: string;
  public reset: boolean;
  public created: Date;
  public safe: Safe;
  public breakDown: BreakDown;
  public user?: User;
  public terminal?: Terminal;

  public load(data: any): SafeActivity {

    Object.assign(this, data);

    if (data?.breakDown) {
      this.breakDown = new BreakDown().load(data.breakDown);
    }

    if (data?.safe) {
      this.safe = new Safe().load(data.safe);
    }

    if (data?.user) {
      this.user = new User().load(data.user);
    }

    if (data?.terminal) {
      this.terminal = new Terminal().load(data.terminal);
    }

    return this;
  }

}
