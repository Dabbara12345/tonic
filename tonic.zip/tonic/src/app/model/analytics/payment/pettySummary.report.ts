import { HttpParams } from '@angular/common/http';
import { PettyReport } from '../reportPaths/pettyReport';
import { PettyCashSummary } from './pettyCashSummary.model';

export class PettySummaryReport extends PettyReport {

  public value: Array<PettyCashSummary>;

  params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('summary', true);

    return params;
  }

}
