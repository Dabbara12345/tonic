import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';
import { ReportCharity } from './reportCharity.model';

export class DonationsDetailsReport extends AnalyticSalesReport {

  public value: Array<ReportCharity>;

  public uri(): string {
    return super.uri() + '/donations';
  }
}
