import { Payment } from '../../activity/payment.model';
import { AnalyticPaymentReport } from '../reportPaths/analyticPaymentReport';

export class CreditCardBatchByPaymentTerminalReport extends AnalyticPaymentReport {

  public value: Array<Payment>;

  public uri(): string {
    return super.uri() + '/payment/creditcardbatch';
  }

}
