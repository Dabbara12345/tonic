import { HttpParams } from '@angular/common/http';
import { ServerHistory } from './serverHistory.model';
import { AnalyticBatchReport } from '../reportPaths/analyticBatchReport';

export class ServerDepositHistoryReport extends AnalyticBatchReport {

  public value: Array<ServerHistory>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('historyByServer', true);

    return params;
  }
}
