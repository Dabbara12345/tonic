import { SafeReport } from '../reportPaths/safeReport';
import { SafeActivity } from './safeActivity.model';

export class SafeSummaryReport extends SafeReport {

  public value: Array<SafeActivity>;

  public uri(): string {
    return super.uri() + '/safe';
  }
}
