import { CashInOutDeposit } from "./cashInOutDeposit.model";

export class DepositHistory {

  public opened: Date;
  public closed: Date;
  public deposit: CashInOutDeposit;

  public load(data: any): this {
    Object.assign(this, data);

    if (data.deposit){
      this.deposit = new CashInOutDeposit().load(data.deposit);
    }

    return this;
  }
}
