import { PettyReport } from '../reportPaths/pettyReport';
import { PettyCash } from './pettyCash.model';

export class PettyCashReport extends PettyReport {

  public value: Array<PettyCash>;

}
