import { Payment } from '../../activity/payment.model';
import { AnalyticPaymentReport } from '../reportPaths/analyticPaymentReport';

export class CreditCardGratuityAndTipReport extends AnalyticPaymentReport {

  public value: Array<Payment>;

  public uri(): string {
    return super.uri() + '/payment/creditcardgratuityandtip';
  }

}
