import { Criteria } from "./criteria.model";
import { ReportType } from "./report-type.model";
import { HttpParams } from "@angular/common/http";
import { DataComparison } from "./data-comparison";

export abstract class AdminReport implements ReportType {

  public name: string;
  public id?: string;
  public reportId: string;
  public category: string;
  public enterpriseId?: number;

  public value: any;
  public criteria: Criteria;
  public showUnits?: string;

  public emailRequested: boolean;

  public load(data: any): AdminReport {

      Object.assign(this, data);

      this.value = data?.value;

      this.criteria = new Criteria();

      if(data?.criteria){
          this.criteria.load(data.criteria);
      }

      return this;
  }

  public isSame(report: AdminReport): boolean {

    let is: boolean = false;

    if (report?.reportId === this.reportId &&
        this.criteria
            .isSame(report.criteria)){
      is = true;
    }

    return is;
  }

  public uri(): string {
      throw new Error('Methods needs to be implemented');
  }

  public params(): HttpParams {
    return new HttpParams();
  }

  public compare(previous: this): Array<DataComparison>{
      throw new Error('Methods needs to be implemented');
  }

  public key(): string {

    let hash: number = this.criteria.hash();
    const p: HttpParams = this.params();

    p?.keys()
      ?.forEach((k: string): void => {

        hash += this.hashCode(k);
      });

    return this.reportId + '-' + hash.toString();
  }

  public hashCode(s: string): number  {

    let hash: number = 0;
    let chr: number;

    for (let i: number = 0; i < s.length; i++) {

      chr = s.charCodeAt(i);
      hash = ((hash << 5) - hash) + chr;
      hash |= 0; // Convert to 32bit integer
    }

    return hash;
  }
}
