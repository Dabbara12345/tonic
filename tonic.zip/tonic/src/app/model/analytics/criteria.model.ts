export class Criteria {

  public storeId: number;

  public output: string;
  public delivery: string;
  public exceededStorage: boolean = false;

  public timeSearchOption?: string;
  public dateOptionSelected: string;
  public retrievedDate: Date;
  public fromDate?: Date;
  public toDate?: Date;

  public filters?: Map<string, string>;
  public filtersString?: string;
  public summary: string;

  public load(data: any): Criteria {

    Object.assign(this, data);

    if (data?.fromDate) {
      this.fromDate = new Date(data.fromDate);
    }

    if (data?.toDate) {
      this.toDate = new Date(data.toDate);
    }

    this.filters = new Map<string, string>();

    if (data?.filters && data?.filters.size > 0) {

      for (const d of data.filters) {

        this.filters
            .set(d[0], d[1]);
      }
    }

    return this;
  }

  public isSame(report: Criteria): boolean {

    let is: boolean = false;

    if (report?.storeId === this.storeId &&
        report?.fromDate === this.fromDate &&
        report?.toDate === this.toDate &&
        this.isSameFilters(report.filters)) {

      is = true;
    }

    return is;
  }

  public isSameFilters(filters?: Map<string, string>): boolean {

    let is: boolean = false;

    if (this.filters?.size === filters?.size) {

      is = true;

      this.filters
          ?.forEach((value, key): void => {

            if (value !== filters.get(key)) {
              is = false;
            }
          });
    }

    return is;
  }

  public hash(): number {

    let hash: number = 0;

    hash += this.hashCode(this.output);
    hash += this.hashCode(this.delivery);
    hash += this.hashCode(this.fromDate
                              ?.toString());
    hash += this.hashCode(this.toDate
                              ?.toString());

    return hash;
  }

  public hashCode(s: string): number  {

    var hash: number = 0;
    let chr: number;

    if(s) {

      for (let i: number = 0; i < s.length; i++) {

        chr = s.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
      }
    }

    return hash;
  }
}
