import { AnalyticAuthRequestReport } from "../reportPaths/analyticAuthRequestReport";
import { RemoteAuths } from "./remoteAuths.model";

export class RemoteAuthsReport extends AnalyticAuthRequestReport {

  public value: Array<RemoteAuths>;

}
