export class NoSales {

  public name: string;
  public forcedBy: string;
  public terminal: string;
  public cashDrawer: string;

  public date: Date;

  public load(data: any): NoSales {
    Object.assign(this, data);

    return this;
  }
}
