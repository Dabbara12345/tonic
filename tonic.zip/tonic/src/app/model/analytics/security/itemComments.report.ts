import { ItemsCommented } from "../items/itemCommented.model";
import { AnalyticSelectionReport } from "../reportPaths/analyticSelectionReport";

export class ItemCommentsReport extends AnalyticSelectionReport {

  public value: Array<ItemsCommented>;

  public uri(): string {
    return super.uri() + '/commented';
  }
}
