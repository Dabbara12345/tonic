import { Item } from '../../menu/item.model';

export class Availability {

  public available: Array<Item>;
  public unavailable: Array<Item>;

  public load(data: any): Availability {

    Object.assign(this, data);

    this.available = new Array<Item>();

    data?.available
        ?.forEach((a: Item): void => {

          this.available
              .push(new Item().load(a));
      });

    this.unavailable = new Array<Item>();

    data?.unavailable
        ?.forEach((u: Item): void => {

          this.unavailable
              .push(new Item().load(u));
      });

    return this;
  }
}
