export class RemoteAuths {

  public createdOn: Date;
  public decidedOn: Date;
  public appliedOn: Date;

  public creator: string;
  public note: string;
  public decision: string;
  public decider: string;
  public reason: string;
  public descriptionName: string;
  public selectionName: string;
  public permission: string;

  public infoOrderId: number;
  public descriptionOrderId: number;
  public quantity: number;

  public load(data: any): RemoteAuths {

    Object.assign(this, data);

    return this;
  }
}
