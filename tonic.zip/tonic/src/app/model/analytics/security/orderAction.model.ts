import { User } from '../../access/user.model';
import { Order } from '../../activity/order.model';
import { Terminal } from '../../equipment/terminal.model';

export class OrderAction {

  public id: number;
  public name: string;
  public description: string;
  public action: number;
  public order: Order;
  public created: string;
  public terminal: Terminal;
  public user: User;
  public forcedBy: User;
  public oldPrice: number;
  public newPrice: number;
  public priceChange: number;

  // Actions
  private static REMOVE_MAIN_SELECTION: number       = 1;
  private static REMOVE_SIDE_SELECTION: number       = 2;
  private static REMOVE_PREPARATION: number          = 3;
  private static REMOVE_ADDL_INGRED: number          = 4;
  private static REMOVE_COMBO_MAIN_SELECTION: number = 5;
  private static PRICE_CHANGE: number                = 6;
  private static RE_OPEN_ORDER: number               = 7;
  private static REMOVE_DELIVERY_CHARGE: number      = 8;
  private static MERGE_ORDER: number                 = 9;    // Destination order
  private static MERGE_INTO_ORDER: number            = 10;   // Source order
  private static ONLINE_ORDER_PRICE_CHANGE: number   = 11;
  private static KITCHEN_INSTRUCTIONS: number        = 12;
  private static KVD_ORDER_BROADCAST_MESSAGE: number = 13;
  private static REMOVE_PERCENTAGE_SELECTION: number = 14;
  private static PRINT_ORDER: number                 = 15;
  private static TRANSFER_ORDER: number              = 16;
  private static SPLIT_ORDER: number                 = 17;   // Destination order
  private static SPLIT_FROM_ORDER: number            = 18;   // Source order
  private static REMOVE_DONATION: number             = 19;
  private static REMOVE_OVERAGE_SELECTION: number    = 20;
  private static REMOVE_ROUNDING_SELECTION: number   = 21;
  private static REMOVE_SACOA_SELECTION: number      = 22;


  public load(data: any): OrderAction {
    Object.assign(this, data);

    return this;
  }

  public static getActionLabel(action: number): string {
    let label = "";

    switch (action) {
      case this.REMOVE_MAIN_SELECTION:
        label = "MAIN SELECTION REMOVED"
        break;

      case this.REMOVE_SIDE_SELECTION:
        label = "SIDE SELECTION REMOVED"
        break;

      case this.REMOVE_PREPARATION:
        label = "PREPARATION REMOVED"
        break;

      case this.REMOVE_ADDL_INGRED:
        label = "ADDL INGREDIENT REMOVED"
        break;

      case this.REMOVE_COMBO_MAIN_SELECTION:
        label = "COMBO MAIN SELECTION REMOVED"
        break;

      case this.PRICE_CHANGE:
        label = "PRICE CHANGE"
        break;

      case this.RE_OPEN_ORDER:
        label = "RE OPEN ORDER"
        break;

      case this.REMOVE_DELIVERY_CHARGE:
        label = "DELIVERY CHARGE REMOVED"
        break;

      case this.REMOVE_PERCENTAGE_SELECTION:
        label = "PERCENTAGE SELECTION REMOVED"
        break;

    }

    return label;
  }
}
