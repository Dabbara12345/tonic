export class PPA {

  public name: string;
  public mealTime: string;

  public seats: number;
  public netSales: number;

  public load(data: any): PPA {
    Object.assign(this, data);

    return this;
  }
}
