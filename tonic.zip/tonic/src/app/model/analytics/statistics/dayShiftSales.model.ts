import { ShiftSale } from "./shiftSale.model";

export class DayShiftSales {

  public date: Date;
  public shiftSales: Map<number, ShiftSale>;

  public load(data: any): DayShiftSales {
    Object.assign(this, data);

    return this;
  }
}
