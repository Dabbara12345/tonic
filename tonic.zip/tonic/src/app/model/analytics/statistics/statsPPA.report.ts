import { HttpParams } from '@angular/common/http';
import { PPA } from './ppa.model';
import { AnalyticSalesReport } from '../reportPaths/analyticSalesReport';

export class StatsPPAReport extends AnalyticSalesReport {

  public value: Array<PPA>;

  public params(): HttpParams {

    let params: HttpParams = new HttpParams();

    params = params.append('ppa', true);

    return params;
  }

}
