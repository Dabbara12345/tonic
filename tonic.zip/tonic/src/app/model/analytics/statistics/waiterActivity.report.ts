import { AnalyticOrderReport } from '../reportPaths/analyticOrderReport';
import { WaiterActivity } from './waiterActivity.model';

export class WaiterActivityReport extends AnalyticOrderReport {

  public value: Array<WaiterActivity>;

  public uri(): string {
    return super.uri() + '/waiterActivity';
  }
}
