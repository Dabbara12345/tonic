import { PromotionEnrolled } from 'src/app/model/customer/promotionEnrolled.model';
import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';

export class CustomerPromotionEnrollmentReport extends AnalyticCustomerReport {

  public value: Array<PromotionEnrolled>;

  public uri(): string {
    return super.uri() + 'promotionEnrolled';
  }

}
