import { StoreCustomer } from '../../customer/storeCustomer.model';
import { AnalyticReport } from '../reportPaths/analyticReport';

export class BirthdayReport extends AnalyticReport {

  public value: Array<StoreCustomer>;

  public uri(): string {
    return super.uri() + '/customer/birthday';
  }
}
