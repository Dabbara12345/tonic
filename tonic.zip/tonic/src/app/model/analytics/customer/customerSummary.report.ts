import { CustomerSummary } from 'src/app/model/customer/customer-summary.model';
import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';

export class CustomerSummaryReport extends AnalyticCustomerReport {

  public value: Array<CustomerSummary>;

  public uri(): string {
    return super.uri() + 'customerSummary';
  }

}
