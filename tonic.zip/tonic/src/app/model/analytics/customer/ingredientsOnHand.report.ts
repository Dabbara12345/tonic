import { IngredientsInfo } from '../inventory/ingredientsInfo.model';
import { AnalyticReport } from '../reportPaths/analyticReport';

export class IngredientsOnHandReport extends AnalyticReport {

  public value: Array<IngredientsInfo>;

  public uri(): string {
    return super.uri() + '/ingredientsInfo/ingredientsonhand';
  }

}
