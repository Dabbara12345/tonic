export class Allowance {

  public amount: number;
  public spent: number;
  public completed: Date;
  public created: Date;
  public update: Date;
  public customerId: number;
  public description: string;
  public nonRolloverAmount: number;
  public storeId: number;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
