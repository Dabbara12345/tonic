import { HttpParams } from '@angular/common/http';

import { AnalyticCustomerReport } from 'src/app/model/analytics/customer/analyticCustomer.report';
import { CustomerComplimentaryDetails } from 'src/app/model/customer/customerComplimentaryDetails.model';

export class CustomerOrderComplimentaryReport extends AnalyticCustomerReport {

  public value: Array<CustomerComplimentaryDetails>;

  public uri(): string {
    return super.uri() + 'customerComplimentaryDetails';
  }

  params(): HttpParams {
    let params: HttpParams = new HttpParams();

    params = params.append('detailed', true);

    return params;
  }

}
