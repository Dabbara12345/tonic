import { CategoriesInfo } from '../inventory/categoriesInfo.model';
import { AnalyticReport } from '../reportPaths/analyticReport';

export class OnHandReport extends AnalyticReport {

  public value: Array<CategoriesInfo>;

  public uri(): string {
    return super.uri() + '/categoriesInfo/onhand';
  }

}
