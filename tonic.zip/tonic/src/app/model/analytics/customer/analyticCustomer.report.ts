import { AdminReport } from "src/app/model/analytics/admin-report.model";

export class AnalyticCustomerReport extends AdminReport {

    public uri(): string {
        return 'analytic/customer/';
    }

}
