export class Quickbook {

  public id: number;
  public name: string;
  public fileFullpath: string;
  public customer: string;

  public load(data: any): Quickbook {
    Object.assign(this, data);

    return this;
  }

}
