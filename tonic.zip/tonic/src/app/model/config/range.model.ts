export class Range<T> {

  constructor(public start?: T,
              public end?: T) {}

  public load(data: any): Range<T> {
    Object.assign(this, data);

    if (data.start) {
      Object.assign(this.start, data.start);
    }

    if (data.end) {
      Object.assign(this.end, data.end);
    }

    return this;
  }
}
