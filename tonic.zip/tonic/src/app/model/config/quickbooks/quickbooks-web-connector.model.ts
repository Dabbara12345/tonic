import { QuickBooksApp } from "src/app/model/config/quickbooks/quickbooks-app.model";

export class QuickBooksWebConnector {

  public appname: string;
  public appid: QuickBooksApp;

  public load(data: any): QuickBooksWebConnector {
    Object.assign(this, data);

    if (data?.appid){
      this.appid = new QuickBooksApp().load(data.appid);
    }

    return this;
  }

}
