export class QuickBooksScheduler {

  public runeverynminutes: number;

  public load(data: any): QuickBooksScheduler {
    Object.assign(this, data);

    return this;
  }

}
