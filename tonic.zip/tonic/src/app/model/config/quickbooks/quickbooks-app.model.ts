import { QuickBooksScheduler } from "src/app/model/config/quickbooks/quickbooks-scheduler.model";

export class QuickBooksApp {

  public appurl: string;
  public appdescription: string;
  public appsupport: string;
  public username: string;
  public fileid: string;
  public qbtype: string;
  public scheduler: QuickBooksScheduler;

  public load(data: any): QuickBooksApp {
    Object.assign(this, data);

    if (data?.scheduler){
      this.scheduler = new QuickBooksScheduler().load(data.scheduler);
    }

    return this;
  }

}
