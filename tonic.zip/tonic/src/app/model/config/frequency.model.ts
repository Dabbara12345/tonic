export class Frequency {

    public type: string;
    public anchor!: string;
    public value: Array<string>;

    public load(data: any): Frequency {

      Object.assign(this, data);

      this.value = new Array<string>();

      data.value
          ?.forEach((v: string): void => {

            this.value.push(v);
          });

      return this;
    }

    public isMonthly(): boolean {

      let is: boolean = false;

      if (this.type === 'month'){
        is = true;
      }

      return is;
    }

    public isWeekly(): boolean {

      let is: boolean = false;

      if (this.type === 'week'){
        is = true;
      }

      return is;
    }

    public isAnnually(): boolean {

      let is: boolean = false;

      if (this.type === 'year'){
        is = true;
      }

      return is;
    }
}
