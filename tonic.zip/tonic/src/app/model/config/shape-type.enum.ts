export enum ShapeType {
  ELLIPSE = 1,
  RECTANGLE = 2
}
