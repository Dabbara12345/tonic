import { ShapeType } from './shape-type.enum';

export class Shape {

  public id!: number;
  public type!: ShapeType;
  public rgbFill!: string;
  public rgbStroke!: string;
  public width!: number;
  public height!: number;
  public angle!: number;
  public x: number = 0;
  public y: number = 0;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
