
export class PettyCashType {

  public description?: string;
  public creditDebit?: number;

  constructor(public name: string) {}

  public load(data: any): PettyCashType {
    Object.assign(this, data);

    return this;
  }
}
