export class DatawireInfo {

  public datawireId!: string;
  public merchantId!: string;
  public terminalId!: string;
  public serviceId!: string;
  public appId!: string;
  public urls!: Array<string>;

  public load(data: any): DatawireInfo {

      Object.assign(this, data);

      this.urls = new Array<string>();

      data.urls
          ?.forEach((d: string): void => {

            this.urls.push(d);
          });

      return this;
  }
}
