import { RuleType } from './ruleType.enum';

export class Rule {

  public id!: number;
  public name!: string;
  public type!: string;
  public created!: string;
  public charity?: number;
  public percentage?: number;
  public rounding?: number;
  public edit?: boolean;
  public freeTaxable?: boolean;
  public groupItems?: boolean;
  public matchItems?: boolean;
  public freeLimit?: number;
  public quantity?: number;
  public defaultItem?: number;

  public x?: number;
  public y?: number;

  public menus?: number[];
  public areas?: number[];
  public items?: number[];
  public taxes?: number[];
  public parents?: number[];
  public children?: number[];
  public salesGroups?: number[];
  public orderTypes?: number[];

  public load(data: any): Rule {

    Object.assign(this, data);

    this.areas = new Array<number>();

    if (data.areas) {

      data?.areas
          ?.forEach((a: number): void => {

            this.areas.push(a);
          });
    }

    this.items = new Array<number>();

    if (data.items) {

      data?.items
          ?.forEach((i: number): void => {

            this.items.push(i);
          });
    }

    this.taxes = new Array<number>();

    if (data.taxes) {

      data?.taxes
          ?.forEach((t: number): void => {

            this.taxes.push(t);
          });
    }

    this.parents = new Array<number>();

    if (data.parents) {

      data?.parents
          ?.forEach((p: number): void => {

            this.parents.push(p);
          });
    }

    this.children = new Array<number>();

    if (data.children) {

      data?.children
          ?.forEach((c: number): void => {

            this.children.push(c);
          });
    }

    this.salesGroups = new Array<number>();

    if (data.salesGroups) {

      data?.salesGroups
          ?.forEach((sG: number): void => {

            this.salesGroups.push(sG);
          });
    }

    this.orderTypes = new Array<number>();

    if (data.orderTypes) {

      data?.orderTypes
          ?.forEach((oT: number): void => {

            this.orderTypes.push(oT);
          });
    }

    return this;
  }

  public setType(type: RuleType): void {
    this.type = type;
  }

  public isDefaultItem(): boolean {
    return this.type === RuleType.DefaultItem;
  }

  public isSalesGroupDependency(): boolean {
    return this.type === RuleType.SalesGroupDependency;
  }

  public isTaxExempt(): boolean {
    return this.type === RuleType.TaxExempt;
  }

  public isDonation(): boolean {
    return this.type === RuleType.Donation;
  }

  public isNonCompable(): boolean {
    return this.type === RuleType.NonCompable;
  }

  public isNonDiscountable(): boolean {
    return this.type === RuleType.NonDiscountable;
  }

  public isDefaultItemPercentage(): boolean {
    return this.type === RuleType.DefaultItemPercent;
  }

  public isXForY(): boolean {
    return this.type === RuleType.XForY;
  }
}
