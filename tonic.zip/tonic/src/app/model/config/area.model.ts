import { Location } from './location.model';

export class Area{

  public id!: number;
  public name!: string;
  public seqNo: number;
  public description: string;
  public rgbBackgroundColor!: string;
  public locations: Array<Location>;

  public load(data: any): Area {

    Object.assign(this, data);

    this.locations = new Array<Location>();

    data?.locations
        ?.forEach((l: Location): void => {

          this.locations
              .push(new Location().load(l));
        });

    return this;
  }
}
