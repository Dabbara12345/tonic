export class Mealtime {

  public id!: number;
  public name!: string;
  public start!: number;
  public end!: number;

  public load(data: any): Mealtime {
    Object.assign(this, data);

    return this;
  }
}
