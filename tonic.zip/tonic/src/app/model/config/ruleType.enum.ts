export const enum RuleType {

    DefaultItem = 'com.ordyx.rule.CustomerOrderDefaultItem',
    DefaultItemPercent = 'com.ordyx.rule.PercentageDefaultItem',
    XForY = 'com.ordyx.rule.XForY',
    TaxExempt = 'com.ordyx.rule.CustomerOrderTaxExempt',
    Donation = 'com.ordyx.rule.Donation',
    SalesGroupDependency = 'com.ordyx.rule.CustomerOrderRecipeGroups',
    NonCompable = 'com.ordyx.rule.NonCompableRecipeGroups',
    NonDiscountable = 'com.ordyx.rule.NonDiscountableRecipeGroups',

}
