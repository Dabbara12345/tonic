import { Anchor } from './anchor.enum';
import { Frequency } from './frequency.enum';

export class Schedule {

  public id!: number;
  public seqNo!: number;

  public name: string;

  public startDate!: string;
  public startTime!: string;

  public endDate!: string;
  public endTime!: string;

  public frequency!: Frequency;
  public anchor!: Anchor;
  public value!: string;

  public created!: string;
  public updated!: string;

  public load(data: any): this {
    Object.assign(this,
                  data);

    return this;
  }
}
