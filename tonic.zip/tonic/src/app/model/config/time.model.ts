export class Time {
  private _hours!: number;
  private _minutes!: number;
  private _seconds: number = 0;
  private _percent!: number;

  constructor(hoursOrPercentOrString: any,
              minutes?: number) {

    if (minutes !== undefined) {

      this.set(hoursOrPercentOrString,
               minutes);

    } else if (typeof hoursOrPercentOrString === 'string') {

      const values: string[] = hoursOrPercentOrString.split(':');

      this.set(parseInt(values[0], 10),
               parseInt(values[1], 10));
    } else {
      this.percent = hoursOrPercentOrString;
    }
  }

  public set(hours: number,
             minutes: number,
             seconds = 0): void {

    this._hours = hours;
    this._minutes = minutes;
    this._seconds = seconds;
    this.percent = Math.min(100, Math.max(0, ((this.hours * 60 + this.minutes) / 1440) * 100));
  }

  public get hours(): number {
    return this._hours;
  }

  public get minutes(): number {
    return this._minutes;
  }

  public get seconds(): number {
    return this._seconds;
  }

  public set percent(percent: number) {

    const totalMinutes: number = Math.round((percent / 100) * 1440);

    this._hours = Math.floor(totalMinutes / 60);
    this._minutes = totalMinutes % 60;
    this._percent = percent;
  }

  public get percent(): number {
    return this._percent;
  }

  public isAM(): boolean {
    return ((Math.floor(this.hours / 12) % 2) === 0);
  }

  public isPM(): boolean {
    return !this.isAM();
  }

  public get12Hours(): number {

    const hour12: number = this.hours % 12;

    return (hour12 === 0) ? 12 : hour12;
  }

  public get24HourString(limit: boolean = true,
                         seconds = false): string {

    const hours: number = (limit) ? this.hours % 24 : this.hours;
    let value: string = hours.toString().padStart(2, '0') + ':' + this.minutes.toString().padStart(2, '0');

    if(seconds){
      value += ':' + this.minutes.toString().padStart(2, '0');
    }

    return value;
  }

  public get12HourString(seconds = false): string {

    let value: string = this.get12Hours() + ':' + this.minutes.toString().padStart(2, '0') + ' ' + (this.isAM() ? 'AM' : 'PM');

    if(seconds){
      value += ':' + this.minutes.toString().padStart(2, '0');
    }

    return value;
  }
}
