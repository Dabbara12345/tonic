
export class OrderType {

  public static readonly TYPE_TAKE_OUT = -1;
  public static readonly TYPE_DELIVERY = -2;
  public static readonly TYPE_DINE_IN = -3;
  public static readonly TYPE_BANQUET = -4;
  public static readonly TYPE_ROOM_SERVICE = -5;
  public static readonly TYPE_BEVERAGE_CART = -6;
  public static readonly TYPE_TOURNAMENT = -7;
  public static readonly TYPE_PETTY_CASH = -8;
  public static readonly TYPE_REFUND = -9;
  public static readonly TYPE_DRIVE_THRU = -10;
  public static readonly TYPE_CATERING = -11;
  public static readonly TYPE_PICK_UP = -12;
  public static readonly TYPE_RETAIL = -13;
  public static readonly TYPE_CURBSIDE = -14;

  public static readonly TYPE_ONLINE_TAKE_OUT = -100;
  public static readonly TYPE_ONLINE_DELIVERY = -101;
  public static readonly TYPE_ONLINE_BANQUET = -102;
  public static readonly TYPE_ONLINE_CATERING = -103;
  public static readonly TYPE_ONLINE_PICK_UP = -104;
  public static readonly TYPE_ONLINE_DINE_IN = -105;
  public static readonly TYPE_ONLINE_CURBSIDE = -106;

  public id: number;
  public abbreviation!: string;
  public label!: string;
  public type!: number;

  public load(data: any): OrderType {
    Object.assign(this, data);

    return this;
  }
}
