import { NumberFormat } from 'xlsx/types';
import { Shape } from './shape.model';
import { Area } from './area.model';

export class Location {
  public seqNo: number;
  public id: NumberFormat;
  public areas: Array<Area>;
  public name!: string;
  public shortName!: string;
  public rgbTextColor!: string;
  public seats!: number;
  public x!: number;
  public y!: number;
  public shape!: Shape;

  constructor() {
    this.id = -1;
    this.shape = new Shape();
  }

  public load(data: any): Location {

    Object.assign(this, data);

    if (data?.shape){
      this.shape = new Shape().load(data.shape);
    }

    return this;
  }
}
