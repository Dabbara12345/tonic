import { User } from '../access/user.model';
import { Recipient } from './recipient.model';

export class Message {

  public static RECIPIENT = -1;
  public static GENERAL = 0;

  public id: number;
  public type!: number;
  public description!: string;

  public userId!: number;
  public user!: User;
  public recipients?: Array<Recipient>;

  public valid!: Date;
  public expires!: Date;
  public created!: Date;

  public load(data: any): this {

    Object.assign(this, data);

    if (data?.user){
      this.user = new User().load(data.user);
    }

    if (data?.valid){
      this.valid = new Date(data.valid);
    }

    if (data?.expires){
      this.expires = new Date(data.expires);
    }

    if (data?.created){
      this.created = new Date(data.created);
    }

    this.recipients = new Array<Recipient>();

    if (data?.recipients){

      for (const r of data.recipients){

        this.recipients
            .push(new Recipient().load(r));
      }
    }

    return this;
  }

  public isRecipient(): boolean {
    return this.type === Message.RECIPIENT;
  }

  public isGeneral(): boolean {
    return this.type === Message.GENERAL;
  }
}
