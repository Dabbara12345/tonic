export class AcceptancePK {

  public storedId: number;
  public documentId: number;
  public userId: number;

  public load(data: any): AcceptancePK {
    Object.assign(this, data);

    return this;
  }
}
