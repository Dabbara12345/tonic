export class Suggestion {

  public id: number;
  public email: string;
  public details!: string;
  public created!: string;

  public load(data: any): Suggestion {

    Object.assign(this, data);

    return this;
  }
}
