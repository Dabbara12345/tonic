export class Broadcast {

  public id!: number;
  public type!: number;
  public name!: string;
  public description!: string ;
  public created!: string;

  public load(data: any): Broadcast {
    Object.assign(this, data);

    return this;
  }
}
