import { User } from '../access/user.model';
import { Agreement } from './agreement.model';
import { AcceptancePK } from './acceptance-pk.model';

export class Acceptance {

  public pk: AcceptancePK;

  public accepted: Date;
  public created: Date;
  public updated: Date;

  public agreement: Agreement;
  public user: User;

  public load(data: any): Acceptance {
    Object.assign(this, data);

    return this;
  }
}
