import { Store } from '../store.model';
import { User } from '../access/user.model';
import { Agreement } from '../communication/agreement.model';

export class AuthResponse {

    public user: User;
    public store: Store;
    public token: string;
    public timeout: number;
    public sessionId: string;
    public agreements: Array<Agreement>
}
