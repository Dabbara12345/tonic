import { Category } from '../map/category.model';
import { Permission } from './permission.model';
import { SubCategory } from '../map/subCategory.model';

export class FOH {

  public foh: Array<Category> = undefined;

  constructor() {
    this.foh = this.fohSection();
  }

  /**
   * Getter $foh
   * @return {Array<Category> }
   */
  public get $foh(): Array<Category>  {
    return this.foh;
  }

  private accessCategory(): Category {

    // LOGIN SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const loginSub: SubCategory = new SubCategory('Login', new Array<Permission>(
      new Permission('STORE_LOGIN', 'STORE_LOGIN')
    ));

    // ONE TOUCH SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const oneTouch: SubCategory = new SubCategory('1 Touch', new Array<Permission>(
      new Permission('ONE_TOUCH_LOGIN', 'ONE_TOUCH_LOGIN')
    ));

    // AUTO-LAYOUT SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const autoLayout: SubCategory = new SubCategory('Auto Layout', new Array<Permission>(
      new Permission('LOGIN_INIT_TABLE_LAYOUT', 'LOGIN_INIT_TABLE_LAYOUT')
    ));

    // AUTO-QS SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const autoQs: SubCategory = new SubCategory('Auto QS', new Array<Permission>(
      new Permission('LOGIN_AUTO_QS', 'LOGIN_AUTO_QS')
    ));

    // AUTO-QS SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const exit: SubCategory = new SubCategory('Exit', new Array<Permission>(
      new Permission('EXIT_APPLICATION', 'EXIT_APPLICATION')
    ));

    // ACCESS CATEGORY
    // Adding subCategory to Category
    const accessCat: Category = new Category('Access', new Array<SubCategory>(loginSub,
                                                                              oneTouch,
                                                                              autoLayout,
                                                                              autoQs,
                                                                              exit));
    return accessCat;
  }

  private orderCategory(): Category {

    // VIEW SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const view: SubCategory = new SubCategory('View', new Array<Permission>(
      new Permission('ALL_ORDERS', 'All'),
      new Permission('ALL_AREA_ORDERS', 'All area'),
      new Permission('ORDER_LIST_PAY_CASH', 'Pay cash from list'),
      new Permission('VIEW_HOSTESS_GUIDE', 'Hostess Guide')
    ));

    // ORDER SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const order: SubCategory = new SubCategory('Actions', new Array<Permission>(
      new Permission('NEW_ORDER', 'New'),
      new Permission('NEW_ORDER_FOR_OTHERS', 'New for others'),
      new Permission('CANCEL_ORDER', 'Cancel'),
      new Permission('CLEAR_ORDER', 'Clear'),
      new Permission('CLOSE_ORDER', 'Close'),
      new Permission('CLOSE_WITH_OVERAGE', 'Close with overage'),
      new Permission('RE_OPEN_ORDER', 'Reopen'),
      new Permission('PRINT_ORDER', 'Print'),
      new Permission('RE_PRINT_ORDER', 'Reprint'),
      new Permission('REFUND', 'Refund')
    ));

    // SELECTION SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const selection: SubCategory = new SubCategory('Selection', new Array<Permission>(
      new Permission('ADD_ORDERS', 'Add'),
      new Permission('DUPLICATE', 'Duplicate'),
      new Permission('MODIFY', 'Modify'),
      new Permission('COMMENTS', 'Comments'),
      new Permission('PREPARATIONS', 'Preparations'),
      new Permission('MODIFY_PRICING', 'Pricing'),
      new Permission('TAX_EXEMPTION', 'Tax Exempt'),
      new Permission('REMOVE_ITEM', 'Remove'),
    ));

    // QUICKSALE SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const quickSale: SubCategory = new SubCategory('Quicksale', new Array<Permission>(
      new Permission('QUICK_SALE', 'QUICK_SALE'),
      new Permission('QS_ADD_TO_ORDER', 'QS_ADD_TO_ORDER'),
    ));

    // TOOLS SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const tools: SubCategory = new SubCategory('Tools', new Array<Permission>(
      new Permission('RENAME_ORDER', 'Rename'),
      new Permission('MERGE', 'Merge'),
      new Permission('MOVE_ORDER', 'Move'),
      new Permission('SPLIT', 'Split'),
      new Permission('ADD_ITEM_TO_SPLIT_ORDER', 'Add item to split'),
      new Permission('TRANSFER_ORDER', 'Transfer'),
      new Permission('TRANSFER_ORDER_BY_ATTENDANCE', 'Transfer by attendance'),
      new Permission('OVERRIDE_NON_COMPABLE', 'Override non compable'),
      new Permission('OVERRIDE_NON_DISCOUNTABLE', 'Override non discountable'),
      new Permission('COMPLIMENTARY', 'Complimentary')
    ));

    const voids: SubCategory = new SubCategory('Void', new Array<Permission>(
      new Permission('VOID_DELIVERY_CHARGE', 'Delivery charge'),
      new Permission('VOID_DONATION_SELECTION', 'Donation'),
      new Permission('VOID_PERCENTAGE_SELECTION', 'Percentage'),
      new Permission('VOID_OVERAGE_SELECTION', 'Overage'),
      new Permission('VOID_ROUNDING_SELECTION', 'Rounding'),
    ));

    // ORDER CATEGORY
    // Adding SubCategory to Category

    return new Category('Order', new Array<SubCategory>(view,
                                                        order,
                                                        selection,
                                                        quickSale,
                                                        voids,
                                                        tools));
  }

  private paymentCategory(): Category {

    // PAY SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const pay: SubCategory = new SubCategory('Types', new Array<Permission>(
      new Permission('PAY', 'All'),
      new Permission('PAY_CASH', 'Cash'),
      new Permission('PAY_CHECK', 'Check'),
      new Permission('PAY_COUPON', 'Coupon'),
      new Permission('PAY_CREDIT', 'Credit'),
      new Permission('PAY_CREDIT_FORCE', 'Credit Force'),
      new Permission('PAY_CREDIT_MANUAL', 'Credit Manual'),
      new Permission('PAY_BILL', 'Bill'),
      new Permission('PAY_BILL_FORCE', 'Bill Force'),
      new Permission('PAY_BILL_WITHOUT_CARD', 'Bill without card'),
      new Permission('PAY_DEBIT', 'Debit'),
      new Permission('PAY_EXT_CREDIT', 'Ext Credit'),
      new Permission('PAY_EXT_DEBIT', 'Ext Debit'),
      new Permission('PAY_EXT_GIFT', 'Ext Gift'),
      new Permission('PAY_GIFT', 'Gift'),
      new Permission('PAY_ROOM_CHARGE', 'Room Charge'),
      new Permission('PAY_ONLINE_CREDIT', 'Online credit'),
      new Permission('PAY_OTHER', 'Other'),
      new Permission('PAY_OVERRIDE_BEFORE_TAX_ONLY', 'Override before tax only'),
      new Permission('EXCEED_TAB_FUNDS_THRESHOLD', 'EXCEED_TAB_FUNDS_THRESHOLD'),
      new Permission('INCREMENT_AUTH_ONLY', 'INCREMENT_AUTH_ONLY'),
    ));

    // VOID SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const Void: SubCategory = new SubCategory('Void', new Array<Permission>(
      new Permission('VOID', 'All'),
      new Permission('VOID_CASH', 'Cash'),
      new Permission('VOID_CREDIT', 'Credit'),
      new Permission('VOID_CREDIT_AUTH_ONLY', 'Credit auth'),
      new Permission('VOID_DEBIT', 'Debit'),
      new Permission('VOID_GIFT', 'Gift'),
      new Permission('VOID_EXT_DEBIT', 'Ext Debit'),
      new Permission('VOID_EXT_CREDIT', 'Ext Credit'),
      new Permission('VOID_EXT_GIFT', 'Ext gift'),
      new Permission('VOID_COUPON', 'Coupon'),
      new Permission('VOID_CHECK', 'Check'),
      new Permission('VOID_BILL', 'Bill'),
      new Permission('VOID_ROOM_CHARGE', 'Room charge'),
      new Permission('VOID_ONLINE_CREDIT', 'Online Credit'),
      new Permission('VOID_OTHER', 'Other'),
      new Permission('VOID_DEPOSIT', 'Deposit'),
      new Permission('VOID_DEPOSIT_NOT_ENOUGH_FUNDS_AVAILABLE', 'Deposit when not enough funds'),
      new Permission('VOID_GIFT_CARD', 'Gift Card'),
    ));

    // TIP SUBCATEGORY
    // ADDING PERMISSIONS TO CATEGORY
    const tip: SubCategory = new SubCategory('Tip', new Array<Permission>(
      new Permission('TIP_ADJUST', 'Adjust'),
      new Permission('REPORT_TIPS', 'Report'),
      new Permission('ORDER_TIP_ADJUST', 'Order Adjust'),
      new Permission('NEW_PAYMENT_TIP_ADJUST', 'Adjust new payment'),
      new Permission('CASH_OUT_TIP_POOL', 'CASH_OUT_TIP_POOL'),
      new Permission('CASH_OUT_TIP_POOL_NO_OPEN_ORDERS', 'CASH_OUT_TIP_POOL_NO_OPEN_ORDERS'),
      new Permission('ADD_TIP_POOL', 'ADD_TIP_POOL'),
      new Permission('EXCEED_TIP_OUT_PERCENTAGE', 'EXCEED_TIP_OUT_PERCENTAGE'),
      new Permission('OVERRIDE_TIP_PERCENTAGE_THRESHOLD', 'OVERRIDE_TIP_PERCENTAGE_THRESHOLD'),

    ));
    const payCat: Category = new Category('Payment', new Array<SubCategory>(pay,
                                                                            Void,
                                                                            tip));

    return payCat;
  }

  private compsCategory(): Category {

    const deliveryCharge: SubCategory = new SubCategory('Delivery Charge', new Array<Permission>(
      new Permission('COMP_DELIVERY_CHARGE', 'COMP_DELIVERY_CHARGE'),
    ));

    const deposit: SubCategory = new SubCategory('Deposit', new Array<Permission>(
      new Permission('COMP_DEPOSIT', 'COMP_DEPOSIT')
    ));

    const gift: SubCategory = new SubCategory('Gift', new Array<Permission>(
      new Permission('COMP_GIFT_CARD', 'COMP_GIFT_CARD')
    ));

    const exceed: SubCategory = new SubCategory('Exceed Max', new Array<Permission>(
      new Permission('EXCEED_USER_MAX_COMP', 'EXCEED_USER_MAX_COMP')
    ));

    const compsCat: Category = new Category('Comps', new Array<SubCategory>(deliveryCharge,
                                                                            deposit,
                                                                            gift,
                                                                            exceed ));

    return compsCat;
  }

  private cashDrawer(): Category {

    const assignment: SubCategory = new SubCategory('Assignment', new Array<Permission>(
      new Permission('ASSIGN_CASH_DRAWER', 'Assign'),
      new Permission('ASSIGN_OTHERS_CASH_DRAWER', 'Assign others'),
      new Permission('DEASSIGN_CASH_DRAWER', 'Deassign'),
      new Permission('DEASSIGN_OTHERS_CASH_DRAWER', 'Deassign others')
    ));

    const actions: SubCategory = new SubCategory('Actions', new Array<Permission>(
      new Permission('APPLY_PETTY_CASH', 'Petty cash'),
      new Permission('NO_SALE', 'No sale'),
      new Permission('NO_SALE_WHEN_ASSIGNED', 'No sale when assigned'),
      new Permission('MAKE_INTERIM_DEPOSIT', 'Interim deposit')
    ));

    const cashIn: SubCategory = new SubCategory('Cash In', new Array<Permission>(
      new Permission('CASH_IN_CASH_DRAWER', 'CASH_IN_CASH_DRAWER')
    ));

    const cashOut: SubCategory = new SubCategory('Cash Out', new Array<Permission>(
      new Permission('CASH_OUT_CASH_DRAWER', 'Cash out'),
      new Permission('CASH_OUT_CASH_DRAWER_VIEW', 'View'),
      new Permission('CASH_OUT_CASH_DRAWER_POSTPONE', 'Postpone'),
      new Permission('CASH_OUT_CASH_DRAWER_POSTPONED', 'Postponed'),
    ));

    return new Category('Cash Drawer', new Array<SubCategory>(cashIn,
                                                              assignment,
                                                              actions,
                                                              cashOut));
  }

  private userCashOut(): Category {

    const cashOut: SubCategory = new SubCategory('Cash Out', new Array<Permission>(
      new Permission('CASH_OUT_USER', 'CASH_OUT_USER'),
      new Permission('CASH_OUT_USER_VIEW', 'View'),
      new Permission('CASH_OUT_USER_NO_OPEN_ORDERS', 'CASH_OUT_USER_NO_OPEN_ORDERS'),
      new Permission('CASH_OUT_USER_VIEW_NO_OPEN_ORDERS', 'CASH_OUT_USER_VIEW_NO_OPEN_ORDERS'),
      new Permission('CASH_OUT_OTHERS', 'Others'),
    ));

    const tipPool: SubCategory = new SubCategory('Tip Pool', new Array<Permission>(
      new Permission('ADD_TIP_POOL', 'Add'),
      new Permission('CASH_OUT_TIP_POOL', 'Cash out'),
      new Permission('CASH_OUT_TIP_POOL_NO_OPEN_ORDERS', 'No open orders')
    ));

    const userCashOutCat: Category = new Category('User Cash Out', new Array<SubCategory>(cashOut,
                                                                                          tipPool));

    return userCashOutCat;
  }

  private communication(): Category {

    const snooze: SubCategory = new SubCategory('Snooze', new Array<Permission>(
      new Permission('SNOOZE_MESSAGE', 'SNOOZE_MESSAGE')
    ));

    const phoneBook: SubCategory = new SubCategory('Phonebook', new Array<Permission>(
      new Permission('VIEW_PHONEBOOK', 'VIEW_PHONEBOOK')
    ));

    const remoteAuth: SubCategory = new SubCategory('Remote Auth', new Array<Permission>(
      new Permission('HANDLE_AUTH_REQUEST', 'HANDLE_AUTH_REQUEST')
    ));

    const communicationCat: Category = new Category('Communication', new Array<SubCategory>(snooze,
                                                                                            phoneBook,
                                                                                            remoteAuth));

    return communicationCat;
  }

  private reports(): Category {

    const onAnyStartTime: SubCategory = new SubCategory('On Any Start Time', new Array<Permission>(
      new Permission('REPORT_ON_ANY_START_TIME', 'REPORT_ON_ANY_START_TIME')
    ));

    const payments: SubCategory = new SubCategory('Payments', new Array<Permission>(
      new Permission('PRINT_PAYMENTS_REPORT', 'PRINT_PAYMENTS_REPORT')
    ));

    const sales: SubCategory = new SubCategory('Sales', new Array<Permission>(
      new Permission('VIEW_REPORTS_SALES', 'View'),
      new Permission('PRINT_SALES_STATUS_REPORT', 'Print')
    ));

    const server: SubCategory = new SubCategory('Server', new Array<Permission>(
      new Permission('PRINT_SALES_BY_SERVER_REPORT', 'PRINT_SALES_BY_SERVER_REPORT'),
      new Permission('PRINT_SERVER_DETAIL_REPORT', 'PRINT_SERVER_DETAIL_REPORT')
    ));


    const reportsCat: Category = new Category('Reports', new Array<SubCategory>(onAnyStartTime,
                                                                                payments,
                                                                                sales));

    return reportsCat;
  }

  private admin(): Category {

    const store: SubCategory = new SubCategory('Close Store', new Array<Permission>(
      new Permission('CLOSE_STORE', 'CLOSE_STORE')
    ));

    const setup: SubCategory = new SubCategory('Setup', new Array<Permission>(
      new Permission('SETUP', 'SETUP'),
      new Permission('MODIFY_AVAILABILITY', 'MODIFY_AVAILABILITY'),
      new Permission('MODIFY_BAR_CODE', 'MODIFY_BAR_CODE'),
      new Permission('MODIFY_PRICING', 'MODIFY_PRICING')
    ));

    const terminal: SubCategory = new SubCategory('Terminals', new Array<Permission>(
      new Permission('ENABLE_DISABLE_TERMINAL', 'Enable/disable'),
      new Permission('SWITCH_DEMO_MODE', 'Demo mode')
    ));

    const safe: SubCategory = new SubCategory('Safe', new Array<Permission>(
      new Permission('SAFE_VIEW', 'View'),
      new Permission('SAFE_ACCESS', 'Access')
    ));

    const adminCat: Category = new Category('Admin', new Array<SubCategory>(store,
                                                                            setup,
                                                                            terminal,
                                                                            safe));

    return adminCat;
  }

  private clockIn(): Category {

    const view: SubCategory = new SubCategory('View', new Array<Permission>(
      new Permission('VIEW_ATTENDANCE', 'VIEW_ATTENDANCE')
    ));
    const ignoreSchedule: SubCategory = new SubCategory('Ignore Schedule', new Array<Permission>(
      new Permission('CLOCK_IN_IGNORE_SCHEDULE', 'CLOCK_IN_IGNORE_SCHEDULE')
    ));
    const force: SubCategory = new SubCategory('Force', new Array<Permission>(
      new Permission('FORCE_CLOCK_IN', 'FORCE_CLOCK_IN')
    ));

    const loginWithOutClockIn: SubCategory = new SubCategory('Login without clockin', new Array<Permission>(
      new Permission('ALLOW_LOGIN_WITHOUT_CLOCKIN', 'ALLOW_LOGIN_WITHOUT_CLOCKIN')
    ));

    const clockInCat: Category = new Category('Clock In', new Array<SubCategory>( view,
                                                                                  ignoreSchedule,
                                                                                  force,
                                                                                  loginWithOutClockIn));

    return clockInCat;
  }

  private customerAccounts(): Category {

    const customer: SubCategory = new SubCategory('Customer', new Array<Permission>(
      new Permission('CUSTOMER_SETUP', 'Setup'),
      new Permission('MODIFY_CUSTOMER', 'Modify'),
      new Permission('SET_CUSTOMER_TRACK_INFO', 'Track info')
    ));

    const loyalty: SubCategory = new SubCategory('Loyalty', new Array<Permission>(
      new Permission('REDEEM_LOYALTY_POINTS', 'REDEEM_LOYALTY_POINTS')
    ));

    const deposits: SubCategory = new SubCategory('Deposits', new Array<Permission>(
      new Permission('ADD_BALANCE_DEPOSITS', 'ADD_BALANCE_DEPOSITS'),
      new Permission('ADD_BALANCE_GIFT_CARD', 'ADD_BALANCE_GIFT_CARD'),
      new Permission('SET_BILLABLE', 'SET_BILLABLE'),
      new Permission('ACTIVATE_DEPOSIT_MANUAL', 'ACTIVATE_DEPOSIT_MANUAL')
    ));

    const driver: SubCategory = new SubCategory('Driver', new Array<Permission>(
      new Permission('DELIVERY_DRIVER', 'Driver'),
      new Permission('ASSIGN_DRIVER', 'Assign')
    ));

    const customerAccountsCat: Category = new Category('Customers', new Array<SubCategory>(customer,
                                                                                           loyalty,
                                                                                           deposits,
                                                                                           driver));

    return customerAccountsCat;
  }

  private fohSection(): Array<Category> {

    const fohArr: Array<Category> = new Array<Category>();

    fohArr.push(this.accessCategory());
    fohArr.push(this.admin());
    fohArr.push(this.orderCategory());
    fohArr.push(this.paymentCategory());
    fohArr.push(this.compsCategory());
    fohArr.push(this.cashDrawer());
    fohArr.push(this.userCashOut());
    fohArr.push(this.communication());
    fohArr.push(this.reports());
    fohArr.push(this.clockIn());
    fohArr.push(this.customerAccounts());

    return fohArr;
  }

}
