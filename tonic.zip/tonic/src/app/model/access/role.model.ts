import { Permission } from './permission.model';

export class Role {

  public id!: number;
  public name!: string;
  public description!: string;
  public groupName!: string;
  public jobTitle!: boolean;
  public waitStaff!: boolean;
  public tipCredit!: boolean;
  public tipWeight!: number;
  public hourlyWages!: number;
  public created!: Date;
  public updated!: Date;
  public permissions!: Array<Permission>;

  public load(data: any): Role {
    Object.assign(this, data);

    this.permissions = new Array<Permission>();

    if (data.permissions){
      for (const p of data.permissions){
        this.permissions
            .push(new Permission().load(p));
      }
    }

    return this;
  }

  public isFOH(): boolean {
    return this.has('STORE_LOGIN');
  }

  public isBOH(): boolean {
    return this.has('WEBSITE_LOGIN');
  }

  public find(permissionName: string): Permission {
    return this.permissions
               .filter(per => per.name === permissionName)[0];
  }

  public has(permissionName: string): boolean {
    return this.permissions
               .some(p => p.name === permissionName);
  }
}
