export class Permission {

  public id?: number;
  public name!: string;
  public description!: string;

  constructor(name?: string,
              description?: string) {
    this.name         = name        ? name        : undefined;
    this.description  = description ? description : undefined;
  }

  public load(data: any): Permission {
    Object.assign(this, data);

    return this;
  }
}
