import { Role } from './role.model';
import { Permission } from './permission.model';

export class Security {

  public id!: number;
  public storeId!: number;
  public roles!: Array<Role>;
  public permissions!: Array<Permission>;
  public name?: string;

  public load(data: any): this {
    Object.assign(this, data);

    this.roles = new Array<Role>();

    data?.roles
        ?.forEach((r: Role): void => {

      this.roles
          .push(new Role().load(r));
    });

    this.permissions = new Array<Permission>();

    data?.permissions
        ?.forEach((r: Permission): void => {

      this.permissions
          .push(new Permission().load(r));
    });

    return this;
  }
}
