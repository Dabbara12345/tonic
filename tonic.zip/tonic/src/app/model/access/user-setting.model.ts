import { User } from "./user.model";

export class UserSetting {

  public userId!:   number;

  public name:      string;
  public value:     string;

  public created?:  Date;

  public user?:     User;


  public load(data: any): this {

    Object.assign(this, data);

    if(data?.created) {
      this.created = new Date(data.created);
    }

    if(data?.user) {
      this.user = new User().load(data.user);
    }

    return this;
  }
}
