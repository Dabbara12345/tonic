import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LegalInfo {

  private nameVal: string;
  private companyVal: string;
  private yearVal: number;

  constructor() {

    this.nameVal = environment.name;
    this.companyVal = environment.company;
    this.yearVal = new Date().getFullYear();
  }

  public get name(): string {
    return this.nameVal;
  }

  public get year(): number {
    return this.yearVal;
  }

  public get company(): string {
    return this.companyVal;
  }
}
