import { CompareIgnore } from "src/app/model/enterprise/compare-ignore.enum";
import { CompareStatus } from "src/app/model/enterprise/compare-status.enum";

export class CompareRowInfo {

  private origBefore: string;
  private origAfter: string;
  private propertyName: string;

  private tabs: CompareRowInfo[] = new Array<CompareRowInfo>();
  private rows: CompareRowInfo[] = new Array<CompareRowInfo>();

  public status: CompareStatus;
  public parent: CompareRowInfo;

  public ignore: CompareIgnore = CompareIgnore.Synced;

  public diffStat: CompareStatus[] = new Array<CompareStatus>();

  public before: string;
  public after: string;

  public indents: number;
  public additions: number = 0;
  public deletions: number = 0;
  public expanded: boolean = false;

  public beforeObj: any;
  public afterObj: any;

  constructor(before: string,
              after: string,
              indents: number,
              status: CompareStatus,
              propertyName?: string) {

    switch (status) {

      case CompareStatus.Added:
        {
          this.after = after;
          break;
        }
      case CompareStatus.Removed:
        {
          this.before = before;
          break;
        }
      case CompareStatus.Changed:
        {
          this.before = before;
          this.after = after;
          break;
        }
      default:
        {
          this.before = before;
          this.after = after;

          break;
        }

    }

    this.origBefore = before;
    this.origAfter = after;
    this.status = status;
    this.indents = indents;
    this.propertyName = propertyName;

  }

  private updateDiffstat(): void {

    let changes: number = this.additions + this.deletions;
    let addNum: number;
    let delNum: number;

    this.diffStat = new Array();

    if (changes > 0) {

      if (changes <= 5) {

        addNum = this.additions;
        delNum = this.deletions;

      } else {

        let addNum5: number = this.additions * 5 / changes;
        let delNum5: number = this.deletions * 5 / changes;
        let addNum4: number = this.additions * 4 / changes;
        let delNum4: number = this.deletions * 4 / changes;
        let rounding5: number = Math.round(addNum5) - addNum5 + Math.round(delNum5) - delNum5;
        let rounding4: number = Math.round(addNum4) - addNum4 + Math.round(delNum4) - delNum4;

        if (rounding5 <= rounding4) {

          addNum = Math.round(addNum5);
          delNum = Math.round(delNum5);

        } else {

          addNum = Math.round(addNum4);
          delNum = Math.round(delNum4);

        }

      }

      for (let i: number = 0; i < addNum; i++) {

        this.diffStat
            .push(CompareStatus.Added);
      }

      for (let i: number = 0; i < delNum; i++) {

        this.diffStat
            .push(CompareStatus.Removed)
      }

      for (let i: number = this.diffStat.length; i < 5; i++) {

        this.diffStat
            .push(CompareStatus.None);
      }

    }

  }

  public getChildrenLength(): number {

    return this.tabs
               .length +
           this.rows
               .length;

  }

  public addTab(tab: CompareRowInfo): void {

    this.tabs
        .push(tab);

    tab.parent = this;

    if (this.ignore == CompareIgnore.Ignored) {

      tab.ignore = CompareIgnore.Ignored;
    }

  }

  public addRow(row: CompareRowInfo): void {

    this.rows
        .push(row);

    row.parent = this;

    if (this.ignore == CompareIgnore.Ignored) {

      row.ignore = CompareIgnore.Ignored;
    }

  }

  public popTab(): CompareRowInfo {

    let tab: CompareRowInfo = this.tabs
                                  .pop();

    if (tab) {
      tab.parent = undefined;
    }

    return tab;

  }

  public popRow(): CompareRowInfo {

    let row: CompareRowInfo = this.rows
                                  .pop();

    if (row) {
      row.parent = undefined;
    }

    return row;

  }

  private updateFromChildren(): void {

    let allIgnored: boolean = true;
    let allSynced: boolean = true;

    for (let i: number = 0;
         i < this.rows.length &&
         (allIgnored || allSynced);
         i++) {

      let row: CompareRowInfo = this.rows[i];

      if (allIgnored &&
          row.ignore == CompareIgnore.Synced) {

        allIgnored = false;

      } else if (allSynced &&
                 row.ignore == CompareIgnore.Ignored) {

        allSynced = false;

      }

    }

    for (let i: number = 0;
         i < this.tabs.length &&
         (allIgnored || allSynced);
         i++) {

      let tab: CompareRowInfo = this.tabs[i];

      if (tab.ignore == CompareIgnore.Indeterminate) {

        allIgnored = false;
        allSynced = false;

      } else if (allIgnored &&
                 tab.ignore == CompareIgnore.Synced) {

        allIgnored = false;

      } else if (allSynced &&
                 tab.ignore == CompareIgnore.Ignored) {

        allSynced = false;

      }

    }

    if (!allIgnored &&
        !allSynced) {

      this.ignore = CompareIgnore.Indeterminate;

    } else if (allSynced) {

      this.ignore = CompareIgnore.Synced;

    } else {

      this.ignore = CompareIgnore.Ignored;

    }

    if (this.parent) {

      this.parent
          .updateFromChildren();

    }

  }

  public toggle(): void {

    let newIgnore: CompareIgnore;

    if (this.ignore == CompareIgnore.Synced) {

      newIgnore = CompareIgnore.Ignored;

    } else {

      newIgnore = CompareIgnore.Synced;
    }

    this.setIgnore(newIgnore, true);

  }

  private setIgnore(ignore: CompareIgnore,
                    refreshParent: boolean): void {

    this.ignore = ignore;

    for (let row of this.rows) {

      row.setIgnore(ignore,
                    false);
    }

    for (let tab of this.tabs) {

      tab.setIgnore(ignore,
                    false);
    }

    if (refreshParent &&
        this.parent) {

      this.parent
          .updateFromChildren();
    }

  }

  public isIndeterminate(): boolean {
    return this.ignore == CompareIgnore.Indeterminate;
  }

  public isSynced(): boolean {
    return this.ignore == CompareIgnore.Synced;
  }

  public getMaxIndent(): number {

    let maxIndent: number = this.indents;

    for (let row of this.rows) {

      if (row.indents > maxIndent) {
        maxIndent = row.indents;
      }

    }

    for (let tab of this.tabs) {

      let maxTabIndent: number = tab.getMaxIndent();

      if (maxTabIndent > maxIndent) {
        maxIndent = maxTabIndent;
      }

    }

    return maxIndent;

  }

  public updateAdditionsAndDeletions(): void {

    this.additions = 0;
    this.deletions = 0;

    for (let t of this.tabs) {
      this.additions += t.additions;
      this.deletions += t.deletions;
    }

    for (let row of this.rows) {
      this.additions += row.additions;
      this.deletions += row.deletions;
    }

    this.updateDiffstat();

  }

  public addRowWithStatus(before: string,
                          after: string,
                          indents: number,
                          beforeObj: any,
                          afterObj: any,
                          status: CompareStatus,
                          propertyName?: string): CompareRowInfo {

    let rowInfo: CompareRowInfo = new CompareRowInfo(before,
                                                     after,
                                                     indents,
                                                     status,
                                                     propertyName);

    rowInfo.beforeObj = beforeObj;
    rowInfo.afterObj = afterObj;

    this.addRow(rowInfo);

    if (status == CompareStatus.Changed ||
        status == CompareStatus.Added) {

      rowInfo.additions++;
    }

    if (status == CompareStatus.Changed ||
        status == CompareStatus.Removed) {

      rowInfo.deletions++;
    }

    return rowInfo;

  }

  private getName(): string {

    return (this.origBefore) ?
           this.origBefore :
           this.origAfter;

  }

  public insertTabAlphabetically(tabInfo: CompareRowInfo): number {

    let left: number = 0;
    let right: number = this.tabs.length - 1;
    let name: string = tabInfo.getName();
    let index: number = -1;

    while (left <= right &&
           index == -1) {

      let middle: number = Math.round(left + (right - left) / 2);

      if ((middle == 0 ||
           name >= this.tabs[middle - 1].getName()) &&
          (middle > this.tabs.length - 1 ||
           name <= this.tabs[middle].getName())) {

        index = middle;

      } else if (name > this.tabs[middle].getName()) {

        left = middle + 1;

      } else {

        right = middle - 1;

      }

    }

    if (index != -1) {

      this.tabs
          .splice(index,
                  0,
                  tabInfo);

      tabInfo.parent = this;

    } else {

      this.addTab(tabInfo);

    }

    return -1;

  }

}
