export enum CompareIgnore {
  Synced,
  Ignored,
  Indeterminate
};
