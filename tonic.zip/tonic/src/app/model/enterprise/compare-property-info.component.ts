import { CompareComponent } from "src/app/route/apps/enterprise/compare/compare.component";

export class ComparePropertyInfo {

  public propertyInfos: Array<ComparePropertyInfo> = new Array();

  constructor(public name: string,
              public property: Array<string>,
              public mapping: any,
              public defaultOpen: any,
              public defaultString?: string,
              public callback?: (obj: any,
                                 isMaster: boolean,
                                 compare: CompareComponent) => string) { }

}
