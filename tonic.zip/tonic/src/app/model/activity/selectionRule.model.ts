import { Selection } from './selection.model';

export class SelectionRule {

  public created!: string;
  public selection!: Selection;
  public name!: string;

}
