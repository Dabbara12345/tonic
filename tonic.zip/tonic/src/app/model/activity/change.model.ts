import { Recipe } from '../menu/recipe.model';
import { Ingredient } from '../inventory/ingredient.model';

export class Change {

    public changeType!: number;
    public charge!: number;
    public quantity!: number;

    public recipe: Recipe;
    public ingredient: Ingredient;

    public created: string;

    public load(data: any): Change {

        Object.assign(this, data);

        if (data.recipe) {
            this.recipe = new Recipe().load(data.recipe);
        }

        if (data.ingredient) {
            this.ingredient = new Ingredient().load(data.ingredient);
        }

        return this;
    }
}
