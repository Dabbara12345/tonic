import { Store } from "../store.model";

export class IngredientCategory {

    public id!:           number;
    public storeId?:      number;
    public name!:         string;
    public description!:  string;

    public disabled?:     Date;
    public store?:        Store;

    public load(data: any): this {

      Object.assign(this, data);

      if(data?.disabled) {
        this.disabled = new Date(data.disabled);
      }

      if (data?.store) {
        this.store = new Store();

        data?.store
            ?.forEach((d: Store): void => {

        this.store
            .load(d);
        });
      }

      return this;
    }
  }
