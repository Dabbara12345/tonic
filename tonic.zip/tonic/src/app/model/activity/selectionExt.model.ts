export class SelectionExt {

  public selectionId!: number;
  public selectionGroupRemoteId!: string;
  public storeComplimentaryId!: number;
  public combineSides!: number;
  public hold!: string;

  public created!: string;
  public updated!: string;

  public load(data: any): this {
    Object.assign(this, data);

    return this;
  }
}
