export class UserAction {

  public id: number;
  public userName: string;
  public comment: string;
  public created: Date;

  public load(data: any): this {
    Object.assign(this, data);

    if(data?.created){
      this.created = new Date(data.created);
    }

    return this;
  }
}
