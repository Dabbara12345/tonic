import { User } from "../access/user.model";

export class AuthRequest {

  public id: number;
  public remoteId: string;

  public note: string;
  public status: number;

  public creator: User;
  public decisionMaker: User;
  public decisionReason: string;

  public decided: string;
  public applied: string;
  public created: string;
  public localCreated: Date;
  public updated: string;

  public load(data: any): AuthRequest {
    Object.assign(this, data);

    return this;
  }
}
