
export class SelectionChoice {

  public charge!: number;
  public chargeCash?: number;
  public chargeCredit?: number;
  public choiceId!: number;
  public name: string;
  public price: number;
  public paidCredit?: boolean;

  public load(data: any): this {

    Object.assign(this, data);

    return this;
  }
}
