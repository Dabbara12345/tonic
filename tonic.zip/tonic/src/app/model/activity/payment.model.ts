import { User } from '../access/user.model';
import { Order } from './order.model';
import { Drawer } from '../equipment/drawer.model';
import { Terminal } from '../equipment/terminal.model';
import { PaymentExt } from './paymentExt.model';
import { EMV } from '../equipment/emv.model';

export class Payment {
  public static CASH            : number = 1;
  public static CREDIT          : number = 2;
  public static DEBIT           : number = 3;
  public static GIFT            : number = 4;
  public static COUPON          : number = 5;
  public static CHECK           : number = 6;
  public static BILL            : number = 7;
  public static EXT_CREDIT      : number = 8;
  public static EXT_DEBIT       : number = 9;
  public static CREDIT_AUTH_ONLY: number = 10;
  public static EXT_GIFT        : number = 11;
  public static ROOM_CHARGE     : number = 12;
  public static OTHER           : number = 13;
  public static ONLINE_CREDIT   : number = 14;
  public static PLAY_CARD       : number = 15;
  public static NOSHER          : number = 16;

  public static PAYMENT_CARD_ENTRY_MODE_SWIPE                  : number = 0;
  public static PAYMENT_CARD_ENTRY_MODE_MANUAL                 : number = 1;
  public static PAYMENT_CARD_ENTRY_MODE_CHIP                   : number = 2;
  public static PAYMENT_CARD_ENTRY_MODE_TAP                    : number = 3;
  public static PAYMENT_CARD_ENTRY_MODE_CHIP_FALLBACK_TO_MANUAL: number = 4;
  public static PAYMENT_CARD_ENTRY_MODE_CHIP_FALLBACK_TO_SWIPE : number = 5;
  public static PAYMENT_CARD_ENTRY_MODE_CARD_NOT_PRESENT_MANUAL: number = 6;

  public id!: number;
  public remoteId!: string;
  public lastUpdated!: number;
  public name!: string;
  public type!: number;
  public cardType!: number;
  public manual!: number;

  public subTotal!: number;
  public gratuity!: number;
  public surcharge!: number;
  public surchargeAmount!: number;
  public tip!: number;
  public total!: number;
  public change!: number;

  public number!: string;
  public referenceNumber: string;
  public approval!: string;
  public emv!: EMV;

  public paymentExt!: PaymentExt;
  public terminal!: Terminal;
  public drawer: Drawer;
  public order: Order;

  public voidedBy?: User;
  public createdBy!: User;

  public created!: Date;
  public updated?: Date;
  public settled?: Date;

  public load(data: any): Payment {
    Object.assign(this, data);

    if (data.createdBy) {
      this.createdBy = new User().load(data.createdBy);
    }

    if (data.voidedBy) {
      this.voidedBy = new User().load(data.voidedBy);
    }

    if (data.drawer) {
      this.drawer = new Drawer().load(data.drawer);
    }

    if (data.terminal) {
      this.terminal = new Terminal().load(data.terminal);
    }

    if (data.order) {
      this.order = new Order().load(data.order);
    }

    if (data.emv) {
      this.emv = new EMV().load(data.emv);
    }

    return this;
  }

  public isCard(): boolean {

    let is: boolean = false;

    switch (this.type) {
      case Payment.CREDIT:
      case Payment.DEBIT:
      case Payment.GIFT:
      case Payment.ONLINE_CREDIT:
      case Payment.EXT_CREDIT:
      case Payment.EXT_DEBIT:
      case Payment.EXT_GIFT:
      case Payment.NOSHER:
        is = true;
        break;
    }

    return is;
  }

  public isCash(): boolean {
    return this.type === Payment.CASH;
  }

  public static getCardEntryModeLabel(cardEntryMode: number): string {

    let label: string = null;

    switch (cardEntryMode) {
      case Payment.PAYMENT_CARD_ENTRY_MODE_MANUAL:
        label = "Manual";
      break;
      case Payment.PAYMENT_CARD_ENTRY_MODE_SWIPE:
        label = "Swipe";
      break;
      case Payment.PAYMENT_CARD_ENTRY_MODE_CHIP:
        label = "Chip";
      break;
      case Payment.PAYMENT_CARD_ENTRY_MODE_TAP:
        label = "Tap";
      break;
      case Payment.PAYMENT_CARD_ENTRY_MODE_CHIP_FALLBACK_TO_MANUAL:
        label = "Chip Fallback to Manual";
      break;
      case Payment.PAYMENT_CARD_ENTRY_MODE_CHIP_FALLBACK_TO_SWIPE:
        label = "Chip Fallback to Swipe";
      break;
      case Payment.PAYMENT_CARD_ENTRY_MODE_CARD_NOT_PRESENT_MANUAL:
        label = "Card Not Present";
      break;
    }

    return label;
  }
}
