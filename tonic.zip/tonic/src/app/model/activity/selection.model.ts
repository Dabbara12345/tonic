import { Side } from './side.model';
import { SelectionBase } from './selectionBase.model';

export class Selection extends SelectionBase {
  public sides: Array<Side>;
  public comboSelections!: Array<Selection>;

  public load(data: any): this {

    super.load(data);

    this.sides = new Array<Side>();

    data?.sides
        ?.forEach((s: Side): void => {

          this.sides
              .push(new Side().load(s));
        });

    data?.comboSelections
        ?.forEach((cS: Selection): void  => {

          this.comboSelections
              .push(new Selection().load(cS));
    });

    return this;
  }
}
