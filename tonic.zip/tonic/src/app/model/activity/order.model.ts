
import { User } from '../access/user.model';
import { Area } from '../config/area.model';
import { Payment } from './payment.model';
import { Terminal } from '../equipment/terminal.model';
import { OrderTax } from './orderTax.model';
import { Selection } from './selection.model';
import { Customer } from 'src/app/model/customer/customer.model';

export class Order {

  public id!: number;
  public remoteId!: string;
  public version: string;
  public master: string;
  public batchNumber!: number;
  public name!: string;
  public description: string;
  public address: string;
  public phoneNumber: string;

  public areaLocationId: number;
  public customerId: number;
  public extOrderId: string;
  public serverId?: number;

  public type!: number;
  public seats: number;

  public totalAmount: number;
  public totalTax: number;
  public totalCompAmount: number;
  public totalDiscountAmount: number;
  public gratuityPercentage: number;
  public gratuityMinSeats: number;

  public created!: Date;
  public createdLocal!: string;
  public updated: string;
  public updatedLocal!: number;
  public printed: number;
  public closed: Date;
  public cleared: number;
  public requested: Date;

  public tipAndGratuityAfterTax: boolean;
  public tipAndGratuityBeforeCompAndDisc: boolean;
  public depositAmount: number;
  public depositCompAmount: number;
  public depositDiscountAmount: number;
  public giftCardAmount: number;
  public giftCardCompAmount: number;
  public giftCardDiscountAmount: number;
  public deliveryChargeAmount: number;
  public deliveryChargeCompAmount: number;
  public deliveryChargeDiscountAmount: number;
  public donationAmount: number;
  public donationCompAmount: number;
  public donationDiscountAmount: number;
  public totalAmountExlOtherIncome: number;

  public area: Area;
  public server: User;
  public driver: User;
  public customer: Customer;
  public terminal: Terminal;

  public taxes: Array<OrderTax> = new Array<OrderTax>();
  public payments: Array<Payment>;
  public selections: Array<Selection>;

  public load(data: any): Order {
    Object.assign(this, data);

    if(data?.requested){
      this.requested = new Date(data.requested);
    }

    if(data?.created){
      this.created = new Date(data.created);
    }

    if(data?.closed){
      this.closed = new Date(data.closed);
    }

    if (data?.server){
      this.server = new User().load(data.server);
    }

    if (data?.customer){
      this.customer = new Customer().load(data.customer);
    }

    if (data?.driver){
      this.driver = new User().load(data.driver);
    }

    if (data?.area){
      this.area = new Area().load(data.area);
    }

    if (data?.terminal){
      this.terminal = new Terminal().load(data.terminal);
    }

    this.taxes = new Array<OrderTax>();

    data?.taxes
        ?.forEach((t: OrderTax): void => {

        this.taxes.push(new OrderTax().load(t));
    });

    this.payments = new Array<Payment>();

    data?.payments
        ?.forEach((p: Payment): void => {

          this.payments
              .push(new Payment().load(p));
    });

    this.selections = new Array<Selection>();

    data?.selections
        ?.forEach((s: Selection): void => {

          const selection: Selection = new Selection().load(s);

          selection.taxes
                   ?.forEach(st => {

            const tax: OrderTax = this.taxes
                                      .find(element => element.id === st.id);

            st.name = tax?.name;
          });

          this.selections
              .push(selection);
          this.selections
              .sort((a, b): number => {

            const aDate: number = new Date(a.created).getTime();
            const bDate: number = new Date(b.created).getTime();

            if (aDate < bDate) {
              return -1;
            } else if (aDate > bDate) {
              return 1;
            } else {
              return 0;
            }
          });
        });

    return this;
  }
}
