import { User } from '../access/user.model';
import { Order } from './order.model';
import { Recipe } from '../menu/recipe.model';
import { Change } from './change.model';
import { ChangeTax } from './changeTax.model';
import { SalesGroup } from '../menu/salesGroup.model';
import { SelectionExt } from './selectionExt.model';
import { SelectionTax } from './selectionTax.model';
import { SelectionExt2 } from './selectionExt2.model';
import { SelectionRule } from './selectionRule.model';
import { SelectionChoice } from './selectionChoice.model';
import { SelectionChoiceTax } from './selectionChoiceTax.model';

export abstract class SelectionBase {

    public id!: number;
    public remoteId!: string;
    public refId!: number;
    public name!: string;
    public description!: string;
    public referencenumber!: string;
    public groupName: string;

    public menuId!: number;
    public type!: string;
    public storeComplimentaryId!: number;
    public selectionGroupRemoteId!: string;

    public sideCount!: number;
    public seat!: number;
    public course!: number;
    public quantity!: number;
    public multiplier!: number;
    public orderedById?: number;

    public price!: number;
    public additionPrice!: number;
    public totalAmount!: number;
    public discountAmount!: number;
    public complimentaryName!: string;
    public complimentaryPercentage!: number;
    public complimentaryAmount!: number;
    public complimentaryDescription!: string;

    public hold!: number;
    public disabled!: string;
    public created!: string;
    public createdLocal!: string;
    public updated!: string;
    public updatedLocal!: number;

    public recipe!: Recipe;
    public order!: Order;
    public group!: SalesGroup;

    public orderedBy!: User;
    public complimentaryBy!: User;
    public loyaltyBy!: User;

    public choices!: Array<SelectionChoice>;
    public choiceTaxes!: Array<SelectionChoiceTax>;

    public changes!: Array<Change>;
    public changeTaxes!: Array<ChangeTax>;

    public rules!: Array<SelectionRule>;
    public taxes!: Array<SelectionTax>;

    public selectionExt!: SelectionExt;
    public selectionExt2!: SelectionExt2;
    public defaultSides!: Array<Recipe>;

  public load(data: any): this {

    Object.assign(this, data);

    if (data.recipe) {
        this.recipe = new Recipe().load(data.recipe);
    }

    this.taxes = new Array<SelectionTax>();

    if (data.selectionExt) {
      this.selectionExt = new SelectionExt().load(data.selectionExt);
    }

    if (data.changes) {

      for (const d of data.changes) {
        this.changes
            .push(new Change().load(d));
      }
    }

    if (data.taxes) {

      for (const d of data.taxes) {
        this.taxes
            .push(new SelectionTax().load(d));
      }
    }

    return this;
  }
}
