export class TerminalLog {

  public id: string;
  public terminalId: number;
  public storeId: number;
  public size: number;
  public date: Date;
  public data: string;

  public load(data: any): this {

    Object.assign(this, data);

    return this;
  }

  public isPaxLog(): boolean {

    return this?.id &&
           this.id
               .includes("POSLog");
  }
}
