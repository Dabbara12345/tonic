export class Installment {

  public id!: number;
  public json: string;
  public method: string;
  public error: string;
  public manual: number;
  public created: Date;
  public updated: Date;
  public due: Date;
  public storeId!: number;
  public profile: boolean;
  public lastLogin: Date;

  public load(data: any): Installment {
    Object.assign(this, data);

    return this;
  }
}
