import { User } from 'src/app/model/access/user.model';
import { Payment } from 'src/app/model/activity/payment.model';
import { CashInOut } from 'src/app/model/activity/cashInOut.model';

export class CashActivity {

    public records: CashInOut[] = new Array<CashInOut>();
    public cashInDate: string;
    public cashOutDate: string;
    public cashInAmount: number = 0;
    public cashOutAmount: number = 0;
    public cashOutCount: number = 0;
    public calculatedCashOutAmount: number = 0;
    public user: User;

    public payments: Array<Payment> = new Array<Payment>();

    public load(data: CashInOut): CashActivity {

      if (!this.cashInDate ||
          (this.sibling(data) &&
           new Date(data.cashInDate) < new Date(this.cashInDate))) {

        this.cashInDate = data.cashInDate;
      }

      if (!this.cashOutDate ||
          (this.sibling &&
           new Date(data.cashOutDate) > new Date(this.cashOutDate))) {

        this.cashOutDate = data.cashOutDate;
        this.user = data.user;
      }

      if (data.cashInAmount > 0) {
        this.cashInAmount = data.cashInAmount;
      }

      if (data.cashOutAmount > 0) {
        this.cashOutAmount = data.cashOutAmount;
      }

      if (data.cashOutCount > 0) {
        this.cashOutCount = data.cashOutCount;
      }

      if (data.calculatedCashOutAmount > 0) {
        this.calculatedCashOutAmount = data.calculatedCashOutAmount;
      }

      this.payments = new Array<Payment>();

      data?.payments
          ?.forEach((p: Payment): void => {

            this.payments
                .push(new Payment().load(p));
          });

      this.records.push(data);

      return this;
    }

    public sibling(inOut: CashInOut): boolean {

      let sibling: boolean = false;

      if ((new Date(inOut.cashInDate) >= new Date(this.cashInDate) &&
           new Date(inOut.cashInDate) <= new Date(this.cashOutDate)) ||
          (new Date(this.cashInDate) >= new Date(inOut.cashInDate) &&
            new Date(this.cashInDate) <= new Date(inOut.cashOutDate))) {

        sibling = true;
      }

      return sibling;
    }

    public isDrawer(): boolean {

      let is: boolean = false;

      if (this.records.length > 0) {
        is = this.records[0].drawer !== undefined;
      }

      return is;
    }

    public get name(): string {

      let name: string = '';

      if (this.records?.length > 0 &&
          this.records[0].isDrawer()) {

        name = this.records[0].drawer.name;
      } else {
        name = 'Server';
      }

      return name;
    }

    public get users(): Array<User> {

      const users: User[] = new Array<User>();

      if (this.records?.length > 0) {

        for (const r of this.records) {
          users.push(r.user);
        }
      }

      return users;
    }
  }
