import { NameValue } from '../utils/nameValue.model';
import { Batch } from './batch.model';

export class Status {

    public batch: Batch;

    public totalSales?: number;
    public totalOrders?: number;
    public totalEmployees?: number;

    public longestShift?: number;
    public highestSales?: number;
    public lastYearSales?: number;

    public averageShift?: number;
    public averagePerson?: number;
    public averageOrder?: number;
    public averageSales?: number;

    public hourlySales?: Array<NameValue>;
    public hourlyAttendance?: Array<NameValue>;
    public groups?: Array<NameValue>;
}
