export class OrderTax {

  public id!: number;
  public name!: string;
  public description!: string;

  public type!: number;
  public percentage!: number;

  public roundingMethod!: number;
  public beforeLoyalty!: boolean;
  public taxGratuity!: boolean;

  public gratuityTaxAmount!: number;
  public totalAmount!: number;

  public created!: Date;
  public updated!: Date;

  public load(data: any): OrderTax {

    Object.assign(this, data);

    return this;
  }
}
