import { EMV } from '../equipment/emv.model';

export class PaymentExt {

  public paymentId!: number;
  public hostData!: string;
  public jsonData!: string;
  public mimeType!: string;
  public balance!: number;

  public emv?: EMV;

  public load(data: any): PaymentExt {
    Object.assign(this, data);

    return this;
  }
}
