import { User } from '../access/user.model';
import { Terminal } from '../equipment/terminal.model';
import { BatchForeignCurrency } from './batchForeignCurrency.model';

export class Batch {

  public id?: number;
  public batchNumber?: number;

  public opened?: Date;
  public closed?: Date;

  public cashInAmount?: number;
  public cashOutCount?: number;
  public cashOutAmount?: number;
  public actualCashOutAmount?: number;

  public grossSalesAmount?: number;
  public netSalesAmount?: number;

  public depositAmount?: number;
  public depositCompAmount?: number;
  public depositDiscountAmount?: number;

  public giftCardAmount?: number;
  public giftCardCompAmount?: number;
  public giftCardDiscountAmount?: number;
  public deliveryChargeAmount?: number;
  public deliveryChargeCompAmount?: number;
  public deliveryChargeDiscountAmount?: number;

  public donationAmount?: number;
  public donationCompAmount?: number;
  public donationDiscountAmount?: number;

  public creditCardDiscountRate?: number;
  public onlineCreditCardDiscountRate?: number;
  public debitCardDiscountRate?: number;

  public currencyCode?: string;
  public closingMessages?: string;

  public openedBy?: User;
  public openedFrom?: Terminal;
  public closedBy?: User;
  public closedFrom?: Terminal;

  public batchForeignCurrencies?: Array<BatchForeignCurrency>;

  public load(data: any): Batch {

    Object.assign(this,
                  data);

    if (this.opened) {
      this.opened = new Date(this.opened);
    }

    if (this.closed) {
      this.closed = new Date(this.closed);
    }

    if (data?.openedBy) {

      const user: User = new User();

      Object.assign(user, data.openedBy);
      this.openedBy = user;
    }

    if (data?.closedBy) {

      const user: User = new User();

      Object.assign(user, data.closedBy);
      this.closedBy = user;
    }

    if (data?.batchForeignCurrencies) {

      this.batchForeignCurrencies = new Array<BatchForeignCurrency>();

      for (const b of data.batchForeignCurrencies) {

        this.batchForeignCurrencies
            .push(new BatchForeignCurrency().load(b));
      }
    }

    return this;
  }
}
