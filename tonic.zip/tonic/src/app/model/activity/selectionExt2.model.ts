import { Selection } from "./selection.model";

export class SelectionExt2 {

  public selectionId!: number;
  public setCharge!: number;
  public setChargeCash?: number;
  public setChargeCredit?: number;
  public priceCash?: number;
  public priceCredit?: number;
  public additionPriceCash?: number;
  public additionPriceCredit?: number;
  public paidCredit?: boolean;
  public multiplier4!: number;
  public created!: string;
  public updated!: string;
  public selection!: Selection;
}
