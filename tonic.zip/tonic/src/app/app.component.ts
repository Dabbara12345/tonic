import { OnInit } from '@angular/core';
import { Component } from '@angular/core';

import { Chart } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';

import { LogService } from './service/activity/log.service';
import { PushService } from './service/notifications/push.service';
import { environment } from 'src/environments/environment';
import { SessionService } from './service/session.service';
import { StorageService } from './service/storage.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  constructor(protected sessionService: SessionService,
              private logService: LogService,
              private storageService: StorageService,
              private pushService: PushService) {}

  public ngOnInit(): void {

    this.logService
        .log('Admin Build: ' + environment.timeStamp);

    Chart.register(ChartDataLabels);
    const version = this.storageService
                        .getSetting('version');

    environment.version = version ? JSON.parse(version) : '1.0';

    this.pushService
        .register();
    this.sessionService
        .getSession();
  }
}
