import { NgModule } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CurrencyPipe } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule} from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { HttpClientModule } from '@angular/common/http';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { ClipboardModule } from '@angular/cdk/clipboard';
import { MatInputModule } from '@angular/material/input';
import { BrowserModule } from '@angular/platform-browser';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { provideFirebaseApp, getApp, initializeApp } from '@angular/fire/app';
import { getFirestore, provideFirestore } from '@angular/fire/firestore';

import { CustomFormsModule } from 'ng2-validation';
import { ColorPickerModule } from 'ngx-color-picker';

import { AppComponent } from 'src/app/app.component';
import { environment } from 'src/environments/environment';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { LoginComponent } from 'src/app/route/auth/login/login.component';
import { CanLoadRouteGuard } from 'src/app/service/access/can-Load-route-guard';
import { AuthenticationService } from 'src/app/service/access/authentication.service';
import { NavOptionsModule } from 'src/app/route/nav-bar/nav-options/nav-options.module';
import { LoginTimeoutComponent } from 'src/app/route/auth/timeout/login-timeout.component';
import { ErrorDialogService } from 'src/app/service/interceptors/extra/error-dialog.service';
import { RequestInterceptorService } from 'src/app/service/interceptors/request-interceptor.service';
import { ResponseInterceptorService } from 'src/app/service/interceptors/response-interceptor.service';
import { SevenShiftsAuthComponent } from 'src/app/route/apps/time/seven-shifts/seven-shifts-auth.component';

// import { CalendarModule, DateAdapter } from 'angular-calendar';
// import { adapterFactory } from 'angular-calendar/date-adapters/date-fns'
import { reducers } from './core/reducers/index';
import { AuthModule } from './modules/auth/auth.module';
import { AuthResolver } from './service/v3/auth.resolver';
import { StoreDetailsEffects } from './core/effects/store-details.effect';

@NgModule({
  imports: [
    FormsModule,
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    CustomFormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,

    // CalendarModule.forRoot({
    //   provide: DateAdapter,
    //   useFactory: adapterFactory,
    // }),

    MatIconModule,
    MatCardModule,
    MatSnackBarModule,
    MatInputModule,
    MatDialogModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatDividerModule,
    ClipboardModule,
    ColorPickerModule,

    provideFirebaseApp(() => initializeApp(environment.firebase)),
    provideFirestore(() => getFirestore()),

//    AngularFireModule.initializeApp(environment.firebase),
  //  AngularFireMessagingModule,
    NavOptionsModule,

    // disabling strict immutability, since it messes up existing v2 codebase (which is not immutable)
    StoreModule.forRoot(reducers, { runtimeChecks: { strictStateImmutability: false, strictActionImmutability: false } }),

    EffectsModule.forRoot([StoreDetailsEffects]),

    StoreRouterConnectingModule.forRoot(),

    StoreDevtoolsModule.instrument({
      name: 'Tonic Back Office Store DevTools',
      maxAge: 250,
      logOnly: environment.production
    }),
    AuthModule.forRoot()
    // VasModule
  ],
  declarations: [
    AppComponent,
    LoginComponent,
    LoginTimeoutComponent,
    SevenShiftsAuthComponent
  ],
  providers: [
    AuthenticationService,
    CanLoadRouteGuard,
    ErrorDialogService,
    { provide: HTTP_INTERCEPTORS,
      useClass: RequestInterceptorService,
      multi: true },
    { provide: HTTP_INTERCEPTORS,
        useClass: ResponseInterceptorService,
        multi: true },
    CurrencyPipe,
    DatePipe,
    AuthResolver
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
