import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { OnChanges } from '@angular/core';
import { SimpleChanges } from '@angular/core';

import { Category } from 'src/app/model/menu/category.model';
import { Recipe } from 'src/app/model/menu/recipe.model';
import { Section } from 'src/app/model/menu/section.model';

@Component({
  selector: 'app-menu-preview',
  templateUrl: './menu-preview.component.html',
  styleUrls: ['./menu-preview.component.scss']
})
export class MenuPreviewComponent implements OnChanges {

  @Input() public menus: Array<Category>;
  @Input() public recipes: Array<Recipe>;

  public menu: Category;
  public section: Section;

  constructor(){}

  public ngOnChanges(changes: SimpleChanges): void {
    if (changes.menus &&
        this.menus.length > 0) {
      this.menu = this.menus[0];

      if (this.menu.sections &&
          this.menu.sections.length > 0) {
        this.section = this.menu.sections[0];
      }
    }
  }
}
