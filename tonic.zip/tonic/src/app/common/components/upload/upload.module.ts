import { NgModule } from '@angular/core';

import { SharedModule } from 'src/app/common/shared.module';
import { UploadComponent } from 'src/app/common/components/upload/upload.component';
import { ItemTableModule } from 'src/app/common/components/item-table/item-table.module';
import { UsersTableModule } from 'src/app/route/access/users/users-table/users-table.module';
import { MenuPreviewComponent } from 'src/app/common/components/upload/menu-preview/menu-preview.component';
import { InventoryUploadComponent } from 'src/app/common/components/upload/inventory-upload/inventory-upload.component';
import { CustomersUploadComponent } from 'src/app/common/components/upload/customers-upload/customers-upload.component';
import { IngredientsPreviewComponent } from 'src/app/common/components/upload/inventory-preview/ingredients-preview.component';
import { CustomersPreviewComponent } from 'src/app/common/components/upload/customers-upload/customers-preview/customers-preview.component';

@NgModule({
  imports: [
    SharedModule,
    ItemTableModule,
    UsersTableModule
  ],
  declarations: [
    UploadComponent,
    MenuPreviewComponent,
    CustomersUploadComponent,
    InventoryUploadComponent,
    CustomersPreviewComponent,
    IngredientsPreviewComponent
  ],
})
export class UploadModule { }
