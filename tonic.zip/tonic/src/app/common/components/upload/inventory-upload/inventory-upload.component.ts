import { Inject } from '@angular/core';
import { OnInit } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Component } from '@angular/core';
import { ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatStepper } from '@angular/material/stepper';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { StepperSelectionEvent } from '@angular/cdk/stepper';

import * as XLSX from 'xlsx';
import Swal from 'sweetalert2';

import { FileService } from 'src/app/service/utils/file.service';
import { AlertService } from 'src/app/service/utils/alert.service';
import { Ingredient } from 'src/app/model/inventory/ingredient.model';
import { IngredientService } from 'src/app/service/vas/inventory/ingredient.service';
import { IngredientCategory } from 'src/app/model/activity/ingredientCategory.model';

@Component({
  selector: 'app-inventory-upload',
  templateUrl: './inventory-upload.component.html',
  styleUrls: ['./inventory-upload.component.scss']
})
export class InventoryUploadComponent implements OnInit, OnDestroy {

  @ViewChild(MatStepper) private stepper: MatStepper;
  @ViewChild(MatSort, { static: false })
  set sort(value: MatSort) {
    if (this.dataSource) {
      this.dataSource.sort = value;
    }
  }

  public dragValid:         boolean;
  public modalTitle:        string;
  public required:          Array<string>;
  private columns:          Array<string>;

  public file:              File;

  public maxJsonColWidth:   number                      = 0;

  public isUploading:       boolean                     = false;

  public jsonObjects:       Array<any>                  = new Array<any>();
  private jsonArray:        Array<any>                  = Array<any>();
  private jsonColumns:      Array<string>               = Array<string>();
  public displayedColumns:  Array<string>               = ['destination', 'arrow', 'source'];

  public columnMap:         Map<string, string>         = new Map<string, string>();
  private jsonColumnMap:    Map<string, string>         = new Map<string, string>();

  public dataSource:        MatTableDataSource<string>  = new MatTableDataSource();

  private weight:            string[]                    = ["kilo", "grams", "centigram",
                                                           "milligram", "microgram", "pound",
                                                           "ounce"];

  private volume:            string[]                    = ["liter", "centiliter", "milliliter",
                                                           "liquid gallon", "liquid quart", "liquid pint",
                                                           "liquid ounce", "cup", "table spoon",
                                                           "tea spoon", "dry gallon", "dry quart",
                                                           "dry pint", "full size keg", "quarter barrel deg",
                                                           "sixth barrel keg", "eighth barrel keg", "cornelius keg",
                                                           "mini keg", "standard european barrel keg",
                                                           "standard european half barrel keg"];

  private part:              string[]                    = ["single", "case of 9", "case of 12",
                                                           "case of 18", "case of 24", "case of 3",
                                                           "case of 4", "case of 6", "case of 100"];

  private weightAbbrevs:     { [key: string]: string }   = {"kg": "kilo",
                                                           "g": "grams",
                                                           "cg": "centigram",
                                                           "mg": "milligram",
                                                           "µg": "microgram",
                                                           "lb": "pound",
                                                           "oz": "ounce"
                                                          };

  private volumeAbbrevs: { [key: string]: string }      = {"l": "liter",
                                                           "cl": "centiliter",
                                                           "ml": "milliliter",
                                                           "gal": "liquid gallon",
                                                           "qt": "liquid quart",
                                                           "pt": "liquid pint",
                                                           "oz": "liquid ounce",
                                                           "cup": "cup",
                                                           "tbsp": "table spoon",
                                                           "tsp": "tea spoon",
                                                           "dry gal": "dry gallon",
                                                           "dry qt": "dry quart",
                                                           "dry pt": "dry pint",
                                                           "fsk": "full size keg",
                                                           "qb keg": "quarter barrel keg",
                                                           "sb keg": "sixth barrel keg",
                                                           "eb keg": "eighth barrel keg",
                                                           "c keg": "cornelius keg",
                                                           "mini keg": "mini keg",
                                                           "seb keg": "standard european barrel keg",
                                                           "sehb keg": "standard european half barrel keg"
                                                          };

  constructor(private fileService: FileService,
              private alertService: AlertService,
              private ingredientService: IngredientService,
              public dialogRef: MatDialogRef<InventoryUploadComponent>,
              @Inject(MAT_DIALOG_DATA) public data: Array<IngredientCategory>) {

    if (window.FileList && window.File) {
      document.addEventListener('dragover', this.dragOver);
      document.addEventListener('dragleave', this.dragLeave);
      document.addEventListener('drop', this.dragDrop);
    }

    this.modalTitle = 'UPLOAD INVENTORY';
    this.columns = ['Name',
                    'Online Ordering Name',
                    'Announcer',
                    'Description',
                    'Category',
                    'Measurement Type',
                    'Default Value',
                    'Default Unit',
                    'Par Level Value',
                    'Par Level Unit',
                    'Default Yield',
                    'UPC',
                    'Reconciled On',
                    'In Stock Value',
                    'In Stock Unit',
                    'Unit Price',
                    'Tracked',
                    'Monitored'];

    this.required = ['Name', 'Measurement Type'];

    this.dataSource.sortingDataAccessor = (item, property): string => {
      const column: string = item + '';

      if (property === 'destination') {
        return column;
      } else {
        return this.columnMap.get(column);
      }
    };

    this.dataSource.data = this.columns;
  }

  public ngOnInit(): void {
    this.dataSource.sort = this.sort;
  }

  public ngOnDestroy(): void {
    document.removeEventListener('dragover', this.dragOver);
    document.removeEventListener('dragleave', this.dragLeave);
    document.removeEventListener('drop', this.dragDrop);
  }

  public onStepChanged(event: StepperSelectionEvent): void {
    this.jsonObjects.length = 0;

    if (event.selectedIndex === 2) {
      this.jsonObjects.push(this.createInventory());
    }
  }

  public onUpload(): void {
    let prompt: string = `Are you sure you want to add the new inventory?`

    Swal.fire({title: prompt,
               text: `Keep in mind that this action cannot be undone or cancelled`,
               icon: 'warning',
               confirmButtonText: 'Yes',
               cancelButtonText: 'No',
               reverseButtons: true,
               showCloseButton: true,
               showCancelButton: true})
        .then((willdelete): void => {

      if (willdelete.isConfirmed) {
        this.doUpload();
      }
    });
  }

  private isTextType(type: string): boolean {
    return type.startsWith('text') ||
           type === 'application/json';
  }

  public isMappingComplete(): boolean {
    return this.columns.every(column => this.columnMap.has(column) ||
                                        !this.required.includes(column));
  }

  public getJsonColumns(column: string): Array<string> {
    return this.jsonColumns.filter(jsonColumn => {
      const col: string = this.jsonColumnMap.get(jsonColumn);

      return col == null ||
             col === column;
    });
  }

  public automap(): void {
    for (const column of this.columns) {
      const match: string = this.jsonColumns.find(jsonColumn => jsonColumn.toLowerCase() === column.toLowerCase());

      if (match) {
        this.set(column, match);
      }
    }
  }

  public clearAll(): void {
    this.columnMap.clear();
    this.jsonColumnMap.clear();
  }

  public columnMapChange(column: string, jsonColumn: string): void {
    const prevColumn: string = this.jsonColumnMap.get(jsonColumn);
    const prevJsonColumn: string = this.columnMap.get(column);

    if (prevColumn) {
      this.delete(prevColumn);
    }

    if (prevJsonColumn) {
      this.delete(column);
    }

    this.set(column, jsonColumn);
  }

  public setFile(file: File): void {

    this.jsonArray = null;
    this.jsonColumns = new Array();
    this.columnMap.clear();
    this.jsonColumnMap.clear();
    this.maxJsonColWidth = 0;

    if (file) {
      if (file.type &&
          (this.isTextType(file.type) ||
           file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {

        this.file = file;

        if (this.stepper.selectedIndex === 0) {
          this.stepper.selected.completed = true;
        }

        this.stepper.selectedIndex = 1;

        if (this.isTextType(file.type)) {
          file.text().then(text => {
            text.trim();

            if (file.type === 'text/csv' ||
                (file.type !== 'application/json' &&
                 !text.startsWith('{') && !text.startsWith('['))) {

              const obj: any[] = this.fileService.csvToJSON(text);

              if (obj) {
                this.jsonArray = obj;
              }
            }

            if (!this.jsonArray &&
                (file.type === 'application/json' ||
                 (file.type !== 'text/csv' &&
                  (text.startsWith('{') ||
                   text.startsWith('['))))) {

              const obj: any = JSON.parse(text);

              if (obj) {
                if (Array.isArray(obj)) {
                  this.jsonArray = obj;
                } else {
                  this.jsonArray = [obj];
                }
              }
            }

            this.parseJSON();
          });
        } else {
          file.arrayBuffer().then(arr => {
            const workbook: XLSX.WorkBook = XLSX.read(new Uint8Array(arr), {type: 'array'});

            if (workbook.SheetNames &&
                workbook.SheetNames.length > 0) {

              this.jsonArray = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);

              this.parseJSON();
            }
          });
        }
      } else {
        this.alertService.error('Invalid File Format, File must be of type .csv, .json, or .xlsx');
      }
    } else {
      this.file = file;
      this.stepper.steps.first.completed = false;
      this.stepper.selectedIndex = 0;
    }
  }

  private doUpload(): void {

    this.isUploading = true;

    this.ingredientService
        .saveMany(this.createInventory())
        .subscribe({
      next: (): void => {

        this.alertService
            .success('Upload started, you will receive an email when it is completed. You may also refresh this page to see the progress',
                      15000);
        this.dialogRef
            .close({reload: true});

        this.isUploading = false;
      },
      error: err => {
        this.isUploading = false;
        this.alertService
            .error(err);
      }
    });
  }

  private dragOver: (event: DragEvent) => void = (event: DragEvent): void => {
    event.stopPropagation();
    event.preventDefault();

    if (event.dataTransfer.items &&
        event.dataTransfer.items.length > 0) {
      const item: DataTransferItem = event.dataTransfer.items[0];

      if (item.kind === 'file' &&
          (this.isTextType(item.type) ||
           item.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {

        event.dataTransfer.dropEffect = 'copy';
        this.dragValid = true;
      } else {
        event.dataTransfer.dropEffect = 'none';
      }
    }
  }

  private dragLeave: (event: DragEvent) => void = (event: DragEvent): void => {
    if (event.screenX === 0 && event.screenY === 0) { // Outside window
      this.dragValid = false;
    }
  }

  private dragDrop: (event: DragEvent) => void = (event: DragEvent): void => {
    event.stopPropagation();
    event.preventDefault();

    const files: FileList = event.dataTransfer.files;

    this.setFile(files[0]);

    this.dragValid = false;
  }

  private parseJSON(): void {
    if (this.jsonArray) {
      for (const row of this.jsonArray) {
        const rowColumns: Array<string> = Object.keys(row);

        for (const column of rowColumns) {
          if (!this.jsonColumns.includes(column)) {
            this.jsonColumns.push(column);
            this.maxJsonColWidth = Math.max(this.maxJsonColWidth, column.length);
          }
        }
      }

      this.automap();
    }
  }

  private set(column: string, jsonColumn: string): void {
    if (jsonColumn) {
      this.columnMap.set(column, jsonColumn);
      this.jsonColumnMap.set(jsonColumn, column);
    } else {
      this.delete(column);
    }
  }

  private delete(column: string): void {
    const prev: string = this.columnMap.get(column);

    this.columnMap.delete(column);

    if (prev) {
      this.jsonColumnMap.delete(prev);
    }
  }

  private createInventory(): Array<Ingredient> {
    const ingredients: Ingredient[] = new Array<Ingredient>();

    for (let i: number = 0; i < this.jsonArray.length; i++) {

      const json: any = this.jsonArray[i];
      const name: string = String(json[this.columnMap.get('Name')]);
      const oloName: string  = String(json[this.columnMap.get('Online Ordering Name')]);
      const announcerName: string  = String(json[this.columnMap.get('Announcer')]);
      const description: string = String(json[this.columnMap.get('Description')]);
      const categoryName: string  = String(json[this.columnMap.get('Category')]);
      const measureTypeLabel: string = String(json[this.columnMap.get('Measurement Type')]);
      let measureValue: number = Number(json[this.columnMap.get('Default Value')]);
      measureValue = isNaN(measureValue) ? 0 : measureValue;
      const measureUnitLabel: string = String(json[this.columnMap.get('Default Unit')]);
      let parLevelValue: number = Number(json[this.columnMap.get('Par Level Value')]);
      parLevelValue = isNaN(parLevelValue) ? 0 : parLevelValue;
      const parLevelUnitLabel: string = String(json[this.columnMap.get('Par Level Unit')]);
      let defaultYield: number = Number(json[this.columnMap.get('Default Yield')]);
      defaultYield = isNaN(defaultYield) ? 0 : defaultYield;
      const upc: string = String(json[this.columnMap.get('UPC')]);
      let availableValue: number = Number(json[this.columnMap.get('In Stock Value')]);
      availableValue = isNaN(availableValue) ? 0 : availableValue;
      const availableUnitLabel: string = String(json[this.columnMap.get('In Stock Unit')]);
      let cost: number = Number(json[this.columnMap.get('Unit Price')]);
      cost = isNaN(cost) ? 0 : cost;
      const tracked: boolean = json[this.columnMap.get('Tracked')] === 'true';
      const monitored: boolean = json[this.columnMap.get('Monitored')] === 'true';
      let reconciledOn: Date = new Date(json[this.columnMap.get('Reconciled On')]);
      reconciledOn = isNaN(reconciledOn.getTime()) ? new Date() : reconciledOn;

      let ingredient: Ingredient = ingredients.find(ingredient => ingredient.name === name);

      if (!ingredient) {
        ingredient = new Ingredient();
        ingredient.name = name;
        ingredient.oloName = oloName;
        ingredient.announcerName = announcerName;
        ingredient.description = description;
        ingredient.measureValue = measureValue;
        ingredient.parLevelValue = parLevelValue;
        ingredient.yield = defaultYield;
        ingredient.upc = upc;
        ingredient.availableValue = availableValue;
        ingredient.cost = cost;
        ingredient.tracked = tracked;
        ingredient.monitored = monitored;

        ingredient.reconciled = new Date(reconciledOn);

        const index: number = this.data.findIndex(cat => cat.name === categoryName);

        if(index === -1){
          ingredient.category = new IngredientCategory().load({name: categoryName});
        } else {
          ingredient.categoryId = this.data[index].id;
          ingredient.category = new IngredientCategory().load(this.data[index]);
        }

        let measureType: number = this.getMeasureType(measureTypeLabel) !== -1 ?
                                  this.getMeasureType(measureTypeLabel) :
                                  this.getMeasureType(measureUnitLabel);

        if (measureType === -1) {
          let label: string = availableUnitLabel ?? parLevelUnitLabel;

          measureType = this.getMeasureType(label) !== -1 ?
                        this.getMeasureType(label) :
                        1;

        }

        ingredient.measureType = measureType;
        ingredient.measureUnit = this.getUnitIndex(ingredient.measureType, measureUnitLabel);
        ingredient.parLevelUnit = this.getUnitIndex(ingredient.measureType, parLevelUnitLabel);
        ingredient.availableUnit  = this.getUnitIndex(ingredient.measureType, availableUnitLabel);

        ingredients.push(ingredient);

      }

    }

    ingredients.sort((a, b): number => a.name.localeCompare(b.name));

    return ingredients;
  }

  private getMeasureType(label: string): number {

    const lowerLabel: string = label.toLowerCase();

    if (lowerLabel === 'weight' ||
        this.weight
            .includes(lowerLabel) ||
        Object.keys(this.weightAbbrevs)
              .includes(lowerLabel)) {

        return 1;

    } else if (lowerLabel === 'volume' ||
               this.volume
                   .includes(lowerLabel) ||
               Object.keys(this.volumeAbbrevs)
                     .includes(lowerLabel)) {

        return 2;

    } else if (lowerLabel === 'part' ||
               this.part
                   .includes(lowerLabel)) {

        return 4;

    } else {

        return -1;

    }

  }

  private getUnitIndex(measureType: number, unitLabel: string): number {
    const lowerLabel: string = unitLabel.toLowerCase();
    let measureTypeArray: string[];
    let abbreviations: { [key: string]: string };

    switch (measureType) {
      case 1:
        measureTypeArray = this.weight;
        abbreviations = this.weightAbbrevs;
        break;
      case 2:
        measureTypeArray = this.volume;
        abbreviations = this.volumeAbbrevs;
        break;
      case 4:
        measureTypeArray = this.part;
        break;
      default:
        return -1;
    }

    const index: number = measureTypeArray.map(u => u.toLowerCase()).indexOf(lowerLabel);
    if (index !== -1) {
      return index;
    }

    if (measureType !== 4) {
      const abbreviationKeys: string[] = Object.keys(abbreviations);
      const matchingKey: string = abbreviationKeys.find(key => key.toLowerCase() === lowerLabel);

      if (matchingKey) {
        return measureTypeArray.map(u => u.toLowerCase()).indexOf(abbreviations[matchingKey].toLowerCase());
      }
    }
    return -1;
  }

}
