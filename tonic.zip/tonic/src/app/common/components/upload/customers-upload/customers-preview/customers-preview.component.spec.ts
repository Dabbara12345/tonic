import { TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture } from '@angular/core/testing';

import { CustomersPreviewComponent } from 'src/app/common/components/upload/customers-upload/customers-preview/customers-preview.component';

describe('CustomersPreviewComponent', () => {
  let component: CustomersPreviewComponent;
  let fixture: ComponentFixture<CustomersPreviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomersPreviewComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],

      imports: [],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomersPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('method1', () => {
    it('should ...', () => {
      expect(component).toBeTruthy();
    });
  });
});
