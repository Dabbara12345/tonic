import { Inject } from '@angular/core';
import { OnInit } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { OnDestroy } from '@angular/core';
import { Component } from '@angular/core';
import { ViewChild } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { StepperSelectionEvent } from '@angular/cdk/stepper';

import * as XLSX from 'xlsx';
import Swal from 'sweetalert2';

import { Customer } from 'src/app/model/customer/customer.model';
import { FileService } from 'src/app/service/utils/file.service';
import { AlertService } from 'src/app/service/utils/alert.service';
import { CustomerService } from 'src/app/service/customer/customer.service';

@Component({
  selector: 'app-customers-upload',
  templateUrl: './customers-upload.component.html',
  styleUrls: ['./customers-upload.component.scss']
})
export class CustomersUploadComponent implements OnInit, OnDestroy {

  @ViewChild(MatStepper) private stepper: MatStepper;
  @ViewChild(MatSort, { static: false })
  set sort(value: MatSort) {
    if (this.dataSource) {
      this.dataSource.sort = value;
    }
  }

  private columns: Array<string>;
  private jsonArray: Array<any> = Array<any>();
  private jsonColumns: Array<string> = Array<string>();
  private jsonColumnMap: Map<string, string> = new Map<string, string>();

  public file: File;
  public dragValid: boolean;
  public modalTitle: string;
  public required: Array<string>;

  public maxJsonColWidth: number = 0;
  public isUploading: boolean = false;

  public jsonObjects: Array<any> = new Array<any>();
  public displayedColumns: Array<string> = ['destination', 'arrow', 'source'];
  public columnMap: Map<string, string> = new Map<string, string>();
  public dataSource: MatTableDataSource<string> = new MatTableDataSource();

  constructor(private fileService: FileService,
              private alertService: AlertService,
              private customerService: CustomerService,
              public dialogRef: MatDialogRef<CustomersUploadComponent>,
              @Inject(MAT_DIALOG_DATA) public data: Array<Customer>) {

    if (window.FileList &&
        window.File) {

      document.addEventListener('dragover',
                                this.dragOver);
      document.addEventListener('dragleave',
                                this.dragLeave);
      document.addEventListener('drop',
                                this.dragDrop);

    }

    this.modalTitle = 'UPLOAD CUSTOMERS';
    this.columns = [
      'Name',
      'First Name',
      'Last Name',
      'Description',
      'Date of Birth',
      'Card Number',
      'Phone',
      'Fax Number',
      'Mobile Number',
      'Email',
      'Address',
      'City',
      'State',
      'Zip',
      'Available balance',
      'Loyalty Points',
      'Date Created',
      'Order Count',
      'Date Last Order',
      'Track 1',
      'Track 2',
      'Track 3',
      /*
      'Total Spent Lifetime',
      'Allowance***',
      'Rollover From Previous Period***',
      'Non Rollover Amount***',
      'Amount Spent Current Period***',
      'Total Deposited***',
      'Transfers***',
      'Wineemotion Owner ID'
      */
    ];

    this.required = ['Name'];

    this.dataSource
        .sortingDataAccessor = (item, property): string => {

          const column: string = item + '';

          if (property === 'destination') {

            return column;

          } else {

            return this.columnMap
                       .get(column);

          }

        };

    this.dataSource
        .data = this.columns;
  }

  public ngOnInit(): void {
    this.dataSource
        .sort = this.sort;
  }

  public ngOnDestroy(): void {

    document.removeEventListener('dragover',
                                 this.dragOver);
    document.removeEventListener('dragleave',
                                 this.dragLeave);
    document.removeEventListener('drop',
                                 this.dragDrop);
  }

  public onStepChanged(event: StepperSelectionEvent): void {

    this.jsonObjects
        .length = 0;

    if (event.selectedIndex === 2) {

      this.jsonObjects
          .push(this.createCustomers());

    }

  }

  public onUpload(): void {

    let prompt: string = `Are you sure you want to add the new customers?`

    Swal.fire({title: prompt,
               text: `Keep in mind that this action cannot be undone or cancelled`,
               icon: 'warning',
               confirmButtonText: 'Yes',
               cancelButtonText: 'No',
               reverseButtons: true,
               showCloseButton: true,
               showCancelButton: true})
        .then((willdelete): void => {

          if (willdelete.isConfirmed) {
            this.doUpload();
          }
        });
  }

  private isTextType(type: string): boolean {

    return type.startsWith('text') ||
           type === 'application/json';
  }

  public isMappingComplete(): boolean {

    return this.columns
               .every(column => this.columnMap
                                    .has(column) ||
                                !this.required
                                     .includes(column));
  }

  public getJsonColumns(column: string): Array<string> {

    return this.jsonColumns
               .filter(jsonColumn => {

                const col: string = this.jsonColumnMap
                                        .get(jsonColumn);

                return col == null ||
                       col === column;

               });
  }

  public automap(): void {

    for (const column of this.columns) {

      const match: string = this.jsonColumns
                                .find(jsonColumn => jsonColumn.toLowerCase() === column.toLowerCase());

      if (match) {
        this.set(column,
                 match);
      }
    }
  }

  public clearAll(): void {

    this.columnMap
        .clear();
    this.jsonColumnMap
        .clear();
  }

  public columnMapChange(column: string,
                         jsonColumn: string): void {

    const prevColumn: string = this.jsonColumnMap
                                   .get(jsonColumn);
    const prevJsonColumn: string = this.columnMap
                                       .get(column);

    if (prevColumn) {
      this.delete(prevColumn);
    }

    if (prevJsonColumn) {
      this.delete(column);
    }

    this.set(column,
             jsonColumn);
  }

  public setFile(file: File): void {

    this.jsonArray = null;
    this.jsonColumns = new Array();

    this.columnMap
        .clear();
    this.jsonColumnMap
        .clear();

    this.maxJsonColWidth = 0;

    if (file) {

      if (file.type &&
          (this.isTextType(file.type) ||
           file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {

        this.file = file;

        if (this.stepper
                .selectedIndex === 0) {

          this.stepper
              .selected
              .completed = true;
        }

        this.stepper.selectedIndex = 1;

        if (this.isTextType(file.type)) {

          file.text()
              .then(text => {

                text.trim();

                if (file.type === 'text/csv' ||
                    (file.type !== 'application/json' &&
                     !text.startsWith('{') &&
                     !text.startsWith('['))) {

                  const obj: any[] = this.fileService
                                         .csvToJSON(text);

                  if (obj) {
                    this.jsonArray = obj;
                  }
                }

                if (!this.jsonArray &&
                    (file.type === 'application/json' ||
                     (file.type !== 'text/csv' &&
                      (text.startsWith('{') ||
                       text.startsWith('['))))) {

                  const obj: any = JSON.parse(text);

                  if (obj) {

                    if (Array.isArray(obj)) {
                      this.jsonArray = obj;
                    } else {
                      this.jsonArray = [obj];
                    }
                  }
                }

                this.parseJSON();
              });

        } else {

          file.arrayBuffer()
              .then(arr => {

                const workbook: XLSX.WorkBook = XLSX.read(new Uint8Array(arr),
                                                          {type: 'array'});

                if (workbook.SheetNames &&
                    workbook.SheetNames
                            .length > 0) {

                  this.jsonArray = XLSX.utils
                                       .sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);

                  this.parseJSON();
                }
              });
        }
      } else {
        this.alertService
            .error('Invalid File Format, File must be of type .csv, .json, or .xlsx');
      }

    } else {

      this.file = file;
      this.stepper
          .steps
          .first
          .completed = false;
      this.stepper
          .selectedIndex = 0;
    }

  }

  private doUpload(): void {

    this.isUploading = true;

    this.customerService
        .importBulk(this.createCustomers())
        .subscribe({

          next: (): void => {

            this.alertService
                .success('Upload started, you will receive an email when it is completed. You may also refresh this page to see the progress',
                         15000);
            this.dialogRef
                .close({reload: false});

            this.isUploading = false;
          }, error: err => {

            this.isUploading = false;
            this.alertService
                .error(err);
          }
        });
  }

  private dragOver: (event: DragEvent) => void = (event: DragEvent): void => {

    event.stopPropagation();
    event.preventDefault();

    if (event.dataTransfer
             .items &&
        event.dataTransfer
             .items
             .length > 0) {

      const item: DataTransferItem = event.dataTransfer
                                          .items[0];

      if (item.kind === 'file' &&
          (this.isTextType(item.type) ||
           item.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {

        event.dataTransfer
             .dropEffect = 'copy';
        this.dragValid = true;
      } else {

        event.dataTransfer
             .dropEffect = 'none';
      }
    }
  }

  private dragLeave: (event: DragEvent) => void = (event: DragEvent): void => {

    if (event.screenX === 0 &&
        event.screenY === 0) {

      this.dragValid = false;
    }
  }

  private dragDrop: (event: DragEvent) => void = (event: DragEvent): void => {

    event.stopPropagation();
    event.preventDefault();

    const files: FileList = event.dataTransfer
                                 .files;

    this.setFile(files[0]);

    this.dragValid = false;
  }

  private parseJSON(): void {

    if (this.jsonArray) {

      for (const row of this.jsonArray) {

        const rowColumns: Array<string> = Object.keys(row);

        for (const column of rowColumns) {

          if (!this.jsonColumns
                   .includes(column)) {

            this.jsonColumns
                .push(column);

            this.maxJsonColWidth = Math.max(this.maxJsonColWidth,
                                            column.length);
          }
        }
      }

      this.automap();
    }
  }

  private set(column: string,
              jsonColumn: string): void {

    if (jsonColumn) {

      this.columnMap
          .set(column,
               jsonColumn);
      this.jsonColumnMap
          .set(jsonColumn,
               column);

    } else {
      this.delete(column);
    }
  }

  private delete(column: string): void {

    const prev: string = this.columnMap
                             .get(column);

    this.columnMap
        .delete(column);

    if (prev) {
      this.jsonColumnMap
          .delete(prev);
    }
  }

  private createCustomers(): Array<Customer> {

    const customers: Customer[] = new Array<Customer>();

    for (let i: number = 0; i < this.jsonArray.length; i++) {

      const json: any = this.jsonArray[i];
      const name: any = json[this.columnMap.get('Name')];
      const firstName: any = json[this.columnMap.get('First Name')];
      const lastName: any = json[this.columnMap.get('Last Name')];
      const address = json[this.columnMap.get('Address')];
      const city = json[this.columnMap.get('City')];
      const state: any = json[this.columnMap.get('State')];
      const postalCode = json[this.columnMap.get('Postal Code')];

      const faxNumber: any = json[this.columnMap.get('Fax Number')];
      const cellNumber: any = json[this.columnMap.get('Mobile Number')];
      const email: any = json[this.columnMap.get('Email')];
      const dateOfBirth: any = json[this.columnMap.get('Date of Birth')];
      const cardNumber: any = json[this.columnMap.get('Card Number')];
      const balance: any = json[this.columnMap.get('Available balance')];
      const loyaltyPoints: any = json[this.columnMap.get('Loyalty Points')];
      const created: any = json[this.columnMap.get('Date Created')];
      const description: any = json[this.columnMap.get('Description')];
      const orderCount: any = json[this.columnMap.get('Order Count')];
      const dateLastOrder: any = json[this.columnMap.get('Date Last Order')];
      const lifetimeLoyaltyPoints: any = json[this.columnMap.get('Total Spent Lifetime')];
      const track1: any = json[this.columnMap.get('Track1')];
      const track2: any = json[this.columnMap.get('Track2')];
      const track3: any = json[this.columnMap.get('Track3')];
      const allowance: any = json[this.columnMap.get('Allowance')];

      let customer: Customer = customers.find(customer => customer.name === name);

      if (!customer) {

        customer = new Customer();
        customer.name = name;
        customer.firstName = firstName;
        customer.lastName = lastName;
        customer.address = address;
        customer.city = city;
        customer.state = state;
        customer.postalCode = postalCode;
        customer.faxNumber = faxNumber;
        customer.cellNumber = cellNumber;
        customer.email = email;
        customer.dateOfBirth = dateOfBirth;
        customer.cardNumber = cardNumber;
        customer.balance = balance;
        customer.loyaltyPoints = loyaltyPoints;
        customer.created = created;
        customer.description = description;
        customer.orderCount = orderCount;
        customer.dateLastOrder = dateLastOrder;
        customer.lifetimeLoyaltyPoints = lifetimeLoyaltyPoints;
        customer.track1 = track1;
        customer.track2 = track2;
        customer.track3 = track3;
        customer.allowance = allowance;

        customers.push(customer);
      }
    }

    customers.sort((a, b): number => a.name
                                      .localeCompare(b.name));

    return customers;
  }

  public getDefinedPropertyNames(customers: Customer[]): string[] {

    const defaultColumns = new Set(['name', 'orderCount', 'loyaltyPoints', 'dateLastOrder', 'created']);

    const columnSet = new Set<string>(defaultColumns);

    if (Object.keys(customers[0]).length > 5) {
      return Array.from(columnSet);
    }

    customers.forEach(customer => {
      Object.keys(customer)
            .forEach(key => {

              if (customer[key] !== undefined) {
                columnSet.add(key);
              }
            });
    });

    return Array.from(columnSet);
  }
}
