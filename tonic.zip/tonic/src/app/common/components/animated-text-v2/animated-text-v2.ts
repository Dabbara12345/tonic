import { Input } from '@angular/core';
import { OnInit } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Component } from '@angular/core';
import { style } from '@angular/animations';
import { trigger } from '@angular/animations';
import { animate } from '@angular/animations';
import { transition } from '@angular/animations';
import { AnimationTriggerMetadata } from '@angular/animations';

export const fadeInOutTimeout = 1000;
export const fadeInOut: AnimationTriggerMetadata = trigger('fadeInOut', [
  transition('void => *', [style({ opacity: '0', transform: 'translateX(-10%)' }), animate(fadeInOutTimeout)]),
  transition('* => void', [animate(fadeInOutTimeout, style({ opacity: '0' }))]),
  transition('* => *', [
style({ opacity: '0', transform: 'translateX(-10%)' }),
animate(fadeInOutTimeout, style({ opacity: '1', transform: 'translateX(0%)' })),
  ]),
]);

@Component({
  selector: 'app-animated-text-v2',
  template: `<div [@fadeInOut]="str" *ngIf="str !== null">
              {{ str }}
            </div>`,
  styles: [],
  animations: [fadeInOut],
})
export class AnimatedTextV2Component implements OnInit, OnDestroy {
  @Input() strings!: string[];

  public str!: string;
  private interval!: number;

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.iterateChoices();
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    window.clearInterval(this.interval);
  }

  private iterateChoices(): void {
    let index = 0
    this.interval = window.setInterval(() => {
      this.str = this.strings[index];

      index ++;
      if (index === this.strings.length) {
        index = 0;
      }
    }, 2500);
  }
}
