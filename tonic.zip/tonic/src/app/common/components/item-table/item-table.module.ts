import { NgModule } from '@angular/core';

import { SharedModule } from 'src/app/common/shared.module';
import { ItemTableComponent } from './item-table.component';

@NgModule({
  imports: [
    SharedModule,
  ],
  declarations: [
    ItemTableComponent
  ],
  exports: [
    ItemTableComponent
  ]
})
export class ItemTableModule { }
