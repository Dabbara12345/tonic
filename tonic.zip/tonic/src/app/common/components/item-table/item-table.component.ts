import { Input } from '@angular/core';
import { Output } from '@angular/core';
import { MatSort  } from '@angular/material/sort';
import { ViewChild } from '@angular/core';
import { Component } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { MatDialogRef } from '@angular/material/dialog';
import { EventEmitter } from '@angular/core';
import { AfterViewInit } from '@angular/core';
import { MatPaginator  } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import { Subscription } from 'rxjs';
import { Rgba } from 'ngx-color-picker';
import { Hsva } from 'ngx-color-picker';
import { Cmyk } from 'ngx-color-picker';
import { ColorPickerService } from 'ngx-color-picker';

import { Item } from 'src/app/model/menu/item.model';
import { Recipe } from 'src/app/model/menu/recipe.model';
import { Section } from 'src/app/model/menu/section.model';
import { Category } from 'src/app/model/menu/category.model';
import { ItemService } from 'src/app/service/menu/item.service';
import { ComboGroup } from 'src/app/model/menu/comboGroup.model';
import { AlertService } from 'src/app/service/utils/alert.service';
import { RecipeService } from 'src/app/service/menu/recipe.service';
import { SectionService } from 'src/app/service/menu/section.service';
import { SessionService } from 'src/app/service/session.service';
import { DualPriceService } from 'src/app/service/menu/dual-price.service';
import { ComboGroupService } from 'src/app/service/menu/combo-group.service';
import { MenuItemComponent } from 'src/app/route/menu/categories/menu-table/menu-item/menu-item.component';
import { MenuComboComponent } from 'src/app/route/menu/categories/menu-table/menu-combo/menu-combo.component';
import { EditRecipeComponent } from 'src/app/route/menu/recipes/edit/edit-recipe.component';

@Component({
  selector: 'app-item-table',
  templateUrl: './item-table.component.html',
  styleUrls: ['./item-table.component.scss']
})
export class ItemTableComponent implements AfterViewInit {

  @Input() menu: Category;
  @Input() selectedSection: Section;
  @Input() dragEnabled: boolean = false;
  @Input() inlineEditing: boolean = true;
  @Input()
  get items(): Array<Item> | null {
    return this._items;
  }
  set items(value: Array<Item> | null) {

    this._items = value;

    if(this._recipes &&
       this._items){
      this.loadItems();
    }
  }

  @Input()
  get recipes(): Array<Recipe> | null {
    return this._recipes;
  }
  set recipes(value: Array<Recipe> | null) {

    this._recipes = value;

    if(this._recipes &&
       this._items){
      this.loadItems();
    }
  }

  @Input() readOnly: boolean = false;
  @Input() disabled: boolean = false;
  @Output() editing: EventEmitter<boolean> = new EventEmitter<boolean>();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false })
  set sort(value: MatSort) {
    if (this.dataSource) {
      this.dataSource.sort = value;
    }
  }

  public _items: Array<Item>;
  public _recipes: Array<Recipe>;
  public comboGroups: Array<ComboGroup> = new Array<ComboGroup>();
  public editingItem: Item = new Item();
  public dualPrice = this.sessionService.getStore().hasEnabled('MODULE_DUAL_PRICE');

  public dragDisabled = false;
  public showPosition = false;
  public showColors = false;
  public editMode = false;
  public loading = false;
  public colorHasChanged = false;
  public saving = false;
  public deleting = false;
  private editModal = false;

  public fontColor: string = '#000000';
  public bgColor: string = '#ffffff';
  public isMobile = false;

  public dataSource: MatTableDataSource<Item> = new MatTableDataSource<Item>();
  public columnsWithSort: string[] = ['sortAsc', 'sortInput', 'sortDesc', 'favorite', 'name',
                                      'prompts', 'sides', 'price', 'action'];
  public displayedColumns: string[] = ['favorite', 'name', 'prompts',
                                       'sides', 'price', 'action'];
  public readOnlyColumns: string[] = ['favorite', 'name', 'sides', 'price'];

  public selectedRecipe: string = '';
  public dropdown_open: boolean = false;
  public dropdownRecipeSelected: Recipe;

  public dropdownConfig: any = {
         displayKey:         'name',               // if objects array passed which key to be displayed defaults to description
         height:             '200px',
         width: '10px',
         search:             true,                 // true/false for the search functionlity defaults to false,
         placeholder:        'Select item',             // text to be displayed when no item is selected defaults to Select,
         limitTo:            0,                    // number thats limits the no of options displayed in the UI
                                                   // (if zero, options will not be limited)
         noResultsFound:     'No recipe found!',   // text to be displayed when no items are found while searching
         searchPlaceholder:  'Search',             // label thats displayed in search input,
         searchOnKey:        'name',               // key on which search should be performed this will be selective search.
                                                   // if undefined this will be extensive search on all keys
         clearOnSelection:   true,                 // clears search criteria when an option is selected if set to true, default is false
         inputDirection:     'ltr'                 // the direction of the search input can be rtl or ltr(default)
  };

  constructor(public dialog: MatDialog,
              private sessionService: SessionService,
              private itemService: ItemService,
              private cpService: ColorPickerService,
              private sectionService: SectionService,
              private recipeService: RecipeService,
              private alertService: AlertService,
              private dualPriceService: DualPriceService,
              private comboGroupService: ComboGroupService) {

    this.isMobile = this.sessionService.isMobile();
    this.loadComboGroups();

    if(!this.isMobile){
      this.displayedColumns.unshift('drag');
    }
  }

  public ngAfterViewInit(): void {
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
    }
  }

  public onTogglePosition(): void {
    this.showPosition = !this.showPosition;
  }

  public onToggleColors(): void {
    this.showColors = !this.showColors;
  }

  public onToggleOrdering(): void {
    if(this.inlineEditing){
      this.showPosition = !this.showPosition;
    }
  }

  public getDisplayedColumns(): string[] {
    let columns: string[];

    if(this.showPosition){
      columns = [... this.columnsWithSort];
    } else {
      columns = [... this.displayedColumns];
    }

    if (this.showColors) {

      const actionIndex: number = columns.indexOf('action');

      if (actionIndex > -1) {

        columns.splice(actionIndex,
                       0,
                       'colors');

      } else {

        columns.push('colors');

      }

    }

    if (this.dualPrice) {

      const actionIndex: number = columns.indexOf('price');

      if (actionIndex > -1) {

        columns.splice(actionIndex + 1,
                       0,
                       'card_price');
      } else {
        columns.push('card_price');
      }
    }

    return columns;
  }

  public isEditing(item: Item): boolean {
    return !this.readOnly &&
           this.inlineEditing &&
           item &&
           item.id === this.editingItem
                           ?.id;
  }

  public onAddItem(): void {

    if(this.inlineEditing){
      this.editingItem = new Item();
      this.editMode = true;

      this._items
          .unshift(this.editingItem);

      this.updateDataSource();
    } else {
      this.onAddItemModal();
    }
  }

  public onCancel(): void {

    this.editMode = false;

    if (this._items[0].id === undefined) {
      this._items.shift();
    }

    this.editingItem = new Item();

    this.dragDisabled = false;
    this.updateDataSource();
    this.editing.emit(false);
  }

  public onHandlePrompts(prompt: string): void {

    switch (prompt) {
      case 'scale':
        this.editingItem.useScale = !this.editingItem.useScale;
        break;

      case 'name':
        this.editingItem.promptForName = !this.editingItem.promptForName;
        break;

      case 'quantity':
        this.editingItem.promptForQuantity = !this.editingItem.promptForQuantity;
        break;

      case 'price':
        this.editingItem.promptForPrice = !this.editingItem.promptForPrice;
        break;
    }
  }

  public onChangeElement(element: Array<Recipe>): void {

    if (element.length === 1 ) {

      this.dropdownRecipeSelected = new Recipe();
      this.dropdownRecipeSelected.name = element[0].name;
      this.dropdownRecipeSelected.id = element[0].id;

    } else if (element.length > 1 &&
               (typeof (element) !== 'string') ) {

      element[0] = element[1];

      element.splice(0, 1);

      this.dropdownRecipeSelected = new Recipe();
      this.selectedRecipe = element[0].name;
      this.dropdownRecipeSelected.name = element[0].name;
      this.dropdownRecipeSelected.id = element[0].id;
    }
  }

  public getPrice(item: Item): string {
    return item.price? (item.price / 100).toFixed(2)
                     : '';
  }

  public onFormatPrice(input: any): number {

    const value = input.target.value;
    const price = isNaN(value) ? undefined
                               : Math.round(value * 100);

    if(price){
      input.target.value = (price / 100).toFixed(2);
    } else {
      input.target.value = '';
    }

    return price;
  }

  public onSave(): void {
    this.saving = true;

    if (this.dropdownRecipeSelected
           ?.id) {
      this.editingItem
          .recipeId = this.dropdownRecipeSelected
                          .id;
      this.editingItem
          .name = this.dropdownRecipeSelected
                      .name;
    }

    if(this.dualPrice){
      this.editingItem
          .priceCredit = this.dualPriceService
                             .calculateCardPrice(this.editingItem.price);
    }

    this.sectionService
        .saveItem(this.editingItem,
                  this.selectedSection)
        .subscribe({
          next: (savedItem) => {
            let message = 'Item ';
            const index = this._items.findIndex(i => i.id === savedItem.id);

            if (index !== -1) {
              this._items[index] = new Item().load(savedItem);
              message += 'saved';
            } else {
              if (this._items[0].id === undefined) {
                this._items.shift();
              }
              this._items.push(new Item().load(savedItem));
              message += 'added';
            }
            this.editingItem = new Item();
            this.updateDataSource();
            this.dataSource.paginator
                           .firstPage();
            this.alertService.success(message);
            this.editing.emit(false);
            this.saving = false;
            this.editingItem = undefined;
            this.editMode = false;
            this.dragDisabled = false;

          }, error: (err) => {
            this.saving = false;
            this.dragDisabled = false;
            err.message = `Unable to save the item ${this.editingItem.name}\n${err.message}`;
            this.alertService.error(err);
            this.editingItem = undefined;
            this.editMode = false;
          }
        });
  }

  public onDelete(): void {

    this.deleting = true;

    this.sectionService
        .removeItem(this.editingItem,
                    this.selectedSection)
        .subscribe({

          next: (): void => {

            this.deleting = false;
            this.deleted(this.editingItem);
            this.editingItem = undefined;
            this.editMode = false;

          }, error: (err): void => {

            this.deleting = false;
            this.editingItem = undefined;
            this.editMode = false;

            this.alertService
                .error(`Unable to delete. ${err.error}`);

          }

        });

  }

  public onAddItemModal(): void {
    const dialogRef: MatDialogRef<MenuItemComponent> = this.dialog
                          .open(MenuItemComponent,
                                { width: 'fit-content',
                                  height: 'fit-content',
                                  disableClose: true,
                                  data: { section: this.selectedSection,
                                          recipes: this._recipes,
                                          items: this._items,
                                          item: this.editingItem ? this.editingItem: new Item() }
                                });

    dialogRef.afterClosed()
             .subscribe((result: any): void => {

              if (result?.deleted) {

                this.deleted(this.editingItem)

              } else if (result) {

                let message: string = 'Item ';

                if(result.id === undefined){
                  this.loadSectionItems();
                } else if (this.editingItem
                               .id) {
                  const index: number = this._items.findIndex( i => i.id === this.editingItem.id);

                  this._items[index].load(this.editingItem);
                  message += 'saved';
                } else {
                  this._items
                      .unshift(new Item().load(result));
                  message += 'added';
                }

                this.editingItem = new Item();
                this.updateDataSource();
                this.dataSource
                    .paginator
                    .firstPage();
                this.alertService.success(message);
                this.editing.emit(false);
              }
      this.editingItem = undefined;
      this.editMode = false;
      });
  }

  public onCancelModal(): void {

    if (this.editingItem.isCombo()) {
      this.onAddCombo();

    } else {
      this.onAddItem()
    }
  }

  private deleted(item: Item): void {

    item.seqNo = undefined;
    this.loading = true;
    this.editMode = false;

    const index: number = this._items.findIndex(i => i.id === item.id);

    this._items.splice(index, 1);
    this.updateDataSource();
    this.loading = false;

    this.alertService.success(`Item ${item.name} deleted!`);
    this.editing.emit(false);
    this.editingItem = new Item();
  }

  public onEdit(item: Item): void {

    // this.onCancel();
    this.editingItem = new Item().load(item);

    if (this.editingItem.isCombo()) {
      this.onAddCombo();

    } else {
      if(this.inlineEditing){
        if (item.recipeId &&
            item.name) {

          this.dropdownRecipeSelected = new Recipe().load(this.findRecipe(item.recipeId));
          this.selectedRecipe = this.dropdownRecipeSelected.name;

        }

        this.dragDisabled = true
        this.editMode = true;
      } else {
        this.onAddItemModal();
      }
    }
  }

  public onDrag(event: CdkDragDrop<any>): void {

//    this.dragDisabled = true;

    if (event.previousIndex !== event.currentIndex) {

      this.move(event.item.data.id,
                event.currentIndex + 1)
         .add(()=> this.dragDisabled = false);
    }
  }

  public onAddCombo(): void {

    if (this.editingItem === undefined) {
      this.editingItem = new Item();
    }

    if (!this.selectedSection.items) {
      this.selectedSection.items = new Array<Item>();
    }
    this.editingItem.setCombo(true);

    const dialogRef: MatDialogRef<MenuComboComponent> = this.dialog
                          .open(MenuComboComponent,
                                { width: '500px',
                                  disableClose: true,
                                  data: {section: this.selectedSection,
                                         item: this.editingItem,
                                         recipes: this._recipes,
                                         comboGroups: this.comboGroups }
                                });

    dialogRef.afterClosed()
            .subscribe({
      next: (result: { combo: Item,
                       delete ?: boolean }): void => {

        if (result) {

          if (result?.delete) {
            this.deleted(result.combo);
          } else {

            if (this._items.some(i => i.id === result.combo.id)) {

              const itemIndex: number = this._items.findIndex(i => i.id === result.combo.id);

              this._items[itemIndex] = new Item().load(result.combo);

              this.alertService.success('Item changed!');
            } else {

              this._items.unshift(result.combo as Item);

              this.alertService.success('Item added!');
            }

            this.updateDataSource();
            this.loading = false;
          }
        }

        this.onCancel();

      },
      error: (err): void => {
        this.alertService.error(`Unable to save the item. \n  ${err.error}`);
        this.loading = false;
      }
    });
  }

  public onShortcutToggled(item: Item): void {

    if(item.hasShortcut()){
      item.shortcut = -1;
    } else {
      item.shortcut = 999;
    }

    this.itemService
        .save(item)
        .subscribe({
          next: (result): void => {
            let mergedItem: Item = this.itemService
                                       .mergeItems(item,
                                                   result);
            this.updateItems(mergedItem);
          },
          error: (err): void => {
            this.alertService
                .error(`Unable to save the item. \n ${err}`);
          }
        });
  }

  public onMove(item: Item,
                up: boolean): void {

    let pos: number = this.findIndex(item) + 1;

    this.move(item.id,
              up ? pos - 1 :
                   pos + 1);
  }

  public onPosition(item: Item,
                    event: EventTarget): void {

    const order: string = (event as HTMLInputElement).value;

    this.move(item.id,
              Number(order));

  }

  public findIndex(item: Item): number {

    return this._items
               .findIndex( i => i.id === item.id);

  }

  public getDataSource(): MatTableDataSource<Item> {
    return this.updateDataSource();
  }
/*
  public hasCharge(): boolean {

    let has: boolean = false;
    const id: string = 'currency-' + (this.editingItem.id ? this.editingItem.id : '');
    const inputCurrency: HTMLInputElement = document.getElementById(id) as HTMLInputElement;

    if (inputCurrency &&
        Number(inputCurrency.value) >= 0) {
      has = true;
    }

    return has;
  }
*/
  public getColorLetters(hexcolor: string): string {
    return (parseInt((hexcolor).slice(1), 16) > Number(0xffffff)/1.1) ? 'black':'white';
  }

  public onChangeColor(color: string,
                       ref: MatButton,
                       item: Item): Cmyk {

    const hsva: Hsva = this.cpService
                           .stringToHsva(color.toString());
    const rgba: Rgba = this.cpService
                           .hsvaToRgba(hsva);

    if (ref._elementRef.nativeElement.name === 'font') {

      item.fontColor = color;

    } else {

      item.backgroundColor = color;
    }

    this.colorHasChanged = true;

    setTimeout(() => {
      if (this.colorHasChanged) {
        this.onUpdate(item);
      }
    }, 0);

    return this.cpService.rgbaToCmyk(rgba);
  }

  private updateItems(item: Item): void {

    let itemFound: Item = this._items.find(i => i.id === item.id);

    if (itemFound) {
      let index: number = this._items.indexOf(itemFound);

      this._items.fill(item, index, index + 1);
    } else {
      this._items.push(item);
    }

    this.updateDataSource();
    this.editing.emit(false);
  }

  private updateDataSource(): MatTableDataSource<Item> {
    console.log('UPDATING DATASOURCE', this._items);
    this.dataSource = new MatTableDataSource(this._items);
    this.dataSource.sortingDataAccessor = (item, property): any => {
      switch (property) {
        case 'name': return item.name;
        case 'card_price': return item.priceCredit;
        default: return item[property];
      }
    };

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    return this.dataSource;
  }

  private loadSectionItems(orderChange?: boolean): void {

    this.loading = true;

    this.sectionService
        .listItems(this.selectedSection.id)
        .subscribe({
      next: (data): void => {

        this._items = new Array<Item>();

        for (const d of data){
          this._items
              .push(new Item().load(d));
        }

        this.loading = false;
        this.editingItem = new Item();
        this.updateDataSource();

        if (!orderChange) {
          this.editing.emit(false);

          this.alertService
              .success('Item saved');
        }

        this.editMode = false;
      },
      error: (err): void => {
        this.alertService.error(err);
        this.loading = false;
      }
    });
  }

  private loadItems(): void {

    this.loading = true;

    if (this._items) {
      this.updateDataSource();
    }

    this.loading = false;
  }

  private move(itemId: number,
               position: number): Subscription {

    return this.sectionService
        .move(this.selectedSection
                  ?.id,
              itemId,
              position)
        .subscribe(() => {

          this.loadSectionItems(true);
        }, err => {
          this.alertService
              .error('Unable to move item, Error: ' + err.error);
        });
  }

  public onUpdate(item: Item): void {

    this.loading = true;

    this.sectionService
        .saveItem(item,
                  this.selectedSection)
        .subscribe({

          next: (data): void => {

            this.loadSectionItems(true);

            this.alertService.success('Item Color updated');
            this.colorHasChanged = false;
            this.loading = false;

          }, error: (err): void => {

            this.alertService.error(err);
            this.colorHasChanged = false;
            this.loading = false;
          }
        });
  }

  public onItem(item: Item): void {

    if(!this.editModal && !item.isCombo()){
      this.editModal = true;

      if(item.recipe){
        this.editItem(item.recipe);
      } else {
        this.recipeService
            .get(item.recipeId)
            .subscribe({
          next: (data): void => {

            const recipe = new Recipe().load(data);

            this.editItem(recipe);
          },
          error: err => {
            this.editModal = false;
            this.alertService
                .error(err);
          }
        });
      }
    }
  }

  private editItem(recipe: Recipe): void {

    const dialogRef: MatDialogRef<EditRecipeComponent> = this.dialog
                                                             .open(EditRecipeComponent,
                                                                   { width: '750px',
                                                                     disableClose: true,
                                                                     data:{ recipe,
                                                                            deletable: false,
                                                                            salesGroups: undefined,
                                                                            preparations: undefined} });

    dialogRef.afterClosed()
             .subscribe({
      next: (result: { recipe: Recipe}): void => {

        if (result) {

          const recipe: Recipe = result.recipe;
          const item = this.items
              .find(i => i.recipeId === recipe.id);

          item.name = recipe.name;
          item.recipe = recipe;
          this.alertService
              .success('Item saved!');
        }

        this.editModal = false;
      },
      error: err => {
        this.editModal = false;
        this.alertService
            .error(err);
      }
    });
  }

  public getDisplayItem(): null | Array<Recipe> {

    this.selectedRecipe = '';

    if (this.items &&
        this.items.length > 0) {

      if (this.recipes &&
          this.recipes.length > 0) {

        return this.recipes
                   .filter((recipe): boolean => {

                       return this.items
                                  .filter((item): boolean => {
                                    return item.recipeId === recipe.id;
                                  })
                                  .length === 0;
                   });

      }

    } else {
      return this.recipes;
    }

    return null;
  }

  private findRecipe(recipeId: number): Recipe {

    return this.recipes
               .find(r => r.id === recipeId);
  }

  private loadComboGroups(): void {
    this.comboGroupService
        .list()
        .subscribe({
          next: data => {
            this.comboGroups = new Array<ComboGroup>();
            data.forEach((d): void => {
              this.comboGroups
                  .push(new ComboGroup().load(d));
           });
          }, error: (err): void => {
            this.alertService.error(err);
          }
        });
  }
}
