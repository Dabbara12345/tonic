import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { animate } from '@angular/animations';
import { AnimationTriggerMetadata } from '@angular/animations';
import { style } from '@angular/animations';
import { transition } from '@angular/animations';
import { trigger } from '@angular/animations';

export const fadeInOutTimeout = 500;
export const fadeInOut: AnimationTriggerMetadata = trigger('fadeInOut', [
  transition('void => *', [style({ opacity: '0', transform: 'translateX(-10%)' }), animate(fadeInOutTimeout)]),
  transition('* => void', [animate(fadeInOutTimeout, style({ opacity: '0' }))]),
  transition('* => *', [
style({ opacity: '0', transform: 'translateX(-10%)' }),
animate(fadeInOutTimeout, style({ opacity: '1', transform: 'translateX(0%)' })),
  ]),
]);

@Component({
  selector: 'app-animated-text',
  template: `<div [@fadeInOut]="text" *ngIf="text !== null">
              {{ text }}
            </div>`,
  styles: [],
  animations: [fadeInOut],
})
export class AnimatedTextComponent {
  @Input() text: string;
}
