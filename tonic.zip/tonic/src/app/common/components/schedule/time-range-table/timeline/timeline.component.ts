import { Input } from '@angular/core';
import { Component } from '@angular/core';

import { Time } from 'src/app/model/config/time.model';
import { SessionService } from 'src/app/service/session.service';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent {

  private pipinterval: number = this.sessionService.isMobile() ? 60 : 30; //minutes

  private xLPipInterval: number = this.sessionService.isMobile() ? undefined : 24;
  private largePipInterval: number = this.sessionService.isMobile() ? undefined : 12;
  private mediumPipInterval: number = this.sessionService.isMobile() ? 12 : 6;
  private smallPipInterval: number = this.sessionService.isMobile() ? 6 : 2;
  private labelInterval: number = 6;

  public pips: PipInfo[] = new Array<PipInfo>();

  @Input() upsideDown: boolean;

  constructor(public sessionService: SessionService) {
    const pipNum: number = 24 * 60 / this.pipinterval;

    for (let i: number = 0; i <= pipNum; i++) {
      const percent: number = 100 * i/pipNum;
      let height: number = 0.4;
      let label: string = undefined;

      if (i % pipNum === 0) {
        height = 0;
      } else if (this.xLPipInterval && i % this.xLPipInterval === 0) {
        height = 2;
      } else if (this.largePipInterval && i % this.largePipInterval === 0) {
        height = 1.6;
      } else if (i % this.mediumPipInterval === 0) {
        height = 1.2;
      } else if (i % this.smallPipInterval === 0) {
        height = 0.8;
      }

      if (i % this.labelInterval === 0 && i % pipNum !== 0) {
        const time: Time = new Time(percent);

        label = time.get12Hours() + ' ' + (time.isAM() ? 'AM' : 'PM');
      }

      const pipInfo: PipInfo = new PipInfo(percent, height, label);

      this.pips.push(pipInfo);
    }
  }
}

class PipInfo {
  constructor(public left: number, public height: number, public label: string) {};
}
