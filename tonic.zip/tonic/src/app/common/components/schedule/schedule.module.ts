import { NgModule } from '@angular/core';

import { SharedModule } from '../../shared.module';
import { EventsComponent } from './events/events.component';
import { ScheduleComponent } from './schedule.component';
import { TimelineComponent } from './time-range-table/timeline/timeline.component';
import { TimeRangeComponent } from './time-range-table/time-range/time-range.component';
import { EditEventComponent } from './events/edit-event/edit-event.component';
import { TimeRangeTableComponent } from './time-range-table/time-range-table.component';

@NgModule({
  imports: [
    SharedModule,
  ],
  declarations: [
    EventsComponent,
    ScheduleComponent,
    TimeRangeComponent,
    TimelineComponent,
    EditEventComponent,
    TimeRangeTableComponent,
  ],
  exports: [
    TimeRangeTableComponent
  ],
  entryComponents: [
    ScheduleComponent
  ]
})
export class ScheduleModule {}
