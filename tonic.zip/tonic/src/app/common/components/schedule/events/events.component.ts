import { AfterViewInit } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { OnInit } from '@angular/core';
import { OnChanges } from '@angular/core';
import { ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { EventInfo } from 'src/app/model/config/event-info.model';
import { AlertService } from 'src/app/service/utils/alert.service';
import { EditEventComponent } from './edit-event/edit-event.component';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss']
})
export class EventsComponent implements OnInit, AfterViewInit, OnChanges {

  @Input() events: Array<EventInfo> = new Array<EventInfo>();
  @Input() isAdding: boolean = false;

  @Output() notAdding: EventEmitter<boolean> = new EventEmitter<boolean>();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  public dataSource: MatTableDataSource<EventInfo>;

  public displayedColumns: string[] = ['name', 'date', 'time', 'repeat', 'actions'];

  constructor(public dialog: MatDialog,
              private alertService: AlertService) {
  }

  public ngOnInit(): void {
    this.dataSource = new MatTableDataSource(this.events);
  }

  public ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public ngOnChanges(): void {
    if (this.isAdding) {
      this.openEventDialog();
      this.notAdding.emit(false);
    }
  }

  private openEventDialog(event?: EventInfo): void {
    const dialogRef: MatDialogRef<EditEventComponent> = this.dialog
                          .open(EditEventComponent,
                                {width: '600px',
                                 disableClose: true,
                                 data: event});

    dialogRef.afterClosed()
             .subscribe({
      next: (obj): void => {

        if (obj && obj.data) {
          if (event) {
            this.events.splice(this.events.indexOf(event), 1);
          }

          if (!obj.delete) {
            this.events.push(obj.data);
          }

          this.dataSource.data = this.events;
        }
      },
      error: err => {
        this.alertService.error(err);
      }
    });
  }

  public edit(event: EventInfo): void {
    this.openEventDialog(event);
  }
}
