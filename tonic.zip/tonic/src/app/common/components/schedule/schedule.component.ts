import { Inject } from '@angular/core';
import { Output } from '@angular/core';
import { Component } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

import { Time } from 'src/app/model/config/time.model';
import { Range} from 'src/app/model/config/range.model';
import { Schedule } from 'src/app/model/config/schedule.model';
import { Frequency } from 'src/app/model/config/frequency.enum';
import { EventInfo } from 'src/app/model/config/event-info.model';
import { SessionService } from 'src/app/service/session.service';
import { ScheduleService } from 'src/app/service/config/schedule.service';

@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.scss'],
})
export class ScheduleComponent {

  @Output() saved: EventEmitter<Array<Schedule>> = new EventEmitter<Array<Schedule>>();

  public weeklySchedule: Map<number, Range<Time>[]> = new Map<number, Array<Range<Time>>>();
  public events: EventInfo[] = new Array<EventInfo>();
  public loadingSchedules: boolean = false;
  public isAdding: boolean = false;
  public tabIndex: number = 0;

  constructor(public dialogRef: MatDialogRef<ScheduleComponent>,
              public sessionService: SessionService,
              private scheduleService: ScheduleService,
              @Inject(MAT_DIALOG_DATA) public data: Array<Schedule>) {

    this.load(data);
  }

  public onAddEvent(): void {
    this.isAdding = true;
  }

  public onSave(): void {

    this.weeklySchedule = this.scheduleService
                              .compact(this.weeklySchedule);

    const schedules: Schedule[] = this.scheduleService
                          .toSchedules(this.weeklySchedule,
                                       this.sessionService.getStore());

    this.events
        .forEach(event => {

      schedules.push(this.scheduleService
                         .toSchedule(event,
                                   this.sessionService.getStore()));
    });

    this.saved
        .emit(schedules);

    this.dialogRef
        .close(schedules);
  }

  private load(data: Schedule[]): void {

    data?.forEach((schedule: Schedule): void => {

      if (new Time(schedule.endTime).percent === 0) {
        schedule.endTime = '24:00:00';
      }

      if (schedule.frequency === Frequency.Weekly &&
          schedule.value?.length === 7 &&
          schedule.value !== '0000000' &&
          schedule.startTime &&
          schedule.endTime) {

        for (let i: number = 0; i < 7; i++) {

          if (schedule.value[i] === '1') {

            let day: Range<Time>[] = this.weeklySchedule
                                         .get(i);

            if (!day) {
              day = new Array();
              this.weeklySchedule
                  .set(i, day);
            }

            day.push(new Range(new Time(schedule.startTime),
                     new Time(schedule.endTime)));
          }
        }

      } else {
        this.events
            .push(this.scheduleService
                      .toEvent(schedule));
      }
    });
  }
}
