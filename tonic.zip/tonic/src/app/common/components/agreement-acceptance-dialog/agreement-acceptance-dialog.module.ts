import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MaterialXModule } from '../../material.module';
import { AgreementAcceptanceDialogComponent } from './agreement-acceptance-dialog.component';



@NgModule({
  declarations: [
    AgreementAcceptanceDialogComponent
  ],
  imports: [
    CommonModule,
    MaterialXModule
  ]
})
export class AgreementAcceptanceDialogModule { }
