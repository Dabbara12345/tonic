import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgreementAcceptanceDialogComponent } from './agreement-acceptance-dialog.component';

describe('AgreementAcceptanceDialogComponent', () => {
  let component: AgreementAcceptanceDialogComponent;
  let fixture: ComponentFixture<AgreementAcceptanceDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgreementAcceptanceDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgreementAcceptanceDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
