import { Input } from '@angular/core';
import { OnChanges } from '@angular/core';
import { Output } from '@angular/core';
import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { EventEmitter } from '@angular/core';
import { SimpleChanges } from '@angular/core';

import { TreeNode } from 'src/app/model/menu/TreeNode.model';
import { SalesGroup } from 'src/app/model/menu/salesGroup.model';
import { AlertService } from 'src/app/service/utils/alert.service';
import { SalesGroupService } from 'src/app/service/menu/sales-group.service';

@Component({
  selector: 'app-hierarchical-sales-group-dropdown',
  templateUrl: './hierarchical-sales-group-dropdown.component.html',
  styleUrls: ['./hierarchical-sales-group-dropdown.component.scss']
})
export class HierarchicalSalesGroupDropdownComponent implements OnInit, OnChanges {

  @Input() multiple!: boolean;
  @Input() selectedGroups: Array<SalesGroup>;
  @Input() selectedChildren: Array<SalesGroup>;
  @Input() selectedGroup: number;
  @Input() salesGroups: Array<SalesGroup>;
  @Input() width: string;

  @Output() formEmitted: EventEmitter<FormGroup> = new EventEmitter();

  private selectedGroupsIds: Array<number> = new Array();

  public form: FormGroup;
  public groups: FormControl;
  public loading: boolean = true;
  public treeBuild: boolean = false;

  public tree: Array<{name: string,
                      treeNodes:Array<TreeNode>,
                      salesGroup: SalesGroup}> = new Array();

  constructor(private salesGroupService: SalesGroupService,
              private alertService: AlertService) {
    this.form = new FormGroup({
      groups: new FormControl(new Array(), Validators.required)
    });
  }

  public ngOnInit(): void {
    if (this.salesGroups === undefined) {
      this.loadSalesGroup();
    } else {
      this.buildGroupsTree();
      this.populateFormField();
    }
  }

  public ngOnChanges(changes: SimpleChanges): void {
    if (changes?.selectedGroups?.currentValue ||
        changes?.selectedGroup?.currentValue) {
      this.initSelected();
    }
  }

  public onEmitForm(): void {
    this.formEmitted
        .emit(this.form);
  }

  public getIndent(node: TreeNode): string {
    let indent: string = '';

    if (node.level > 0){
      for (let index: number = 0; index < node.level; index++) {
        indent += '\u00A0';
      }

      indent += '';
    }

    return indent;
  }

  public getValue(value: any): SalesGroup {

    let name: SalesGroup;

    if (value.treeNodes) {
      name = this.form.get('groups')
                      .value.find(e => e.name === value.name);
    } else {
      name = this.form.get('groups')
                      .value.find(e => e.name === value.salesGroup.name);
    }

    return name;
  }

  private setForm(): void {
    if (this.selectedGroups) {

      this.form = new FormGroup({
        groups: new FormControl(this.selectedGroups ? this.selectedGroups : new Array<string>(),
                                Validators.required)
      });
    } else {

      this.form = new FormGroup({
        groups: new FormControl(this.selectedChildren ? this.selectedChildren : new Array<string>(),
                                Validators.required)
      });
    }
  }

  private initSelected(): void {
    if (this.selectedGroups !== undefined) {

      this.selectedGroups.forEach(group => {
        if (typeof group === 'number') {
          this.selectedGroupsIds.push(group);
        }
      });
    } else {
      this.selectedGroupsIds.push(this.selectedGroup);
    }
  }

  private loadSalesGroup(): void {
    this.salesGroups = new Array<SalesGroup>();

    this.salesGroupService
        .list()
        .subscribe({
          next: (list): void => {

          list.forEach((rule): void => {
            this.salesGroups
                .push(new SalesGroup().load(rule));
          });

          this.buildGroupsTree();
          this.populateFormField();
        },
      error: (err): void => {
        this.alertService.error(err);
        this.loading = false;
      }
    });
  }

  private buildGroupsTree(): void {
    this.tree = new Array<{ name: string,
                            treeNodes: Array<TreeNode>,
                            salesGroup: SalesGroup }>();

    this.salesGroups
        .forEach(group => {

          if (group.groupName &&
              group.groupName === group.name &&
              !this.tree.find(t => t.name === group.groupName)) {

            this.tree
                .push({name: group.groupName,
                      treeNodes: new Array<TreeNode>(),
                      salesGroup: group});

          } else if (group?.groupName &&
                     !this.tree.find(t => t.name === group.groupName) &&
                     group.groupName !== group.name) {

            this.tree
                .push({ name: group.groupName,
                        treeNodes: new Array<TreeNode>(),
                        salesGroup: new SalesGroup() });

            this.addToBranch(group);

          } else if(group?.groupName &&
                    group.groupName !== group.name &&
                    this.tree.find(t => t.name === group.groupName)) {

            this.addToBranch(group);
          } else if (group.groupName &&
                     group.groupName === group.name &&
                     this.tree.find(t => t.name === group.groupName)) {

            this.replaceTreeNode(group);
          } else {

            this.tree
                .push({ name: group.name,
                        treeNodes: new Array<TreeNode>(),
                        salesGroup: group });
          }
        });
  }

  private replaceTreeNode(group: SalesGroup): void {
    let parentNode: { name: string,
                      treeNodes: Array<TreeNode>,
                      salesGroup: SalesGroup } = this.tree.find(t => t.name === group.groupName);

    parentNode.salesGroup = group;

    this.tree.fill(parentNode,
                   this.tree.findIndex(t => t.name === group.groupName),
                   1);
  }

  private addToBranch(group: SalesGroup): void {
    let parentNode: { name: string,
                      treeNodes: Array<TreeNode> } = this.tree.find(t => t.name === group.groupName);

    this.tree.fill({ name: group.groupName,
                     treeNodes: this.buildBranch(parentNode,
                                                 new TreeNode(group, group.groupName,
                                                 1)),
                     salesGroup: group },
                     this.tree.findIndex(t => t.name === group.groupName),
                     1);
  }

  private buildBranch(parentNode: { name: string,
                                    treeNodes: Array<TreeNode>},
                      treeNode: TreeNode): Array<TreeNode> {

    let branch: TreeNode[] = parentNode.treeNodes;

    branch.push(treeNode);

    return branch;
  }

  private populateFormField(): void {
    this.setForm();

    this.loading = false;
  }
}
