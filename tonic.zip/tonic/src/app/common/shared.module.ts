import { NgModule } from '@angular/core';
import { ModuleWithProviders } from '@angular/core';

import { NgChartsModule } from 'ng2-charts';

import { ShortenPipe } from './pipes/shorten.pipe';
import { TruncatePipe } from 'src/app/common/pipes/truncate.pipe';
import { ColorsService } from '../service/utils/colors.service';
import { AngularXModule } from './angular.module';
import { MaterialXModule } from './material.module';
import { DirectivesModule } from './directives.module';
import { BootstrapXModule } from './bootstrap.module';
import { AnimatedTextComponent } from './components/animated-text/animated-text';
import { AnimatedTextV2Component } from './components/animated-text-v2/animated-text-v2';
import { PaymentsConfigComponent } from '../route/nav-bar/nav-options/settings/payments/payments.component';

// https://angular.io/styleguide#!#04-10
@NgModule({
    imports: [
        MaterialXModule,
        AngularXModule,
        BootstrapXModule,
        DirectivesModule,
        NgChartsModule
    ],
    declarations: [
        ShortenPipe,
        TruncatePipe,
        AnimatedTextComponent,
        AnimatedTextV2Component,
        PaymentsConfigComponent
    ],
    providers: [
        ColorsService
    ],
    exports: [
        MaterialXModule,
        AngularXModule,
        BootstrapXModule,
        DirectivesModule,
        NgChartsModule,

        ShortenPipe,
        TruncatePipe,
        AnimatedTextComponent,
        AnimatedTextV2Component,
        PaymentsConfigComponent
    ]
})

export class SharedModule {
    static forRoot(): ModuleWithProviders<SharedModule> {
        return {
            ngModule: SharedModule
        };
    }
}
