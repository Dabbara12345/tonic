import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

import { REGEX_US_PHONE_NUMBER } from "src/app/common/constants/regex.constants";

// Defines a custom validator function for US phone numbers.
export const usPhoneNumberValidator = (): ValidatorFn => {
  return (control: AbstractControl): ValidationErrors | null => {

    const valid = REGEX_US_PHONE_NUMBER.test(control.value);

    return valid ? null : { invalidPhoneNumber: true };
  };
}
