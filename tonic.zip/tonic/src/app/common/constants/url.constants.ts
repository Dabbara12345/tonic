export const FOOTER_URLS = {
  SHOP: 'https://shop.ordyx.com/',
  GOOGLE_PLAY_STORE: 'https://apps.apple.com/us/app/ordyxone/id1540796532?itsct=apps_box&itscg=30200"><img src="/assets/img/icons/v3/google-play.png',
  APPLE_STORE: 'https://play.google.com/store/apps/details?id=com.ordyx.one&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1',
  PCI_COMPLIANCE: 'https://tonicpos.com/pci-compliance/',
  MERCHANT_FUNDING: "https://tonicpos.com/merchant-funding/",
  INTEGRATIONS: "https://tonicpos.com/integrations/",
  CAREERS: "https://tonicpos.com/careers/",
  TONIC_SETUP_INFORMATION: "https://tonicpos.com/tonic-setup-information/",
  REQUEST_A_DEMO: "https://tonicpos.com/request-a-demo/",
  CONTACT: "https://tonicpos.com/contact",
  FEATURE_REQUEST: "https://tonicpos.com/feature-request/",
  GIFT_CARD: "https://tonicpos.com/gift-card/",
  SAFE_HARBOR_STATEMENT: "https://tonicpos.com/safe-harbor-statement/",
  APPS: "https://app.ordyx.com"
}

export enum DASHBOARD_ROUTES {
  HOME = '/app/v3/dashboard',
  APPS = 'http://app.ordyx.com'
}

export const V2_ROUTES = {
  DASHBOARD: {
    path: '/system/dashboard',
    text: 'DASHBOARD'
  },
  CONFIGURATION: {
    MENU: {
      MENU_CONFIGURATION: {
        path: '/system/menu/menu',
        text: 'Categories'
      },
      MODIFIERS: {
        path: '/system/menu/preparation?showModal=true',
        text: 'Modifier Sets'
      },
      MODIFIERS_SETS: {
        path: '/system/menu/preparation',
        text: 'Modifier Sets'
      },
      SALES_GROUPS: {
        path: '/system/menu/recipe?showModal=true',
        text: 'Items'
      },
      COMBO_GROUPS: {
        path: '/system/menu/combo_group',
        text: 'Combo Groups'
      },
      ITEMS: {
        path: '/system/menu/recipe',
        text: 'Items'
      },
      RULES: {
        path: '/system/menu/rules',
        text: 'Rules'
      },
    },
    LABOR: {
      STAFF: {
        path: '/system/staff/user',
        text: 'Staff'
      },
      ROLES: {
        path: '/system/staff/role',
        text: 'Roles'
      }
    },
    PAYMENT: {
      TYPES: {
        path: '/system/payment/type',
        text: 'Types'
      },
      DISCOUNTS: {
        path: '/system/payment/discount',
        text: 'Discounts'
      },
      DONATIONS: {
        path: '/system/payment/donation',
        text: 'Donations'
      },
      TAXES: {
        path: '/system/payment/tax',
        text: 'Taxes'
      },
      CURRENCIES: {
        path: '/system/payment/foreign_currency',
        text: 'Currencies'
      },
    },
    HARDWARE: {
      TERMINALS: {
        path: '/system/equipment/terminal',
        text: 'Terminals'
      },
      EMVS: {
        path: '/system/equipment/emv',
        text: 'EMVs'
      },
      PERIPHERALS: {
        path: '/system/equipment/annunciator',
        text: 'Peripherals'
      },
      SAFES: {
        path: '/system/equipment/safe',
        text: 'Safes'
      }
    },
    UI: {
      TABLE_MAP: {
        path: '/system/ui/layout',
        text: 'Table Map'
      },
      SETTINGS: {
        path: '/system/ui/settings',
        text: 'Settings'
      }
    }
  },
  TIME: {
    path: '/system/time',
    text: 'Time & Attendance'
  },
  CUSTOMER: {
    path: '/system/customer',
    text: 'Customers'
  },
  INVENTORY: {
    path: '/system/inventory',
    text: 'Inventory'
  },
  QUICKBOOKS: {
    path: '/system/quickbooks',
    text: 'Quickbooks'
  }
}

