// Regular expression to match the US phone number format: (XXX) XXX-XXXX
export const REGEX_US_PHONE_NUMBER = /^\(\d{3}\) \d{3}-\d{4}$/;

