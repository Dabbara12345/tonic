import { ExtraStoreToolsViewModal, STORE_MODULES, StoreModuleViewModel, EXTRA_STORE_TOOLS } from "src/app/model/v3/store.model";
import { V2_ROUTES } from "./url.constants";
import { DropdownMenuViewModal, DropdownViewModal } from "src/app/model/v3/ui.model";

export const MAX_DATA_POINTS_SALES_BY_HOUR = 24;

export const SALES_BREAKDOWN_CHART_SEGMENT_LIMIT = 8;


export const storeModuleList: Array<StoreModuleViewModel> = [
  {
    id: STORE_MODULES.MODULE_NEW_BACK_OFFICE,
    text: 'New BOH',
    icon: 'auto_awesome',
    moduleName: STORE_MODULES.MODULE_NEW_BACK_OFFICE,
    path: V2_ROUTES.DASHBOARD.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_TIME_ATTENDANCE,
    text: 'Attendance',
    icon: 'punch_clock',
    moduleName: STORE_MODULES.MODULE_TIME_ATTENDANCE,
    path: V2_ROUTES.TIME.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_CUSTOMER_ACCOUNTS,
    text: 'Customers',
    icon: 'people',
    moduleName: STORE_MODULES.MODULE_CUSTOMER_ACCOUNTS,
    path: V2_ROUTES.CUSTOMER.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_INVENTORY,
    text: 'Inventory',
    icon: 'inventory',
    moduleName: STORE_MODULES.MODULE_INVENTORY,
    path: V2_ROUTES.INVENTORY.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_ONLINE_ORDERING,
    text: 'Self Order',
    icon: 'shopping_cart',
    moduleName: STORE_MODULES.MODULE_ONLINE_ORDERING,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_ENTERPRISE,
    text: 'Enterprise',
    icon: 'business',
    moduleName: STORE_MODULES.MODULE_ENTERPRISE,
    path: '/system/enterprise',
    isEnabled: false,
  }
];

export const extraStoreToolsList : ExtraStoreToolsViewModal[] = [
  {
    id: EXTRA_STORE_TOOLS.MARKETPLACE,
    text: 'Marketplace',
    icon: '/assets/img/v3/icons/store-front-white.svg',
    path: '',
  },
  {
    id: EXTRA_STORE_TOOLS.INTEGRATION,
    text: 'Integration',
    icon: '/assets/img/v3/icons/stack.svg',
    path: '',
  },
  {
    id: EXTRA_STORE_TOOLS.URLS,
    text: 'URLs',
    icon: '/assets/img/v3/icons/link.svg',
    path: '',
  },
  {
    id: EXTRA_STORE_TOOLS.QUICKBOOKS,
    text: 'Quickbooks',
    icon: '/assets/img/v3/icons/quick-books.svg',
    path: V2_ROUTES.QUICKBOOKS.path,
  },
  {
    id: STORE_MODULES.MODULE_MAIL_CHIMP,
    text: 'Mail Chimp',
    icon: '/assets/img/v3/icons/mailchimp-logo.png',
    path: '',
  }
];

export const MORE_TOOLS_DROP_DOWN_MENU_LIST: DropdownMenuViewModal[] = [
  {
    label: 'Dealer Portal',
    path: '',
    icon: '/assets/img/v3/icons/store-front-white.svg',
  },
  {
    label: 'Suggestions',
    path: '',
    icon: '/assets/img/v3/icons/chat-white.svg',
  },
  {
    label: 'Shop',
    path: '',
    icon: '/assets/img/v3/icons/shopping-cart-white.svg',
  },
  {
    label: 'Phone Book',
    path: '',
    icon: '/assets/img/v3/icons/address-book.svg',
  },
  {
    label: 'Support Library',
    path: '',
    icon: '/assets/img/v3/icons/bookmark-white.svg',
  },
  {
    label: 'Themes',
    path: '',
    icon: '/assets/img/v3/icons/color-pallet.svg',
    disable: true,
  },
  {
    label: 'Admin',
    path: '',
    icon: '/assets/img/v3/icons/user-shield-white.svg',
    toggleIcon: 'keyboard_arrow_right',
    submenu: [
      {
        label: 'Store',
        path: '',
        icon: '/assets/img/v3/icons/store-front-white.svg',
      },
      {
        label: 'Enterprises',
        path: '',
        icon: '/assets/img/v3/icons/building-white.svg',
      },
      {
        label: 'Communities',
        path: '',
        icon: '/assets/img/v3/icons/communities-white.svg',
      },
      {
        label: 'Documents',
        path: '',
        icon: '/assets/img/v3/icons/folder-open-white.svg',
      },
      {
        label: 'Support',
        path: '',
        icon: '/assets/img/v3/icons/headset-white.svg',
      },
      {
        label: 'System',
        path: '',
        icon: '/assets/img/v3/icons/gear-white.svg',
      },
      {
        label: 'Log History',
        path: '',
        icon: '/assets/img/v3/icons/clock-anti-clockwise-white.svg',
      },
    ],
  },
  {
    label: 'Billing',
    path: '',
    icon: '/assets/img/v3/icons/dollar-rounded-white.svg',
    toggleIcon: 'keyboard_arrow_right',
    submenu: [
      {
        label: 'Fees',
        path: '',
        icon: '/assets/img/v3/icons/dollar-rounded-white.svg',
      },
      {
        label: 'Payments',
        path: '',
        icon: '/assets/img/v3/icons/credit-card-white.svg',
      },
    ],
  }
];

export const MORE_TOOLS_DROP_DOWN: DropdownViewModal = {
  menu: MORE_TOOLS_DROP_DOWN_MENU_LIST,
  listContainerClass: 'bg-primary v3-font font-smaller font-weight-medium mw200 py-0 dark-theme arrange-main-dropdown translate-x-33 top-20',
  listItemClasses: 'd-flex d-flex justify-content-between align-items-center v3-font font-smaller font-weight-medium px15 py12 font-color-light',
  submenuContainerClass: 'dropdown-menu-right'
}
