import { ExtraStoreToolsViewModal, STORE_MODULES, StoreModuleViewModel, EXTRA_STORE_TOOLS } from "src/app/model/v3/store.model";
import { V2_ROUTES } from "./url.constants";

export const MAX_DATA_POINTS_SALES_BY_HOUR = 24;

export const SALES_BREAKDOWN_CHART_SEGMENT_LIMIT = 8;


export const storeModuleList: Array<StoreModuleViewModel> = [
  {
    id: STORE_MODULES.MODULE_NEW_BACK_OFFICE,
    text: 'New BOH',
    icon: 'auto_awesome',
    moduleName: STORE_MODULES.MODULE_NEW_BACK_OFFICE,
    path: V2_ROUTES.DASHBOARD.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_TIME_ATTENDANCE,
    text: 'Attendance',
    icon: 'punch_clock',
    moduleName: STORE_MODULES.MODULE_TIME_ATTENDANCE,
    path: V2_ROUTES.TIME.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_CUSTOMER_ACCOUNTS,
    text: 'Customers',
    icon: 'people',
    moduleName: STORE_MODULES.MODULE_CUSTOMER_ACCOUNTS,
    path: V2_ROUTES.CUSTOMER.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_INVENTORY,
    text: 'Inventory',
    icon: 'inventory',
    moduleName: STORE_MODULES.MODULE_INVENTORY,
    path: V2_ROUTES.INVENTORY.path,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_ONLINE_ORDERING,
    text: 'Self Order',
    icon: 'shopping_cart',
    moduleName: STORE_MODULES.MODULE_ONLINE_ORDERING,
    isEnabled: false,
  },
  {
    id: STORE_MODULES.MODULE_ENTERPRISE,
    text: 'Enterprise',
    icon: 'business',
    moduleName: STORE_MODULES.MODULE_ENTERPRISE,
    path: '/system/enterprise',
    isEnabled: false,
  }
];

export const extraStoreToolsList : ExtraStoreToolsViewModal[] = [
  {
    id: EXTRA_STORE_TOOLS.MARKETPLACE,
    text: 'Marketplace',
    icon: '/assets/img/v3/icons/store-front-white.svg',
    path: '',
  },
  {
    id: EXTRA_STORE_TOOLS.INTEGRATION,
    text: 'Integration',
    icon: '/assets/img/v3/icons/stack.svg',
    path: '',
  },
  {
    id: EXTRA_STORE_TOOLS.URLS,
    text: 'URLs',
    icon: '/assets/img/v3/icons/link.svg',
    path: '',
  },
  {
    id: EXTRA_STORE_TOOLS.QUICKBOOKS,
    text: 'Quickbooks',
    icon: '/assets/img/v3/icons/quick-books.svg',
    path: V2_ROUTES.QUICKBOOKS.path,
  },
  {
    id: STORE_MODULES.MODULE_MAIL_CHIMP,
    text: 'Mail Chimp',
    icon: '/assets/img/v3/icons/mailchimp-logo.png',
    path: '',
  }
];
