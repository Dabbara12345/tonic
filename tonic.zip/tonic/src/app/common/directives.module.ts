import { NgModule } from '@angular/core';

import { NowDirective } from './directives/now.directive';
import { FlotDirective } from './directives/flot.directive';
import { AngularXModule } from './angular.module';
import { BootstrapXModule } from './bootstrap.module';
import { JqcloudDirective } from './directives/jqcloud.directive';
import { SparklineDirective } from './directives/sparkline.directive';
import { VectormapDirective } from './directives/vectormap.directive';
import { ScrollableDirective } from './directives/scrollable.directive';
import { StopEventPropagationDirective } from './directives/stop-propagation.directive';

// https://angular.io/styleguide#!#04-10
@NgModule({
    imports: [
        AngularXModule,
        BootstrapXModule,
    ],
    declarations: [
        NowDirective,
        FlotDirective,
        JqcloudDirective,
        SparklineDirective,
        VectormapDirective,
        ScrollableDirective,
        StopEventPropagationDirective
    ],
    exports: [
        AngularXModule,
        BootstrapXModule,

        NowDirective,
        FlotDirective,
        JqcloudDirective,
        SparklineDirective,
        VectormapDirective,
        ScrollableDirective,
        StopEventPropagationDirective,
    ]
})

export class DirectivesModule {
}
