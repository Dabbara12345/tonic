import { Pipe } from '@angular/core';
import { PipeTransform } from '@angular/core';

@Pipe({
  name: 'shorten'
})
export class ShortenPipe implements PipeTransform {

  transform(
    value: string,
    index: number,
    limit: number,
    type?: string,
    length?: number
  ): string {

    if (type === 'single_sentence' &&
        value.length > limit) {
      // Shortening by a single string

      return value.slice(0, limit) + ' ... ';

    } else if (type === 'words' && value.split(' ').length > length) {

      // Shortening by quantity of words
      if (index < limit) {

        return value.split(' ').slice(0, length).join(' ') + ' ... ';

      } else if ( index === limit) {

        return ' ... ';

      } else {

        return null;
      }
    } else {

      // Shortening by an Array of strings
      if (index < limit) {

        return value;

      } else if ( index === limit) {

        return ' ... ';

      } else {

        return null;
      }
    }
  }
}
