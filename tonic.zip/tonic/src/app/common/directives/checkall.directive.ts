import { Directive } from '@angular/core';
import { ElementRef } from '@angular/core';

declare var $: any;

@Directive({
    selector: '[appCheckAll]'
})
export class CheckallDirective {

    constructor(public el: ElementRef) {

        const $element: any = $(el.nativeElement);

        $element.on('change', function(): void {

            const index: any = $element.index() + 1;
            const checkbox: any = $element.find('input[type="checkbox"]');
            const table: any = $element.parents('table');

            // Make sure to affect only the correct checkbox column
            table.find('tbody > tr > td:nth-child(' + index + ') input[type="checkbox"]')
                 .prop('checked', checkbox[0].checked);
        });
    }
}
