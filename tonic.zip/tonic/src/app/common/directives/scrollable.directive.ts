import { OnInit } from '@angular/core';
import { Directive } from '@angular/core';
import { Input } from '@angular/core';
import { ElementRef } from '@angular/core';

declare var $: any;

@Directive({
    selector: '[appScrollable]'
})
export class ScrollableDirective implements OnInit {

    @Input() height: number;

    private defaultHeight: number = 250;

    constructor(public element: ElementRef) { }

    public ngOnInit(): void {

        $(this.element.nativeElement).slimScroll({
            height: (this.height || this.defaultHeight)
        });
    }

}
