import { Input } from '@angular/core';
import { Output } from '@angular/core';
import { OnChanges } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Directive } from '@angular/core';
import { ElementRef } from '@angular/core';
import { SimpleChange } from '@angular/core';
import { EventEmitter } from '@angular/core';

declare var $: any;

@Directive({
    selector: '[appFlot]'
})
export class FlotDirective implements OnChanges, OnDestroy {

    private element: any;
    private plot: any;
    private width: any;

    @Input() dataset: any;
    @Input() options: any;
    @Input() attrWidth: any;
    @Input() height: number;
    @Input() series: any;

    @Output() ready: EventEmitter<any> = new EventEmitter();

    constructor(public el: ElementRef) {

        this.element = $(this.el.nativeElement);

        if (!$.plot) {
            console.log('Flot chart no available.');
        }

        this.plot = null;
    }

    public ngOnChanges(changes: { [propertyName: string]: SimpleChange }): void {

        if (!$.plot) {
            return;
        }

        if (changes['dataset']) {
            this.onDatasetChanged(this.dataset);
        }

        if (changes['series']) {
            this.onSerieToggled(this.series);
        }
    }

    public init(): void {

        const heightDefault: number = 220;

        this.width = this.attrWidth || '100%';
        this.height = this.height || heightDefault;

        this.element.css({
            width: this.width,
            height: this.height
        });

        let plotObj: any;

        if (!this.dataset || !this.options) {
            return;
        }

        plotObj = $.plot(this.el.nativeElement, this.dataset, this.options);

        if (this.ready) {
            this.ready.next({ plot: plotObj });
        }

        return plotObj;
    }

    public onDatasetChanged(dataset: any): void {

        if (this.plot) {

            this.plot.setData(dataset);
            this.plot.setupGrid();

            return this.plot.draw();

        } else {

            this.plot = this.init();
            this.onSerieToggled(this.series);

            return this.plot;
        }
    }

    public onSerieToggled(series: any): void {

        if (!this.plot || !series) {
            return;
        }

        let someData: any = this.plot.getData();

        for (let sName in series) {
            series[sName].forEach(toggleFor(sName));
        }

        this.plot.setData(someData);
        this.plot.draw();

        function toggleFor(sName: any): (s: any, i: number) => void {

            return function(s, i: number): void {
                if (someData[i] && someData[i][sName]) {
                    someData[i][sName].show = s;
                }
            };
        }
    }

    public ngOnDestroy(): void {

        if (this.plot) {
            this.plot.shutdown();
        }
    }
}
