import { OnInit } from '@angular/core';
import { OnChanges } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Input } from '@angular/core';
import { Directive } from '@angular/core';
import { ElementRef } from '@angular/core';
import { SimpleChange } from '@angular/core';

declare var $: any;

@Directive({
    selector: '[appJqcloud]'
})
export class JqcloudDirective implements OnInit, OnDestroy, OnChanges {

    @Input() words;
    @Input() width;
    @Input() height;
    @Input() steps;

    $elem: any;
    options: any;
    initialized: boolean = false; // flag to not update before plugin was initialized

    constructor(element: ElementRef) {
        this.$elem = $(element.nativeElement);
        this.options = $.fn.jQCloud.defaults.get();
    }

    public ngOnInit(): void {

        let opts: any = {};

        if (this.width) {
            opts.width = this.width;
        }

        if (this.height) {
            opts.height = this.height;
        }

        if (this.steps) {
            opts.steps = this.steps;
        }

        $.extend(this.options, opts);
        this.$elem.jQCloud(this.words, opts);
        this.initialized = true;
    }

    public ngOnChanges(changes: { [propertyName: string]: SimpleChange }): void {

        if (this.initialized && this.words && changes['words']) {
            this.$elem.jQCloud('update', this.words);
        }
    }

    public ngOnDestroy(): void {
        this.$elem.jQCloud('destroy');
    }
}
