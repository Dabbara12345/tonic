import { Directive } from '@angular/core';
import { HostListener } from '@angular/core';

@Directive({
    selector: '[stopEventPropagation]'
})
export class StopEventPropagationDirective {

    @HostListener('keydown.enter', ['$event'])
    @HostListener('keydown.Space', ['$event'])
    @HostListener('keydown.Home', ['$event'])
    @HostListener('keydown.End', ['$event'])

    public onKeydown(event: KeyboardEvent): void {

      event.stopImmediatePropagation();
    }

    @HostListener('click', ['$event'])

    public onClick(event: any): void {

      event.stopPropagation();
    }
}
