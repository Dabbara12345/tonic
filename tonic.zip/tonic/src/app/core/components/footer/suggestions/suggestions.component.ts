import { Component, EventEmitter, Inject, Output } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

import { Suggestion } from 'src/app/model/communication/suggestion.model';
import { SuggestionService } from 'src/app/service/communication/suggestion.service';
import { SessionService } from 'src/app/service/session.service';
import { AlertService } from 'src/app/service/utils/alert.service';

@Component({
  selector: 'app-suggestions',
  templateUrl: './suggestions.component.html',
  styleUrls: ['./suggestions.component.scss']
})
export class SuggestionsComponent {
  suggestionsText: string;
  @Output() dismiss: EventEmitter<MouseEvent> = new EventEmitter();
  constructor(public sessionService: SessionService, private suggestionService: SuggestionService, private alertService: AlertService, @Inject(MAT_DIALOG_DATA) private modalData: { email: string }) { }

  send(): void {
    const suggestion: Suggestion = new Suggestion();
    suggestion.details = this.suggestionsText;
    suggestion.email = this.modalData.email;
    this.suggestionService.save(suggestion).subscribe({
      next: (): void => {
        this.alertService.success('Thank you for your suggestion, we will review it right away');
        this.suggestionsText = '';
        this.dismiss.emit();
      },
      error: (err): void => {
        this.alertService.success('Unable to send your suggestion, please retry later\n', err);
      }
    });
  }

}
