import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { FooterComponent } from './footer.component';
import { RouterModule } from '@angular/router';
import { SuggestionsComponent } from './suggestions/suggestions.component';
import { MaterialXModule } from 'src/app/common/material.module';



@NgModule({
  declarations: [
    FooterComponent,
    SuggestionsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    MaterialXModule
  ],
  exports: [
    FooterComponent
  ]
})
export class FooterModule { }
