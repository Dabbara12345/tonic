import { Component, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Store as NgRxStore } from '@ngrx/store';
import { MatDialog } from '@angular/material/dialog';
import { take, takeWhile } from 'rxjs';

import {FOOTER_URLS, V2_ROUTES} from 'src/app/common/constants/url.constants';
import {COMPANY_ADDRESS, COMPANY_INFO_EMAIL, COMPANY_INFO_PHONE} from 'src/app/common/constants/company-info.constants';
import { StorageService } from 'src/app/service/storage.service';
import { HelpComponent } from 'src/app/route/help/help.component';
import { PrivacyPolicyComponent } from 'src/app/route/nav-bar/privacy-policy/privacy-policy.component';
import { selectUserEmailId } from 'src/app/modules/auth/selectors/auth.selector';
import { SuggestionsComponent } from './suggestions/suggestions.component';
import { PhonebookComponent } from 'src/app/route/nav-bar/nav-options/phonebook/phonebook.component';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnDestroy {
  public screenWidth = window.innerWidth;
  public footerUrls = FOOTER_URLS;
  public routesV2 = V2_ROUTES;
  public companyAddress = COMPANY_ADDRESS;
  public companyInfoEmail = COMPANY_INFO_EMAIL;
  public companyInfoPhone = COMPANY_INFO_PHONE;
  private _isAlive = true;
  userEmail$ = this._ngRxStore.select(selectUserEmailId).pipe(takeWhile(() => this._isAlive));

  constructor(private _router: Router,  private _storageService: StorageService, private _ngRxStore: NgRxStore, private _dialog: MatDialog) { }

  // Temporary method to handle router navigation to old Beta application - VRIZ-363
  onV2RouteClick(routeData: { path: string; text: string; }): void {
    // Logic in the existing Beta application to set nav-option in local storage which allows the router navigation to old Beta application's pages.
    // Ref- saveSelectedNode() & setDefaultNode() in route.component.ts.
    this._storageService.addSetting('nav-option', routeData.text);
    this._router.navigateByUrl(routeData.path);
  }

  public onHelpCenterClick() {
    const helpDialogRef = this._dialog.open(HelpComponent, {
      width: '600px',
      disableClose: false,
      data: ''
    });

    helpDialogRef.componentInstance.dismiss.subscribe(() => {
      helpDialogRef.close();
    });
  }

  public onPrivacyClick(): void {
    this._dialog.open(PrivacyPolicyComponent, {
        width: '800px',
        maxHeight: '700px',
        disableClose: false,
        data: ''
      })
  }

  onSuggestionsClick(): void {
    let userEmail = '';
    this.userEmail$.pipe(take(1)).subscribe(email => {
      userEmail = email;
    })
    const suggestionsDialogRef = this._dialog.open(SuggestionsComponent, {
      disableClose: false,
      data: {
        email: userEmail
      }
    });
    suggestionsDialogRef.componentInstance.dismiss.subscribe(() => {
      suggestionsDialogRef.close();
    });
  }

  onPhoneBookClick(): void {
    this._dialog.open(PhonebookComponent, {
      width: '700px',
      maxHeight: '800px',
      disableClose: false
    })
  }

  ngOnDestroy(): void {
    this._isAlive = false;
  }

}
