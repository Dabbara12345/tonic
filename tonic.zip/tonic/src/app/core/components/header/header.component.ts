import { Component, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Store as NgRxStore } from '@ngrx/store';
import { combineLatest, map, takeWhile } from 'rxjs';

import { DASHBOARD_ROUTES, V2_ROUTES } from 'src/app/common/constants/url.constants';
import { HeaderEnum } from './header.model';
import { selectUser, selectUserRoles } from 'src/app/modules/auth/selectors/auth.selector';
import { StorageService } from 'src/app/service/storage.service';
import { MORE_TOOLS_DROP_DOWN } from 'src/app/common/constants/common.constants';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnDestroy {
  private _isAlive = true;
  public logo = '/assets/img/logo/tonic_white_blue.svg';
  public notificationIcon = '/assets/img/v3/icons/bell.svg';
  public notificationValue = '8';
  public dashboardRoutes = DASHBOARD_ROUTES;
  public routesV2 = V2_ROUTES;
  public subMenu = '';
  public headerEnum = HeaderEnum;
  private _loggedInUser$ = this._store.select(selectUser).pipe(takeWhile(() => this._isAlive));
  private _userRoles$ = this._store.select(selectUserRoles).pipe(takeWhile(() => this._isAlive));
  public userDetails$ = combineLatest([this._loggedInUser$, this._userRoles$]).pipe(
    map(([user, roles]) => ({ user, roles }))
  );
  public moreToolsDropdown = MORE_TOOLS_DROP_DOWN; // Data will be used for displaying 'More Tools' dropdown.
  constructor(private _store: NgRxStore, private _router: Router, private storageService: StorageService){}

  onSubMenuClick = (subMenu: string):void => {
    if(subMenu === this.subMenu){
      this.subMenu = '';
      return;
    }
    this.subMenu = subMenu;
  }

  // Temporary method to handle router navigation to old Beta application - VRIZ-367
  onHeaderItemsClick(routeData: { path: string; text: string; }): void {
    // Logic in the existing Beta application to set nav-option in local storage which allows the router navigation to old Beta application's pages.
    // Ref- saveSelectedNode() & setDefaultNode() in route.component.ts.
    this.storageService.addSetting('nav-option', routeData.text);
    this._router.navigateByUrl(routeData.path);
    this.onSubMenuClick(this.subMenu); // Calling again the same method with the existing subMenu data which will close the dropdown as per the logic of the method.
  }

  ngOnDestroy(): void {
      this._isAlive = false;
  }
}
