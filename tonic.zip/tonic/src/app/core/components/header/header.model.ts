export enum HeaderEnum {
  HOME = 'home',
  WIDGETS = 'widgets',
  REPORTS = 'reports',
  CONFIGURATION = 'configuration',
  ACTIVITY = 'activity',
  APPS = 'apps'
}

export enum NavbarUserMenu {
  SETTINGS = 'Settings', 
  STORE = 'Store',
  OLO_SCHEDULES = 'OLO Schedules',
  BILLING = 'Billing',
  LOGOUT = 'Logout',
}