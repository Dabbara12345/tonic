import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationSubmenuComponent } from './configuration-submenu.component';

describe('ConfigurationSubmenuComponent', () => {
  let component: ConfigurationSubmenuComponent;
  let fixture: ComponentFixture<ConfigurationSubmenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfigurationSubmenuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationSubmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
