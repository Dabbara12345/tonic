import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppsSubmenuComponent } from './apps-submenu.component';

describe('AppsSubmenuComponent', () => {
  let component: AppsSubmenuComponent;
  let fixture: ComponentFixture<AppsSubmenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppsSubmenuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppsSubmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
