import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToggleStoreModuleComponent } from './toggle-store-module.component';

describe('ToggleStoreModuleComponent', () => {
  let component: ToggleStoreModuleComponent;
  let fixture: ComponentFixture<ToggleStoreModuleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ToggleStoreModuleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ToggleStoreModuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
