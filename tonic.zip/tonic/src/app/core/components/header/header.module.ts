import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { MatTooltipModule } from '@angular/material/tooltip';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MatIconModule } from '@angular/material/icon';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { HeaderComponent } from './header.component';
import { ConfigurationSubmenuComponent } from './configuration-submenu/configuration-submenu.component';
import { AppsSubmenuComponent } from './apps-submenu/apps-submenu.component';
import { ToggleStoreModuleComponent } from './apps-submenu/toggle-store-module/toggle-store-module.component';
import { FormsModule } from '@angular/forms';
import { SharedV3Module } from 'src/app/shared-v3/shared-v3.module';
import { NavbarUserMenuDropdownComponent } from './user-details/navbar-usermenu-dropdown.component';


@NgModule({
  declarations: [
    HeaderComponent,
    NavbarUserMenuDropdownComponent,
    ConfigurationSubmenuComponent,
    AppsSubmenuComponent,
    ToggleStoreModuleComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    MatTooltipModule,
    MatIconModule,
    MatSlideToggleModule,
    FormsModule,
    SharedV3Module,
    BsDropdownModule
  ],
  exports: [
    HeaderComponent
  ]
})
export class HeaderModule { }
