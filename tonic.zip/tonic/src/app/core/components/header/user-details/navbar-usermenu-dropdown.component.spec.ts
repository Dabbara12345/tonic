import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavbarUserMenuDropdown } from './navbar-usermenu-dropdown.component';

describe('UserDetailsComponent', () => {
  let component: NavbarUserMenuDropdown;
  let fixture: ComponentFixture<NavbarUserMenuDropdown>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NavbarUserMenuDropdown ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarUserMenuDropdown);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
