import { Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';

import { Store as NgRxStore} from '@ngrx/store';
import { MatDialog } from '@angular/material/dialog';
import swal from 'sweetalert2';
import { takeWhile } from 'rxjs';

import { getInitials } from 'src/app/shared-v3/utils';
import { NavbarUserMenu } from '../header.model';
import { SettingsComponent } from 'src/app/route/nav-bar/nav-options/settings/settings.component';
import { CurrentStoreComponent } from 'src/app/route/nav-bar/nav-options/current-store/current-store.component';
import { OloSchedulesComponent } from 'src/app/route/nav-bar/nav-options/olo-schedules/olo-schedules.component';
import { SessionService } from 'src/app/service/session.service';
import { selectSelectedStore } from 'src/app/modules/auth/selectors/auth.selector';
import { Store } from 'src/app/model/store.model';
import { Logout } from 'src/app/modules/auth/actions/auth.action';

@Component({
  selector: 'app-navbar-usermenu-dropdown',
  templateUrl: './navbar-usermenu-dropdown.component.html',
  styleUrls: ['./navbar-usermenu-dropdown.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class NavbarUserMenuDropdownComponent implements OnInit, OnDestroy {
  @Input() public userDisplayName = '';
  @Input() public userRolesArray: string[] = [];
  private _isAlive = true;
  private selectedStoreDetails: Store;

  settingsDropdownMenu = [
    { name: NavbarUserMenu.SETTINGS, icon: '/assets/img/v3/icons/settings-icon.svg' },
    { name: NavbarUserMenu.STORE, icon: '/assets/img/v3/icons/store-icon.svg' },
    { name: NavbarUserMenu.OLO_SCHEDULES, icon: '/assets/img/v3/icons/clock-icon.svg' },
    { name: NavbarUserMenu.BILLING, icon: '/assets/img/v3/icons/dollar-circle-icon.svg' },
    { name: NavbarUserMenu.LOGOUT, icon: '/assets/img/v3/icons/signout-icon.svg' },
  ];

  get userRolesString(): string {
    return this.userRolesArray?.join(', ');
  }

  get userDisplayRole(): string {
    return this.userRolesArray?.length > 1 ? this.userRolesArray[0] + '...' : this.userRolesArray?.[0] || '';
  }

  get getInitials(): string {
    return getInitials(this.userDisplayName);
  }

  constructor(
    private _dialogService: MatDialog,
    private _sessionService: SessionService,
    private _ngRxStore: NgRxStore
  ) { }
  
  ngOnInit(): void {
    this._ngRxStore.select(selectSelectedStore).pipe(takeWhile(() => this._isAlive)).subscribe((selectedStore: Store) => {
      this.selectedStoreDetails = selectedStore;
    })
  }

  onMenuSelected(selectedMenu: string): void {
    const dialogConfigData = {
      [NavbarUserMenu.SETTINGS]: { component: SettingsComponent, config: { width: '800px', maxHeight: '700px', disableClose: true }},
      [NavbarUserMenu.STORE]: { component: CurrentStoreComponent, config: { width: '800px', maxHeight: '700px', disableClose: true }},
      [NavbarUserMenu.OLO_SCHEDULES]: { component: OloSchedulesComponent, config: { width: '800px', maxHeight: '700px', disableClose: true, data: { store: this.selectedStoreDetails }}},
      [NavbarUserMenu.LOGOUT]: null // Handle logout separately
    };

    if (selectedMenu === NavbarUserMenu.LOGOUT) {
      this.handleLogout();
    } else {
      const dialogConfig = dialogConfigData[selectedMenu];
      if (dialogConfig) {
        this._dialogService.open(dialogConfig.component, dialogConfig.config);
      }
    }
  }

  handleLogout(): void {
    swal.fire({
      title: 'Ready to Log out?',
      icon: 'warning',
      confirmButtonText: 'Yes',
      confirmButtonColor: 'rgb(63, 81, 181)',
      cancelButtonText: 'No',
      cancelButtonColor: 'rgb(244, 67, 54)',
      showCancelButton: true,
      showCloseButton: true
    }).then((response): void => {
      if (response.isConfirmed) {
        console.log(new Date() + ' Explicit logout');
        this._ngRxStore.dispatch(Logout());
      }
    });
  }

  ngOnDestroy(): void {
    this._isAlive = false;
  }
}
