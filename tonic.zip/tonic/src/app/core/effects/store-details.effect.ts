import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { exhaustMap, catchError, map, switchMap  } from 'rxjs/operators';
import { of } from 'rxjs';
import * as _ from 'lodash';
import { Store as NgRxStore} from '@ngrx/store';

import {
    RetrieveEnterpriseConfig, RetrieveEnterpriseConfigFailed, StoreEnterpriseConfig,
    ToggleStoreModule, ToggleStoreModuleSuccessful, ToggleStoreModuleFailed, EnableStoreModule, DisableStoreModule,
    EnableOnlineOrderingModule, DisableOnlineOrderingModule
} from 'src/app/core/actions/store-details.action'
import { SettingService } from 'src/app/service/config/setting.service';
import { NameValue } from 'src/app/model/utils/nameValue.model';
import { LogService } from 'src/app/service/activity/log.service';
import { STORE_MODULES } from 'src/app/model/v3/store.model';
import { AlertService } from 'src/app/service/utils/alert.service';
import { NoOpAction } from 'src/app/core/actions/no-op.action';
import { selectSelectedStore } from 'src/app/modules/auth/selectors/auth.selector';
import { getState } from 'src/app/shared-v3/utils';
import { Store } from 'src/app/model/store.model';
import { SessionService } from 'src/app/service/session.service';
import { SelectedStore } from 'src/app/modules/auth/actions/auth.action';
import { MarketplaceService } from 'src/app/service/vas/marketplace.service';
import { AppInstalledService } from 'src/app/service/vas/app-installed.service';
import { App } from 'src/app/model/vas/app.model';

@Injectable()
export class StoreDetailsEffects {
    constructor(
        private _actions: Actions, private _ngRxStore: NgRxStore,
        private _settingService: SettingService, private _logService: LogService, private _alertService: AlertService, private _sessionService: SessionService,
        private _marketplaceService: MarketplaceService, private _appInstalledService: AppInstalledService,
    ) { }

    retrieveEnterpriseConfig = createEffect(() => this._actions.pipe(
        ofType(RetrieveEnterpriseConfig),
        exhaustMap(() => {
            const includeSiblingEnabled = true;
            return this._settingService.get(STORE_MODULES.MODULE_ENTERPRISE, includeSiblingEnabled)
                .pipe(
                    map((response: NameValue) => {
                        return StoreEnterpriseConfig(response.value === 'true');
                    }),
                    catchError((err) => {
                        this._logService.error(err);
                        return of(RetrieveEnterpriseConfigFailed());
                    })
                );
        })
    ));

    toggleStoreModule = createEffect(() => this._actions.pipe(
        ofType(ToggleStoreModule),
        map(({moduleName, enable}) => {
            if(enable) {
                return EnableStoreModule(moduleName);
            }
            return DisableStoreModule(moduleName);
        })
    ));

    enableStoreModule = createEffect(() => this._actions.pipe(
        ofType(EnableStoreModule),
        exhaustMap(({moduleName}) => {
            // OLO specific action to be dispatched
            if(moduleName === STORE_MODULES.MODULE_ONLINE_ORDERING) {
                return of(EnableOnlineOrderingModule());
            }
            return this._settingService.enable(moduleName)
                .pipe(
                    map((response: NameValue) => {
                        return ToggleStoreModuleSuccessful(moduleName, true);
                    }),
                    catchError((err) => {
                        this._logService.error(err);
                        this._alertService.error(err)
                        return of(ToggleStoreModuleFailed(moduleName, true));
                    })
                );
        })
    ));

    disableStoreModule = createEffect(() => this._actions.pipe(
        ofType(DisableStoreModule),
        exhaustMap(({moduleName}) => {
            // enterprise module can only be disabled by contacting support
            if(moduleName === STORE_MODULES.MODULE_ENTERPRISE) {
                this._alertService.warning('Contact Support to disable Enterprise');
                return of(NoOpAction());
            }
            // OLO specific action to be dispatched
            if(moduleName === STORE_MODULES.MODULE_ONLINE_ORDERING) {
                return of(DisableOnlineOrderingModule());
            }
            return this._settingService.disable(moduleName)
                .pipe(
                    map(() => {
                        return ToggleStoreModuleSuccessful(moduleName, false);
                    }),
                    catchError((err) => {
                        this._logService.error(err);
                        this._alertService.error(err)
                        return of(ToggleStoreModuleFailed(moduleName, false));
                    })
                );
        })
    ));

    toggleStoreModuleSuccessful = createEffect(() => this._actions.pipe(
        ofType(ToggleStoreModuleSuccessful),
        switchMap(({moduleName, enabled}) => {
            this._alertService.success(`Module ${enabled ? 'Enabled' : 'Disabled'}`);
            const selectedStore = getState<Store>(this._ngRxStore, selectSelectedStore);
            selectedStore.toggle(moduleName, enabled);
            this._sessionService.updateStore(selectedStore);
            // enterprise config is kept in a separate slice 
            if(moduleName === STORE_MODULES.MODULE_ENTERPRISE) {
                [SelectedStore(selectedStore), StoreEnterpriseConfig(enabled)]
            }
            return [SelectedStore(selectedStore)];
        })
    ));

    enableOnlineOrderingModule = createEffect(() => this._actions.pipe(
        ofType(EnableOnlineOrderingModule),
        exhaustMap(() => {
            return this._marketplaceService.get('olo')
                .pipe(
                    exhaustMap((response: App) => {
                        return this._appInstalledService.enable(response.id)
                            .pipe(
                                map(() => {
                                    return ToggleStoreModuleSuccessful(STORE_MODULES.MODULE_ONLINE_ORDERING, true);
                                })
                            );
                    }),
                    catchError((err) => {
                        this._logService.error(err);
                        this._alertService.error(err)
                        return of(ToggleStoreModuleFailed(STORE_MODULES.MODULE_ONLINE_ORDERING, true));
                    })
                );
        })
    ));

    disableOnlineOrderingModule = createEffect(() => this._actions.pipe(
        ofType(DisableOnlineOrderingModule),
        exhaustMap(() => {
            return this._marketplaceService.get('olo')
                .pipe(
                    exhaustMap((response: App) => {
                        return this._appInstalledService.disable(response.id)
                            .pipe(
                                map(() => {
                                    return ToggleStoreModuleSuccessful(STORE_MODULES.MODULE_ONLINE_ORDERING, false);
                                })
                            );
                    }),
                    catchError((err) => {
                        this._logService.error(err);
                        this._alertService.error(err)
                        return of(ToggleStoreModuleFailed(STORE_MODULES.MODULE_ONLINE_ORDERING, false));
                    })
                );
        })
    ));

}
