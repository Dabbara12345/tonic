import {createAction} from '@ngrx/store';

// an empty action which does nothing
export const NoOpAction = createAction(
  '[NoOp] No-Op Action'
);
