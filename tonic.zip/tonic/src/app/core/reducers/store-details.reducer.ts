import { Action, createReducer, on } from '@ngrx/store';

import { StoreConfig } from 'src/app/model/v3/store.model';
import { StoreEnterpriseConfig } from 'src/app/core/actions/store-details.action';

export interface StoreDetailsState {
    config: StoreConfig
}

export const initialState: StoreDetailsState = {
    config: {
        enterpriseEnabled: false
    }
}

const reducer = createReducer(
    initialState,
    on(StoreEnterpriseConfig, (state, {enabled}) => ({
        ...state,
        config: {
            ...state.config,
            enterpriseEnabled: enabled
        }
    })),
);

export function StoreDetailsReducer(state: StoreDetailsState, action: Action) {
    return reducer(state, action);
}
