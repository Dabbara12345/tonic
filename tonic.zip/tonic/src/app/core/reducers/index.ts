import * as fromRouter from '@ngrx/router-store';
import { ActionReducerMap } from '@ngrx/store';

import * as fromUi from './ui.reducer';
import * as fromLookup from './lookup.reducer';
import * as fromStoreDetails from './store-details.reducer'

export interface State {
    router: fromRouter.RouterReducerState;
    ui: fromUi.UiState;
    lookup: fromLookup.LookupState;
    storeDetails: fromStoreDetails.StoreDetailsState;
}

export const reducers: ActionReducerMap<State> = {
    router: fromRouter.routerReducer,
    ui: fromUi.UiStateReducer,
    lookup: fromLookup.LookupReducer,
    storeDetails: fromStoreDetails.StoreDetailsReducer
}