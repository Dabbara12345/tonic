import { Action, createReducer } from "@ngrx/store"

export interface UiState {

}

export const initialState: UiState = {

}

const reducer = createReducer(
    initialState
);

export function UiStateReducer(state: UiState, action: Action) {
    return reducer(state, action);
}