import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as _ from 'lodash';

import { StoreDetailsState } from 'src/app/core/reducers/store-details.reducer';
import { ExtraStoreToolsViewModal, StoreConfig, StoreModuleViewModel } from 'src/app/model/v3/store.model';
import { isManager, isSupportUser, selectSelectedStore } from 'src/app/modules/auth/selectors/auth.selector';
import { extraStoreToolsList, storeModuleList } from 'src/app/common/constants/common.constants';
import { STORE_MODULES } from 'src/app/model/v3/store.model';
import { Store } from 'src/app/model/store.model';
import { NameValue } from 'src/app/model/utils/nameValue.model';

export const selectStoreDetailsState = createFeatureSelector<StoreDetailsState>('storeDetails');

export const selectStoreConfigState = createSelector(
    selectStoreDetailsState,
    (state: StoreDetailsState): StoreConfig => state ? state.config : null
);

export const selectIsEnterpriseEnabled = createSelector(
    selectStoreConfigState,
    (state: StoreConfig): boolean => state ? state.enterpriseEnabled : false
);

export const selectIsModuleEnabled = (moduleName: STORE_MODULES) =>
    createSelector(
        selectSelectedStore,
        selectIsEnterpriseEnabled,
        (selectedStore: Store, enterpriseEnabled: boolean): boolean => moduleName === STORE_MODULES.MODULE_ENTERPRISE
            ? enterpriseEnabled
            : selectedStore.hasEnabled(moduleName)
    );

export const selectSelectedStoreSettings = createSelector(
  selectSelectedStore,
  (selectedStore: Store): NameValue[] => selectedStore ? selectedStore.settings : undefined
);

export const selectModules = createSelector(
  selectIsEnterpriseEnabled,
  selectSelectedStore,
  isSupportUser,
  isManager,
  (enterpriseEnabled: boolean, store: Store, isSupportUser: boolean, isManager: boolean): StoreModuleViewModel[] => {
    const isOloAvailable = store?.hasSetting(STORE_MODULES.TOKEN_OLO);
    const tempModules = _.map(storeModuleList, (module: StoreModuleViewModel) => {

      const isEnabled = module.moduleName === STORE_MODULES.MODULE_ENTERPRISE ? enterpriseEnabled : store.hasEnabled(module.moduleName);

      let includeModuleInTheMenu = false;

      switch (module.id) {
        case STORE_MODULES.MODULE_NEW_BACK_OFFICE:
          includeModuleInTheMenu = isSupportUser;
          break;
        case STORE_MODULES.MODULE_TIME_ATTENDANCE:
        case STORE_MODULES.MODULE_CUSTOMER_ACCOUNTS:
        case STORE_MODULES.MODULE_INVENTORY:
          includeModuleInTheMenu = isEnabled || isManager;
          break;
        case STORE_MODULES.MODULE_ENTERPRISE:
          includeModuleInTheMenu = enterpriseEnabled;
        break;
        case STORE_MODULES.MODULE_ONLINE_ORDERING:
          includeModuleInTheMenu = isOloAvailable || isManager;
        break;
        default:
          includeModuleInTheMenu = false;
          break;
      }

      return {
        ...module,
        isEnabled,
        includeModuleInTheMenu // This is used only for filtering
      };
    });

    // Filtering and removing `includeModuleInTheMenu` key.
    return _.chain(tempModules).filter(module => module.includeModuleInTheMenu).map(({ includeModuleInTheMenu, ...module }) => module).value();
  }
);

export const selectActiveModules = createSelector(
  selectModules,
  (modules: StoreModuleViewModel[]): StoreModuleViewModel[] => modules.filter(module => module.isEnabled)
);

export const selectDisabledModules = createSelector(
  selectModules,
  (modules: StoreModuleViewModel[]): StoreModuleViewModel[] => modules.filter(module => !module.isEnabled)
);

export const selectExtraStoreToolList = createSelector(
  selectSelectedStore,
  (store: Store): ExtraStoreToolsViewModal[] => {
    const isMailChipEnabled = store?.hasEnabled(STORE_MODULES.MODULE_MAIL_CHIMP);

    const tempOptions = _.map(extraStoreToolsList, (option: ExtraStoreToolsViewModal) => {
      let includeModuleInTheMenu = true;

      switch (option.id) {
        case STORE_MODULES.MODULE_MAIL_CHIMP:
          includeModuleInTheMenu = isMailChipEnabled
          break;
        default:
          break;
      }

      return {
        ...option,
        includeModuleInTheMenu // This is used only for filtering
      }
    })

    // Filtering and removing `includeModuleInTheMenu` key.
    return _.chain(tempOptions).filter(option => option.includeModuleInTheMenu).map(({includeModuleInTheMenu, ...option}) => option).value();
  }
);
