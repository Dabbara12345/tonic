export interface Paginator {
  previousPageIndex: number;
  pageIndex: number;
  pageSize: number;
  length: number;
}
