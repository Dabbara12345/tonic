export interface JsonData {
  name: string;
  value: string;
}
