var replace = require("replace-in-file");

const moment = require("moment-timezone");
var timeStamp = moment(new Date()).tz("America/New_York")
                                  .format("MMM D, YY @ h:mm a");
const optionsTimestamp = {files: ["src/environments/environment.ts",
                                  "src/environments/environment.test.ts",
                                  "src/environments/environment.qa2.ts",
                                  "src/environments/environment.dev.ts",
                                  "src/environments/environment.qa.ts",
                                  "src/environments/environment.uat.ts",
                                  "src/environments/environment.prod-preview.ts",
                                  "src/environments/environment.admin-prod.ts",
                                  "src/environments/environment.prod.ts"],
                          from: /timeStamp: '(.*)'/g,
                          to: "timeStamp: '" + timeStamp + "'",
                          allowEmptyPaths: false,};

try {

    let changedFilesTimestamp = replace.sync(optionsTimestamp);

    if (changedFilesTimestamp == 0) {
        throw ("Please make sure that the file '" + optionsTimestamp.files + "' has \"timeStamp: ''\"");
    }

    console.log("Build timestamp is set to: " + timeStamp + ' in ', changedFilesTimestamp);

} catch (error) {
    console.error("Error occurred:", error);
    throw error;
}
